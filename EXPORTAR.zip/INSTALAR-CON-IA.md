# Instalación Asistida por IA (Todo-en-Uno)

Copia el bloque de abajo y pégalo en **Claude Code**, **Antigravity** o cualquier agente con acceso a terminal y sistema de archivos en Windows. El agente instala todo el sistema completo por defecto sin requerir configuraciones adicionales.

---

```
Instálame el sistema completo de dashboards de Power BI "Metodología 2" (Datdata + Fabric Authoring) en este equipo.
Trabaja de forma 100% autónoma: ejecuta todos los pasos y al final indícame el estado de la instalación.

CONTEXTO
Es un sistema integral para construir dashboards profesionales de Power BI de forma automática:
- El modelo semántico y las medidas DAX se gestionan mediante el MCP oficial de Power BI.
- Los visuales (gráficas Deneb Vega-Lite, tarjetas HTML/CSS fluidas, barra de filtros interactiva) los genera el motor hybrid.js.
- El diseño, layout y buenas prácticas se gobiernan mediante la suite completa de skills de Datdata y Microsoft Fabric.
- Todo el ecosistema queda instalado de forma global en %USERPROFILE%\.claude\skills (y ~/.gemini/config/skills si aplica).

PASOS A EJECUTAR

1. Node.js LTS
   Comprueba `node --version`. Si no está presente, instálalo:
     winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
   Recarga el PATH del entorno antes de continuar.

2. CLIs de Microsoft Fabric y MCP
   Ejecuta:
     npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli @microsoft/powerbi-modeling-mcp
   Verifica que `powerbi-report-author --help` y `powerbi-desktop status` respondan correctamente.

3. Suite Completa de Skills
   Descarga y descomprime el paquete Todo-en-Uno:
     https://ricardo050427.github.io/datdata/EXPORTAR.zip
   Copia TODAS las carpetas de skills incluidas a %USERPROFILE%\.claude\skills\ (y a %USERPROFILE%\.gemini\config\skills si existe .gemini):
     - powerbi-dashboard (orquestador + hybrid.js + visual Filtro)
     - powerbi-report-design (arquetipos, grids de diseño, color y tipografía)
     - powerbi-report-planning (arquitectura de información y KPIs)
     - powerbi-report-authoring (formato y mecánicas PBIR)
     - semantic-model-authoring (DAX de alto rendimiento y modelos estrella)
     - semantic-model-consumption (consultas de descubrimiento)
     - powerbi-report-management
     - deneb-chart-generator (Vega-Lite interactivo y cross-filtering)
     - html-kpi-cards (tarjetas de KPI y deltas en HTML/CSS)
     - powerbi-filter (barra de filtros y ordenamiento en español)
     - powerbi-dax-auditor (auditoría de calidad del modelo)
     - check-updates
   (Si alguna ya existía, respalda la anterior con sufijo .bak_<fecha> antes de sobreescribir).

4. Pre-configuración de Servidores MCP y Plugins
   - En %USERPROFILE%\.claude\settings.json registra el marketplace 'fabric-collection' (https://github.com/microsoft/skills-for-fabric.git) y activa 'powerbi-authoring@fabric-collection'.
   - Si existe %USERPROFILE%\.gemini, añade 'powerbi-modeling-mcp' a mcp_config.json.

5. Verificación Final
   Confirma:
     - node --version
     - powerbi-report-author --help
     - powerbi-desktop status
     - Sintaxis de hybrid.js: node --check <ruta>\powerbi-dashboard\assets\hybrid.js
     - Total de skills instaladas y operativas.

LO QUE HAGO YO POR CADA REPORTE NUEVO:
   1. Activar el formato PBIP en Power BI Desktop (Archivo > Opciones > Características de vista previa > Guardar proyectos de Power BI).
   2. Importar Deneb y HTML Content desde AppSource.
   3. Importar el visual Filtro desde archivo (%USERPROFILE%\.claude\skills\powerbi-dashboard\assets\FiltroGeneralUniversal.pbiviz).
   4. Guardar con Ctrl+S antes de pedir el dashboard.

No instales Python: este sistema no lo requiere.
```

---

## 🚀 Después de instalar

1. Abre tu `.pbip` en Power BI Desktop con los datos cargados.
2. Importa los 3 custom visuals y guarda con **Ctrl+S**.
3. En tu asistente de IA (Claude Code o Antigravity), escribe:

```
Crea un dashboard del reporte que tengo abierto
```
