# Instalar la Metodología 2 con tu agente de IA

Funciona igual en **Claude Code**, **Codex** y **Antigravity** (en Windows). Copia esta frase y pégala en tu agente:

```
Instala la Metodología 2 de Datdata siguiendo las instrucciones de https://ricardo050427.github.io/datdata/instalar.md
```

El agente ejecuta el instalador, revisa el resultado y te dice qué quedó listo. Al terminar, **cierra y vuelve a abrir tu agente**.

## Sin agente: instalador de PowerShell

Desde esta carpeta descomprimida:

```
powershell -NoProfile -ExecutionPolicy Bypass -File setup.ps1
```

O, sin descargar nada antes, desde cualquier terminal:

```
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://ricardo050427.github.io/datdata/instalar.ps1 | iex"
```

La última línea dice `RESULTADO: OK` o `RESULTADO: CON PROBLEMAS`, con la lista de lo que falló.
No borra nada: lo que reemplaza queda respaldado en `%USERPROFILE%\.datdata\respaldos\<fecha>`.

## Después de instalar

1. Abre tu reporte en Power BI Desktop y guárdalo como proyecto `.pbip`.
2. Importa Deneb y HTML Content desde AppSource, y el visual Filtro desde
   `%USERPROFILE%\.claude\skills\powerbi-dashboard\assets\FiltroGeneralUniversal.pbiviz`.
3. Guarda con **Ctrl+S** y escribe en tu agente:

```
Crea un dashboard del reporte que tengo abierto
```
