# Instalación asistida por IA

Copia el bloque de abajo y pégalo en **Claude Code** (o en cualquier agente con acceso a
terminal y sistema de archivos en tu Windows). El agente hace todo lo automatizable y te dice
exactamente qué te queda a ti.

---

```
Instálame el sistema de dashboards de Power BI "Metodología 2" (Datdata) en este Windows.
Trabaja de forma autónoma: no me pidas confirmación paso a paso, ejecuta y al final dame un
reporte de qué quedó instalado y qué falta.

CONTEXTO
Es un sistema para que tú (la IA) construyas dashboards completos de Power BI: el modelo y las
medidas DAX se crean por un MCP, y los visuales (gráficas Deneb, tarjetas HTML, barra de filtros)
los escribe un generador Node llamado hybrid.js. Todo el sistema vive en %USERPROFILE%\.claude\skills
para que esté disponible en cualquier sesión y cualquier carpeta.

PASOS

1. Node.js LTS
   Comprueba con `node --version`. Si no está, instálalo:
     winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
   Después recarga el PATH del proceso antes de seguir.

2. Las 2 CLIs de Fabric
     npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli
   Verifica que `powerbi-report-author --help` y `powerbi-desktop status` respondan.
   Si dicen "no se reconoce", el PATH no se recargó: avísame de que hay que reabrir la terminal.

3. Las skills
   Descarga y descomprime el paquete:
     https://ricardo050427.github.io/datdata/EXPORTAR.zip
   Copia TODAS las carpetas de EXPORTAR\skills\ a %USERPROFILE%\.claude\skills\
   Deben quedar 5: powerbi-dashboard, deneb-chart-generator, html-kpi-cards,
   powerbi-filter, powerbi-dax-auditor.
   Si alguna ya existía, respáldala (renómbrala con sufijo .bak_<fecha>) antes de sobrescribir.
   Verifica que exista %USERPROFILE%\.claude\skills\powerbi-dashboard\assets\hybrid.js

4. El marketplace de skills de Fabric
   Edita %USERPROFILE%\.claude\settings.json (respáldalo antes) y añade:
     "extraKnownMarketplaces": {
       "fabric-collection": {
         "source": { "source": "git", "url": "https://github.com/microsoft/skills-for-fabric.git" }
       }
     }
   Si el JSON existente no es válido, no lo toques y dímelo.

5. Comprobación final
   Confirma que existen y funcionan:
     - node --version
     - powerbi-report-author --help
     - powerbi-desktop status
     - las 5 carpetas de skills, con sus SKILL.md
     - hybrid.js parsea:  node --check <ruta>\powerbi-dashboard\assets\hybrid.js

LO QUE NO PUEDES HACER TÚ — dímelo al final, con estas palabras exactas:
   a) Instalar el plugin de Fabric. Yo tengo que escribir en Claude Code:
        /plugin marketplace add microsoft/skills-for-fabric
        /plugin install powerbi-authoring@fabric-collection
      y reiniciar Claude Code. Ese plugin trae el MCP de modelado.
   b) Instalar Power BI Desktop y activar el formato de proyecto:
      Archivo > Opciones > Características de vista previa > Power BI Project (.pbip)
   c) Importar los 3 custom visuals en CADA reporte nuevo: Deneb y HTML Content desde AppSource,
      y el Filtro desde archivo (está en
      %USERPROFILE%\.claude\skills\powerbi-dashboard\assets\FiltroGeneralUniversal.pbiviz).
      Después de importarlos hay que GUARDAR con Ctrl+S antes de pedirte un dashboard.

No instales Python: este sistema no lo usa.
```

---

## Después de instalar

1. Crea tu `.pbip` en Power BI Desktop con los datos ya cargados.
2. Importa los 3 custom visuals y guarda con **Ctrl+S**.
3. Con el reporte abierto, en Claude Code:

```
Crea un dashboard del reporte que tengo abierto
```

Y ya. Si quieres dirigir el resultado, dilo en la misma frase o después:

- "lo quiero de color verde"
- "que sean 5 páginas, el menú arriba y el filtro a la izquierda"
- "hazme un filtro personalizado que además tenga un rango de fechas"
