# SISTEMA — Dashboards Power BI automáticos por lenguaje natural

Referencia técnica completa del motor que permite a Claude Code construir dashboards
de Power BI de principio a fin: modelo, medidas, visuales Deneb, tarjetas HTML, panel
de filtros desplegable y layout global — todo desde una descripción en lenguaje natural.

> **Para Claude:** lee este archivo completo antes de construir o modificar un dashboard.
> Es la fuente de verdad de la mecánica; las skills (`powerbi-dashboard-builder`,
> `deneb-chart-generator`, `html-kpi-cards`, `powerbi-dax-auditor`) son la capa de
> metodología y disparo que apunta aquí.

---

## 1. Arquitectura: dos capas

El sistema combina DOS mecanismos que hacen cosas distintas y NO se solapan:

| Capa | Herramienta | Hace | Requiere PBI |
|------|-------------|------|--------------|
| **Modelo semántico** | MCP `powerbi-modeling-mcp` | Crear/editar tablas, medidas DAX, relaciones, refrescar particiones | **ABIERTO** |
| **Visuales y layout** | Scripts PBIR (`pbir_tool.py`) editando `visual.json` | Colocar gráficas Deneb, tarjetas HTML, slicers, botones, bookmarks, grid layout | **CERRADO** |

**Constraint clave (no negociable):** el MCP necesita Power BI ABIERTO; editar los
archivos PBIR necesita Power BI CERRADO (PBI bloquea/relee los archivos al guardar).
El wrapper `pbi.ps1` gestiona el ciclo cerrar→editar→abrir con `pbi-refresh`.

Por eso el MCP **solo** se usa para el modelo y las medidas. Todo lo visual (que es
donde está el valor estético) se hace por archivos. El MCP no puede colocar un visual
Deneb ni construir un panel de filtros — solo el pipeline de archivos puede.

---

## 2. Tooling (carpeta de este archivo)

`C:\Users\lanfa\.claude\code\primera sesion\`

| Archivo | Rol |
|---------|-----|
| `pbir_tool.py` | CLI principal. Lee/escribe `visual.json`, páginas, bookmarks. |
| `pbir_templates.py` | Fábricas de `visual.json` válidos (card, deneb, html_card, slicer, action_button, background_rect, …). Esquemas derivados de visuales reales, no inventados. |
| `pbir_layout.py` | Clase `Grid` (cols/rows/margin/gutter → x/y/w/h exactos). Elimina aritmética a ciegas. |
| `pbi.ps1` | Wrapper PowerShell. Config-driven (lee `pbi.config.json`). Gestiona el ciclo abrir/cerrar PBI. |
| `pbi.config.json` | Proyecto activo (rutas .Report / .SemanticModel / .tmdl de medidas). Generado con `pbi-init`. |

**Ejecutar Python con `py`** (el launcher, Python 3.14), NO `python`/`python3`.

---

## 3. Empezar un proyecto nuevo

```powershell
cd "C:\Users\lanfa\.claude\code\primera sesion"
.\pbi.ps1 pbi-init "C:\ruta\a\MiReporte.pbip"
```

`pbi-init` autodetecta las carpetas hermanas `.Report\definition` y `.SemanticModel`,
encuentra el `.tmdl` de la tabla de medidas, y escribe `pbi.config.json`. A partir de
ahí, todos los comandos (`list-pages`, `build-dashboard`, `pbi-refresh`, …) operan
sobre ese proyecto. Para cambiar de proyecto: correr `pbi-init` con otro `.pbip`.

**Paso obligatorio después de `pbi-init` — detectar GUIDs de custom visuals:**

```powershell
.\pbi.ps1 detect-custom
```

Esto devuelve los GUIDs reales del proyecto (Deneb, HTML Content, u otros custom visuals
instalados). Los GUIDs son distintos por versión de visual y por instalación. **No asumir**
los GUIDs del proyecto Tractchun — siempre correr `detect-custom` para el proyecto nuevo
y usar los que devuelve. Sin los GUIDs correctos, `build-dashboard` genera un visual
Deneb/HTML vacío que PBI no reconoce.

---

## 4. Ciclo de trabajo

```powershell
# Modelo / medidas (PBI ABIERTO, via MCP) — crear tablas, medidas DAX, relaciones.

# Visuales (PBI CERRADO, via archivos):
.\pbi.ps1 pbi-refresh build-dashboard --spec mi_dashboard.json
#   ↑ cierra PBI → escribe los visual.json → reabre PBI

# Inspección sin tocar PBI:
.\pbi.ps1 list-pages
.\pbi.ps1 list-visuals --page "Pagina 1"
.\pbi.ps1 validate-page --page "Pagina 1 Pro"   # lint pre-apertura
.\pbi.ps1 fix-page      --page "Pagina 1 Pro"   # corrige lo que el lint detecta
```

`build-dashboard` corre un **lint automático** al final y devuelve `errors:[]` y
`lint:[]` cuando todo está limpio. Si `lint` trae items, son props/keys que PBI
rechazaría al abrir — corregir con `fix-page` o ajustando la plantilla.

---

## 5. Spec de `build-dashboard` (referencia completa)

Un dashboard es un JSON. Estructura:

```jsonc
{
  "page": "Pagina 1 Pro",        // página existente (por nombre o id)  …O…
  "newPage": "Ventas 2026",      // crea una página nueva con este nombre
  "clear": true,                 // borra visuales existentes antes de construir
  "canvas": { "width": 1280, "height": 720 },
  "grid":   { "cols": 12, "rows": 8, "margin": 16, "gutter": 10 },
  "visuals": [ /* … */ ],
  "filterPanel": { /* opcional, ver §7 */ }
}
```

Cada visual se posiciona con **`at`** (grid: col/row/colspan/rowspan) o **`abs`**
(píxeles: x/y/w/h). El grid es la forma preferida — alinea todo automáticamente.

### Tipos de visual soportados

| `type` | Campos | Notas |
|--------|--------|-------|
| `card` | `entity`, `measure` | tarjeta nativa (evitar; preferir `html_card`) |
| `html_card` | `entity`, `measure` | **HTML Content** — mide una medida DAX que devuelve HTML (§6) |
| `deneb` | `dataset:[{entity,property,kind}]`, `vega:{…}` | **Deneb** — Vega-Lite (§8) |
| `bar_chart` / `column_chart` / `line_chart` | `category`, `y`, `series?`, `color_id?` | nativos (fallback) |
| `donut_chart` / `pie_chart` | `category`, `y` | nativos |
| `navara_filter` | `fields:[{entity,column}]`, `accent?` | **Barra de filtros Navara** — método estándar de filtros (§7) |
| `slicer` | `entity`, `column`, `mode?`, `title?` | segmentador nativo (fallback) |
| `table` | `fields:[…]` | tabla nativa (preferir Deneb o `html_card` para tablas, §8) |
| `textbox` | `text`, `font_size?`, `color?`, `bold?` | texto |
| `action_button` | `text`, `bookmark_id`, `bg?`, `text_color?`, `font_size?`, `radius?` (def 8), `shadow?` (def true), `border?`, `is_hidden?` | botón con hover/pressed auto-derivados, esquinas redondeadas y sombra (§9) |
| `background_rect` | `color?`, `border?`, `is_hidden?` | rectángulo de fondo (para paneles) |

**Regla de diseño (no negociable):**
- KPIs / tarjetas → SIEMPRE `html_card` (§6).
- Gráficas y tablas interactivas → SIEMPRE `deneb` (§8).
- Filtros → SIEMPRE `navara_filter` (§7).
- Botones (navegación entre páginas, abrir/cerrar paneles) → `action_button` nativo (§9).
- Los visuales nativos (card, barChart, slicer, table) quedan solo para mapas
  geográficos, como fallback técnico, o si el analista los pide explícitamente.

---

## 6. HTML Content (`html_card`) — orientación y tema

La medida DAX devuelve un string HTML completo; PBI la evalúa en el contexto de filtro,
así que las tarjetas reaccionan a slicers. La medida se escribe en el `.tmdl` de la
tabla de medidas (PBI CERRADO) o via MCP (PBI ABIERTO).

**Orientación = forma del contenedor.** El CSS `body` debe coincidir con el espacio:
- Tira superior ancha y baja → `display:flex; flex-direction:row` (tarjetas en fila).
- Sidebar alto y angosto (≈200px × alto completo) → `display:flex; flex-direction:column`.

**Tema = fondo de la página.** Página clara → tarjetas claras (`#fff`, texto oscuro).
Página oscura → tarjetas oscuras. No mezclar (error cometido: card oscura en página clara).

**⚠️ Bug TMDL unicode:** los escapes `Ó`, `ó`, etc. dentro de un string DAX en
un archivo `.tmdl` aparecen **literalmente** en el HTML renderizado (PBI no los resuelve).
→ En textos HTML usar ASCII plano ("SATISFACCION", "Dias") o entidades HTML (`&#211;`).
Los nombres de medidas DAX sí pueden llevar acentos; el problema es solo el texto dentro
del string HTML.

**⚠️ `html { height:100% }` es obligatorio en TODA medida HTML Content.** Sin él, el
`body { height:100% }` referencia al `html` cuya altura es `auto` (colapsa al contenido),
dejando un espacio vacío al fondo del visual que crece al redimensionar el contenedor.
La primera línea del bloque CSS de cualquier medida HTML debe ser siempre:

```css
html,body { height:100%; overflow:hidden; }
```

**Variedad de diseño — no repetir la misma tarjeta en cada reporte.** El esqueleto
(número grande + label + badge delta) es reutilizable, pero cada dashboard debe traer
adiciones propias al caso: una mini-barra de progreso vs meta, un sparkline embebido,
un semáforo de estado, un texto de contexto. La base puede parecerse; los detalles que
ayudan a ESE reporte específico cambian. Tarjetas idénticas en todos los proyectos =
señal de plantilla genérica, justo lo que hay que evitar.

**¿Una medida HTML o varias?** Decisión de diseño, no automática:
- **Una sola medida** (varias tarjetas dentro de un mismo HTML con flex) → cuando los KPIs
  comparten tema/escala y van juntos en una tira o sidebar. Menos visuales, layout estable.
- **Varias medidas** (un `html_card` por KPI) → cuando un KPI necesita ir en otra zona del
  canvas, tener tamaño distinto, o reaccionar a un contexto de filtro propio. También
  cuando un KPI es claramente protagonista y merece su propio contenedor grande.

Claude decide según el layout y la intención; no hay regla fija de "siempre 1" ni "siempre N".

Medidas HTML disponibles en el proyecto Tractchun (todas usan `flex-direction:column` y
son responsive con `clamp()`/`vh`/`vw`): `KPI Cards Light HTML` (columna, clara),
`KPI Cards Dark HTML` (columna, oscura), `KPI Cards Vertical HTML` (columna, clara).

Ver la skill `html-kpi-cards` para plantillas de tarjetas, semáforos, tablas y badges.

---

## 7. Filtros — barra Navara (`navara_filter`, método estándar)

**Todo filtro del dashboard se hace con el custom visual Navara.** Un solo visual maneja
N columnas: muestra los primeros 3 campos como pills desplegables + un panel "Más Filtros"
para el resto, con búsqueda, chips y limpiar individual/global. Filtra el resto de la
página vía `applyJsonFilter` (cross-filter nativo de PBI → gráficas Deneb y tarjetas HTML
reaccionan).

Código fuente del visual: `C:\Users\lanfa\.claude\code\primera sesion\navarafilter\`
(TypeScript + LESS). Paquete listo: `navarafilter\dist\navarafilter…1.1.0.0.pbiviz`.
GUID: `navarafilterA1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6`.

### 7.1 En el spec

```jsonc
{
  "type": "navara_filter",
  "id": "navara_bar",
  "abs": { "x": 0, "y": 0, "w": 1280, "h": 58 },  // top bar full-width
  "z": 6000,
  "accent": "#7C3AED",                              // = color de acento del dashboard
  "fields": [
    { "entity": "f_Tickets",    "column": "Categoría" },
    { "entity": "f_Tickets",    "column": "Tipo" },
    { "entity": "f_Tickets",    "column": "Severidad" },
    { "entity": "d_Calendario", "column": "Mes" }     // 4º+ campo → va al panel "Más Filtros"
  ]
}
```

Cada `field` se mapea a una proyección de columna en el data role `category`. El visual
lee el nombre tabla/columna del `queryName` — no hay config extra. Conviene ponerlo
arriba con `z` alto y fondo/borde del contenedor ocultos (la plantilla ya lo hace) para
que los dropdowns se dibujen sobre las gráficas.

### 7.2 Coherencia con el dashboard (obligatorio)

- **Color:** `accent` debe ser el color de acento del dashboard (el mismo que usan
  tarjetas, gráficas y botones). El visual deriva solo las variantes (hover más oscuro,
  fondo claro). Sin `accent` queda morado `#7C3AED` por defecto — solo válido si la
  paleta del dashboard ES morada. **Nunca dejar el filtro con un color que no combina.**
- **Posición / orientación:** la barra es horizontal (pills en fila). Va como tira
  superior ancha y baja (alto ~50–58px). Para un dashboard de paleta y layout horizontal
  encaja directo. Si el dashboard es de sidebar vertical, la barra superior sigue siendo
  el lugar correcto para los filtros (no forzar Navara a una columna angosta — no está
  pensado para vertical).
- **Importante:** se usan SOLO los apartados de filtros de Navara. Los tabs de navegación
  que el visual dibuja arriba son decorativos; **NO** se usan para saltos de página.
  La navegación entre páginas se hace con `action_button` nativos (§9).

### 7.3 El usuario debe importar el `.pbiviz` (instrucciones exactas a entregar)

El custom visual no viaja dentro del `.pbip`; hay que importarlo una vez por reporte.
Cuando un dashboard use `navara_filter`, entregar al analista estos pasos textuales:

> 1. En Power BI Desktop, con el reporte abierto, ir a la cinta **Inicio** → grupo
>    *Insertar* → **"Más objetos visuales"** → **"Importar desde archivo"**.
> 2. Navegar a `C:\Users\lanfa\.claude\code\primera sesion\navarafilter\dist\` y abrir
>    `navarafilterA1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6.1.1.0.0.pbiviz`.
> 3. Aceptar la advertencia de seguridad → aparece "Importación correcta".
> 4. (Solo si se actualizó el visual) reimportar el mismo archivo: PBI reemplaza la
>    versión en todas las instancias por el GUID, sin perder los campos ya asignados.

El **color** ya no requiere reimportar: se setea por instancia desde `accent` en el spec,
o manualmente en el panel **Formato → Apariencia → Color de acento**.

### 7.4 Verificar los campos en PBI

Tras `build-dashboard`, el visual queda con los 4 campos en el data role. Para
comprobarlo: seleccionar el visual → panel **Datos** muestra los campos en "Campos de
filtro". Para probar la interacción: entrar en **modo de enfoque** (ícono de expandir
abajo del visual seleccionado), abrir un pill, elegir un valor → los demás visuales se
filtran. El pill activo queda con borde de acento.

### 7.5 Alternativa nativa (legacy `filterPanel`) — solo si Navara no aplica

El motor aún soporta un panel flotante de slicers nativos con bookmarks. Quedó como
fallback (p. ej. si el usuario rechaza custom visuals). No es el método por defecto.

```jsonc
"filterPanel": {
  "filtrosButton": { "abs":{x,y,w,h}, "text":"Filtros", "bg":"#6A0DAD", "text_color":"#FFFFFF", "font_size":11 },
  "cerrarButton":  { "abs":{x,y,w,h}, "text":"Cerrar",  "bg":"#9B59B6", "text_color":"#FFFFFF", "font_size":10 },
  "background":    { "abs":{x,y,w,h}, "color":"#FAF7FF", "border":"#6A0DAD" },
  "slicers": [ { "abs":{x,y,w,h}, "entity":"f_Tickets", "column":"Categoría", "title":"Categoría", "mode":"Dropdown" } ]
}
```

Genera 2 bookmarks (`bm_panel_open_*`, `bm_panel_close_*`, `applyOnlyToTargetVisuals:true`),
fondo + slicers ocultos al inicio. Slicers: alto ≥ 90px para que no se corten.

---

## 8. Deneb (`deneb`) — estética + interactividad

`dataset` es la lista de campos que alimentan el visual; en la spec Vega se referencian
por su `property` (= `nativeQueryRef`). `vega` es la spec Vega-Lite (se serializa y
empaqueta como literal en el `visual.json`).

**Interactividad (hover + click) — patrón obligatorio para "funcionalidad":**

```python
# params: uno para hover (mouseover), uno para selección (click)
"params": [
  {"name":"hov_x", "select":{"type":"point","on":"mouseover","fields":["Categoría"]}},
  {"name":"sel_x", "select":{"type":"point","fields":["Categoría"]}}
]
# opacity condicional: seleccionado=1, hover=0.85, resto=0.25
"opacity": {
  "condition":[ {"param":"sel_x","value":1}, {"param":"hov_x","empty":false,"value":0.85} ],
  "value":0.25
}
# y habilitar selección en usermeta:
"usermeta": {"deneb": {"interactivity": {"tooltip":true,"selection":true,"dataPointLimit":50}}}
```

`gen_pagina1_pro.py` tiene los helpers `PARAMS()` y `OPACITY_COND()` reutilizables y 5
gráficas de ejemplo (barras, columnas, donut, línea, barras con degradado) listas para
copiar. Ver la skill `deneb-chart-generator` para plantillas por tipo y lectura de
imágenes de referencia.

**Cross-filter a TODA la página (requisito de "funcional").** No basta con que la gráfica
se resalte a sí misma. El objetivo es: **clic en una barra → todas las demás gráficas Y
las tarjetas HTML cambian** a ese contexto. Mecánica: `selection:true` en `usermeta` +
el param `point` de click hacen que PBI propague la selección como cross-filter nativo a
todos los visuales de la página. Las tarjetas HTML reaccionan porque son medidas DAX
evaluadas en el contexto de filtro. Verificar siempre este comportamiento tras construir:
si al hacer clic en una barra las tarjetas no cambian, falta `selection:true` o el param
de click. (El cross-highlight visual dentro del propio chart es `OPACITY_COND`; el
cross-filter al resto de la página es `selection:true` — son cosas distintas, hacen falta
las dos.)

**Tablas en Deneb.** Cuando el dashboard pide una tabla de detalle, hay dos caminos y
Claude elige:
- **Deneb** (Vega-Lite con marcas `text` en grid) → cuando la tabla debe **cross-filtrar**
  (clic en una fila filtra el resto) o llevar mini-visuales embebidos (barras en celda,
  heatmap). Más versátil e interactiva.
- **`html_card`** (tabla HTML con semáforos/badges) → cuando es una tabla de lectura
  estática con formato condicional rico y no necesita disparar filtros. Más simple.

**Coherencia estética:** misma paleta de acento, tipografía (Segoe UI) y radios que las
tarjetas HTML, el filtro Navara y el resto del dashboard. La paleta morada es solo el
default; usar la del dashboard en TODOS los visuales (incluido el `accent` de Navara, §7).

---

## 9. Estética de negocio y layout global

Estos son dashboards de **negocio**: la estructura y la información que se muestra son
tan importantes como que se vea bien. Un dashboard bonito que no responde la intención
del analista está mal.

### 9.1 Layout (cuando Claude decide el acomodo)

- **Lo más importante primero:** el KPI o visual que responde la intención va arriba/izquierda.
- **Controles agrupados:** los filtros van en la barra Navara (§7), normalmente como tira
  superior. Nunca slicers dispersos por el canvas.
- **Sidebar de KPIs** (columna vertical) libera la fila superior para una gráfica grande.
- **Respirar:** márgenes y gutters consistentes (el grid los garantiza). Sin decoración sin propósito.
- **Jerarquía de información:** agrupar lo relacionado, separar lo distinto; el ojo debe
  recorrer el dashboard en el orden en que importa el negocio.

### 9.2 Regla de estética — que NO parezca "hecho por IA"

- **Sin emojis.** Nada de 🎉📊✅🚀 ni similares en títulos, tarjetas, labels ni texto.
- **Glifos funcionales sí, decorativos no.** Las flechas de delta `▲ ▼` (`&#9650;`/`&#9660;`)
  y un `•` separador son iconografía estándar de BI y están permitidas porque comunican
  un dato. Iconos decorativos sin función, no.
- **Texto sobrio.** Labels concretos del dominio ("Tickets resueltos", "Margen %"), no
  frases de relleno entusiastas ("¡Mira estos increíbles resultados!").
- **Una sola paleta de acento** en TODO: tarjetas, gráficas, tablas y el `accent` de
  Navara comparten el mismo color. Tipografía Segoe UI, radios consistentes.

### 9.3 Botones (nativos de PBI)

Los botones (navegación entre páginas, abrir/cerrar el panel legacy) son `action_button`
nativos, lo más cuidados posible: color de fondo = acento del dashboard o un neutro de la
paleta, texto contrastado, esquinas redondeadas, tamaño táctil (alto ≥ 28px). Coherentes
entre sí y con el resto. Disparan bookmarks (navegación o paneles); el cross-filtrado NO
se hace con botones sino con la interacción de las gráficas (§8) y Navara (§7).

### 9.4 Multi-página

El sistema trabaja **una página a la vez**. Un dashboard de varias páginas = varios specs
(uno por página), cada uno con su `build-dashboard`. Patrón recomendado:

- Un archivo de spec por página (`pagina_ventas.json`, `pagina_operaciones.json`, …),
  cada uno con `"page"` o `"newPage"` apuntando a la página correspondiente.
- Construir y revisar página por página: armar una, verificar en PBI, pasar a la siguiente.
  No hace falta reconstruir todas en cada iteración.
- **Cada página lleva su propia barra Navara** con los campos relevantes a esa página
  (el filtro de un custom visual es por página; no se sincroniza solo entre páginas).
- La navegación entre páginas se hace con `action_button` nativos + bookmarks o con la
  navegación de páginas de PBI — **no** con los tabs decorativos de Navara.
- Mantener paleta, tipografía y estilo de tarjetas/gráficas idénticos entre páginas para
  que el reporte se sienta como un solo producto.

Layout de referencia (sidebar KPI + grid de gráficas + filtros) está implementado en
`gen_pagina1_pro.py` / `pagina1_pro.json`.

---

## 10. Gotchas (errores ya resueltos — no repetir)

| Síntoma | Causa | Fix |
|---------|-------|-----|
| "propiedad 'shadow'/'size'/'blur' adicional… no se pudo resolver" | props inválidas en `dropShadow` PBIR | Solo usar `show,color,position,preset,angle,transparency` (whitelist en `pbir_tool._VALID_PROPS`) |
| "propiedad 'howCreated' adicional" | clave de UI, no de archivo | No incluir `howCreated` en `visual` |
| `SATISFACCIÓN` sale como `SATISFACCIÓN` | escape unicode en string DAX dentro de `.tmdl` | ASCII plano o entidades HTML en el texto HTML |
| Espacio vacío al fondo del HTML Content que crece al redimensionar | `html` no tiene `height:100%` | Primera regla CSS: `html,body{height:100%;overflow:hidden}` — siempre, sin excepción |
| Tarjeta oscura en página clara | medida HTML equivocada | Igualar tema al fondo de la página |
| Tarjetas con tamaño fijo que no escalan al redimensionar el contenedor | CSS con px fijos | Usar `clamp(min, preferred_en_vh_o_vw, max)` para todos los font-size, padding y gap |
| Slicer cortado | rowspan/alto insuficiente | ≥ 90px de alto por slicer |
| Gráfica sin reacción al mouse | params solo de click | Añadir param `mouseover` + `OPACITY_COND` (§8) |
| Clic en una barra no cambia las tarjetas | falta `selection:true` en `usermeta` o el param `point` de click | Habilitar `interactivity.selection:true` + param click (§8). El cross-filter a la página es distinto del cross-highlight interno |
| Barra de filtros morada en dashboard de otra paleta | `navara_filter` sin `accent` | Pasar `accent:"#hex"` = color del dashboard en el spec (§7.2) |
| Navara aparece vacío / "Importa el visual" | `.pbiviz` no importado en ese reporte | El analista debe importar el `.pbiviz` (§7.3); es por reporte |
| Páginas duplicadas con mismo nombre | builds repetidos creando página nueva | Usar `"page"` (existente) no `"newPage"`; borrar duplicados con `delete-page --page <id>` |
| Visual Deneb/HTML Content vacío o no reconocido | GUIDs del proyecto anterior reutilizados | Correr `detect-custom` al inicio de cada proyecto nuevo |
| `python: command not found` | launcher | Usar `py` |

El lint (`validate-page` / auto en `build-dashboard`) atrapa las dos primeras
automáticamente antes de abrir PBI.

---

## 11. Flujo end-to-end para "vamos a hacer un dashboard nuevo"

1. `pbi-init` con el `.pbip` del proyecto.
2. `detect-custom` — obtener GUIDs reales de Deneb y HTML Content del proyecto.
3. Si el dashboard llevará filtros: indicar al analista que **importe el `.pbiviz` de
   Navara** (instrucciones exactas en §7.3). Pedirle confirmación de "Importación correcta"
   antes de correr el build que use `navara_filter`.
4. Auditar modelo (`powerbi-dax-auditor`) si PBI está abierto.
5. Preguntar la **intención** (qué responde el dashboard, qué se ve primero) y la **paleta**
   (define el `accent` de Navara y el color de gráficas/tarjetas).
6. Modelo + medidas DAX via MCP (PBI abierto). Medidas HTML al `.tmdl` o MCP.
7. Diseñar el spec **de la página** (grid, html_cards con variedad, deneb con cross-filter,
   navara_filter con `accent` = paleta). Una página = un spec.
8. `pbi-refresh build-dashboard --spec X.json` (cierra→escribe→abre).
9. Revisar en PBI; verificar cross-filter (clic en barra → tarjetas cambian) y color del
   filtro. Iterar correcciones en lenguaje natural.
10. ¿Más páginas? Repetir 6–9 por cada página, manteniendo estilo y paleta.

---

## 12. Spec de ejemplo completo (referencia funcional verificada)

Este spec genera el layout barra Navara superior + sidebar-KPIs + gráficas con
cross-filter. Usar como punto de partida para cualquier dashboard nuevo. El `accent` de
Navara y los colores de las gráficas comparten la paleta del dashboard.

```jsonc
{
  "page": "Pagina 1 Pro",
  "clear": true,
  "canvas": { "width": 1280, "height": 720 },
  "grid":   { "cols": 12, "rows": 8, "margin": 16, "gutter": 10 },
  "visuals": [
    // Barra de filtros Navara — tira superior full-width (color = paleta del dashboard)
    {
      "type": "navara_filter", "id": "navara_bar",
      "abs": { "x": 0, "y": 0, "w": 1280, "h": 56 }, "z": 6000,
      "accent": "#6A0DAD",
      "fields": [
        { "entity": "f_Tickets",    "column": "Categoria" },
        { "entity": "f_Tickets",    "column": "Tipo" },
        { "entity": "f_Tickets",    "column": "Severidad" },
        { "entity": "d_Calendario", "column": "Mes" }
      ]
    },
    // Sidebar de KPIs — columna izquierda (debajo de la barra)
    {
      "type": "html_card",
      "abs": { "x": 0, "y": 64, "w": 210, "h": 648 },
      "entity": "DAX Medidas",
      "measure": "KPI Cards Vertical HTML"
    },
    // Gráfica principal con cross-filter (selection:true) — a la derecha del sidebar
    {
      "type": "deneb",
      "name": "Tickets por Categoria",
      "abs": { "x": 218, "y": 64, "w": 600, "h": 320 },
      "dataset": [
        { "entity": "f_Tickets", "property": "Categoria", "kind": "Column" },
        { "entity": "DAX Medidas", "property": "Total Tickets", "kind": "Measure" }
      ],
      "vega": { /* Vega-Lite con PARAMS() + OPACITY_COND() + usermeta.interactivity.selection:true */ }
    }
    // ... más gráficas Deneb; todas con cross-filter habilitado
  ]
}
```

El spec completo funcional vive en `gen_pagina1_pro.py` (genera el JSON en memoria y
llama a `build_dashboard`). Ver ese archivo como plantilla viva para nuevos proyectos.
El spec mínimo de Navara verificado está en `filtros_test.json`.

---

## 13. Patrones avanzados — Fase 1 (delta badge) y Fase 2 (insight text)

### Fase 1 — KPIs con delta badge (cambio vs período anterior)

Un badge verde ▲ / rojo ▼ muestra cuánto varió la métrica respecto a otro período.
El badge aparece solo cuando hay un período seleccionado; si no, la tarjeta muestra el
total sin badge (comportamiento honesto — no mostrar delta ficticio).

**CSS del badge (añadir al bloque de estilos de la tarjeta):**

```css
.footer { display:flex; align-items:center; justify-content:space-between; gap:4px; }
.lbl    { font-size:clamp(8px,2vh,12px); color:#7B5EA7; font-weight:500; }
.bu     { font-size:clamp(7px,1.5vh,11px); font-weight:700; padding:2px 7px;
          border-radius:20px; background:#e6f9f0; color:#1a7a4a; white-space:nowrap; }
.bd     { font-size:clamp(7px,1.5vh,11px); font-weight:700; padding:2px 7px;
          border-radius:20px; background:#fce8ec; color:#c0142d; white-space:nowrap; }
```

**HTML de la card con badge (reemplaza el par `val` + `lbl` anteriores):**

```html
<div class='val'>123</div>
<div class='footer'>
  <div class='lbl'>Descripcion KPI</div>
  <span class='bu'>▲ 12.5%</span>   <!-- o .bd para negativo -->
</div>
```

**DAX — patrón con tabla de calendario (badges siempre visibles):**

La clave es auto-detectar el último mes con datos cuando no hay selección. Así los badges
aparecen desde que se abre el dashboard, sin necesidad de que el usuario elija un período.

```dax
VAR _selected_mes = SELECTEDVALUE(d_Calendario[#Mes])

// Auto-detect: último año/mes que tenga datos (SUMMARIZE solo devuelve períodos con filas)
VAR _periodos  = SUMMARIZE(FactTable, d_Calendario[#Año], d_Calendario[#Mes])
VAR _auto_anio = MAXX(_periodos, d_Calendario[#Año])
VAR _auto_mes  = MAXX(FILTER(_periodos, d_Calendario[#Año] = _auto_anio), d_Calendario[#Mes])

// Resolver período: selección del slicer o auto-detectado
VAR _mes  = IF(ISBLANK(_selected_mes), _auto_mes, _selected_mes)
VAR _anio = IF(ISBLANK(_selected_mes), _auto_anio,
               COALESCE(SELECTEDVALUE(d_Calendario[#Año]), _auto_anio))

// Período anterior (enero → diciembre del año anterior)
VAR _mes_p  = IF(_mes > 1, _mes - 1, 12)
VAR _anio_p = IF(_mes > 1, _anio, _anio - 1)

// Siempre comparar período puntual (no fallback a grand total)
VAR _v  = CALCULATE([Medida], d_Calendario[#Mes]=_mes,   d_Calendario[#Año]=_anio)
VAR _vp = CALCULATE([Medida], d_Calendario[#Mes]=_mes_p, d_Calendario[#Año]=_anio_p)
VAR _d  = DIVIDE(_v - _vp, _vp, 0)

// Badge — vacío solo si no existe mes anterior (primer mes del dataset)
VAR _b  = IF(ISBLANK(_vp), "",
             IF(_d >= 0,
                "<span class='bu'>&#9650; " & FORMAT(ABS(_d),"0.0%") & "</span>",
                "<span class='bd'>&#9660; " & FORMAT(ABS(_d),"0.0%") & "</span>"))
```

**Nota:** cuando el usuario selecciona un mes, las KPI cards muestran ese mes y el badge
vs el mes anterior. Cuando no hay selección, muestran el último mes disponible en los datos
con el badge automático. El comportamiento es coherente en ambos casos.

**DAX — patrón sin tabla de calendario (vs promedio global):**

```dax
// Útil cuando no hay d_Calendario o se quiere comparar vs la media de todos los períodos
VAR _v   = [Medida]           // valor en el contexto actual (puede tener filtros)
VAR _avg = CALCULATE([Medida], REMOVEFILTERS())  // media sobre todos los datos
VAR _d   = DIVIDE(_v - _avg, _avg, 0)
VAR _b   = IF(_d >= 0,
              "<span class='bu'>&#9650; " & FORMAT(ABS(_d),"0.0%") & " vs promedio</span>",
              "<span class='bd'>&#9660; " & FORMAT(ABS(_d),"0.0%") & " vs promedio</span>")
```

**Delta invertido** (para métricas donde bajar es bueno, ej. "días de resolución"):

```dax
VAR _d = DIVIDE(_vp - _v, _vp, 0)   // invertido: si el valor bajó → delta positivo → badge verde
```

**Nota de diseño — dónde ubicar el badge en el spec:**
El `html_card` de KPIs con delta ocupa el mismo espacio que el de KPIs simples
(sidebar vertical, `colspan:2 rowspan:8`). No requiere más espacio — el `.footer`
reemplaza el `.lbl` con un flex row de dos hijos.

**Medida de referencia en Tractchun:** `KPI Cards Delta HTML` en la tabla `DAX Medidas`.

---

### Fase 2a — Insight text como `html_card` separado (opción básica)

Medida que devuelve HTML con el texto de insight. Se coloca como `html_card` debajo de la gráfica.
Limitación: tiene fondo propio y no se integra visualmente con el chart.

Ver `html-kpi-cards/SKILL.md` para la plantilla CSS/HTML de esta variante.

**Medidas de referencia en Tractchun:** `Insight Categorias HTML` (con HTML/CSS)
y `Insight Categorias Texto` (solo texto, para Deneb).

---

### Fase 2b — Insight text DENTRO del Deneb como subtitle ⭐ (integración total)

La forma de integración correcta: el texto aparece como una línea de subtítulo directamente
encima del área de la gráfica, sin fondo, sin separación visual. Se logra con una capa
`text` mark dentro del spec Vega-Lite del Deneb.

**Por qué NO se puede usar `VALUES()` directamente en la medida:**
Si `Insight Texto` usa `VALUES(DimTabla[Campo])`, en el contexto de cada fila del dataset
Deneb (que tiene una categoría por fila), la medida se evalúa filtrada por esa categoría →
el líder siempre sería "la categoría de esta fila con 100% del total" (incorrecto).

**Solución — patrón GROUPBY + CALCULATETABLE + REMOVEFILTERS:**
El `GROUPBY` con `CALCULATETABLE(f_Tickets, REMOVEFILTERS(f_Tickets[Categoría]))` crea
un resumen limpio de TODAS las categorías ignorando el row context del Deneb. El resultado
es el MISMO texto para todas las filas → en Vega-Lite `aggregate: "min"` devuelve ese texto.

```dax
Mi Insight Texto =
VAR _tbl = GROUPBY(
    CALCULATETABLE(FactTable, REMOVEFILTERS(FactTable[Dimension])),
    FactTable[Dimension],
    "T", SUMX(CURRENTGROUP(), [Metrica])  // o SUMX(CURRENTGROUP(), 1) para COUNTROWS
)
VAR _tot = SUMX(_tbl, [T])
VAR _n   = COUNTROWS(_tbl)
VAR _t1  = MAXX(TOPN(1, _tbl, [T], DESC), [T])
VAR _d1  = MAXX(FILTER(_tbl, [T] = _t1), FactTable[Dimension])
VAR _p1  = FORMAT(DIVIDE(_t1, _tot), "0%")
VAR _top3 = SUMX(TOPN(3, _tbl, [T], DESC), [T])
VAR _p3  = FORMAT(DIVIDE(_top3, _tot), "0%")
RETURN _d1 & " lidera con " & _p1 & " del total, las 3 primeras concentran " & _p3 & " de " & _n & " categorias"
```

**Cómo incluirlo en el spec Deneb del dashboard:**

1. Agregar la medida al `dataset` del Deneb:
```jsonc
{
  "entity": "DAX Medidas",
  "property": "Mi Insight Texto",
  "kind": "Measure"
}
```

2. En el spec Vega-Lite, cambiar `usermeta.deneb.combination.type` a `"layer"` (obligatorio — Deneb ignora silenciosamente un spec `layer` si este campo sigue en `"none"`), y convertir la gráfica a `layer` añadiendo padding:
```jsonc
{
  "$schema": "...",
  "usermeta": {
    "deneb": {
      "combination": { "type": "layer" },  // CRÍTICO: cambiar de "none" a "layer"
      "interactivity": { "tooltip": true, "selection": true, "dataPointLimit": 50 }
    }
  },
  "padding": { "top": 38, "bottom": 4, "left": 4, "right": 4 },
  "layer": [
    {
      "description": "insight-subtitle",
      "mark": {
        "type": "text",
        "align": "left",
        "baseline": "top",
        "fontSize": 11,
        "color": "#888",
        "fontStyle": "italic",
        "fontFamily": "Segoe UI",
        "clip": false
      },
      "encoding": {
        "text": {
          "field": "Mi Insight Texto",
          "aggregate": "min",
          "type": "nominal"
        }
      }
    },
    {
      /* aquí va el mark original de la gráfica (bar, line, etc.) */
    }
  ]
}
```

**Por qué `"aggregate": "min"` en el text mark:** todas las filas tienen el mismo insight
(GROUPBY lo garantiza), así que min/max da el mismo resultado — es el único aggregation
que Vega-Lite acepta para mostrar un valor de campo en un `text` mark sin segmentar.

**Medida de referencia en Tractchun:** `Insight Categorias Texto` en la tabla `DAX Medidas`.

---

### Registrando nuevas medidas HTML en proyectos distintos a Tractchun

Cuando se crea un proyecto nuevo, las medidas de Fase 1 y Fase 2 se escriben en el
`.tmdl` de la tabla de medidas del proyecto (ruta en `pbi.config.json → measuresTmdl`),
adaptando:
1. Los nombres de las medidas base (`[Total Tickets]` → `[Ventas]`, etc.)
2. La tabla de calendario y columnas (`d_Calendario[#Mes]` → la tabla equivalente del proyecto)
3. La dimensión del insight (`f_Tickets[Categoría]` → la dimensión relevante del proyecto)

Los CSS, la estructura HTML y el patrón DAX son **idénticos** — solo cambian los
nombres de tablas/medidas/columnas.
