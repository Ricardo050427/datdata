# SISTEMA — Dashboards Power BI híbridos (skills de Fabric + custom visuals)

Referencia técnica del flujo **híbrido** (Metodología 2) con el que Claude Code construye
dashboards de Power BI de principio a fin: modelo, medidas, gráficas Deneb, tarjetas HTML,
barra de filtros y layout — todo desde una descripción en lenguaje natural.

> **Para Claude:** lee este archivo antes de construir o modificar un dashboard. El pipeline
> (posicionar, cargar datos, navegación, validar) lo dan las **skills de Fabric**; los
> visuales los dibujan **custom visuals** (Deneb, HTML Content, Filtro) escritos por el
> generador Node `hybrid.js`. Las skills propias (`deneb-chart-generator`, `html-kpi-cards`,
> `powerbi-filter`, `powerbi-dax-auditor`) codifican los patrones de cada visual.

> **Nota de versión:** este flujo **reemplaza** al motor Python anterior (`pbir_tool.py` /
> `pbi.ps1` / `build-dashboard`). Ya no se usa Python ni la extensión MCP de VS Code. El MCP
> de modelado viene con el plugin de Fabric (vía `npx`).

---

## 1. Arquitectura: dos capas

| Capa | Herramienta | Hace | Power BI |
|------|-------------|------|----------|
| **Modelo semántico** | MCP `powerbi-modeling-mcp` (viene con el plugin de Fabric) | Crear/editar tablas, medidas DAX, relaciones, refrescar particiones | **ABIERTO** |
| **Visuales y layout** | Skills de Fabric + generador Node `hybrid.js` + 2 CLIs de Fabric | Escribir los visuales (Deneb/HTML/Filtro) en la cuadrícula, sidebar y navegador; validar; recargar; capturar | **ABIERTO** (se refresca con `reload`) |

**Mejora clave sobre el motor Python:** editar los visuales ya **no** exige cerrar Power BI.
El generador escribe los archivos PBIR y `powerbi-desktop reload --pid <PID>` refresca la
ventana abierta. El MCP se usa para el modelo/medidas; `hybrid.js` para todo lo visual.

**Cuidado (revert de `reload`):** un `reload` puede revertir el modelo vivo a la caché
(`.SemanticModel/.pbi/cache.abf`), perdiendo columnas/medidas agregadas por MCP sin guardar.
Mitigación: apoyarse en columnas **estables** de dimensión + medidas (no columnas nuevas del
hecho); si hace falta, exportar el modelo a TMDL y borrar `cache.abf` antes de recargar.

---

## 2. Piezas del sistema

`C:\Claude\pbi-motor\` (o donde se haya copiado el paquete)

| Pieza | Rol |
|-------|-----|
| `hybrid.js` | **Generador Node** (plantilla). Fábricas `htmlCard`, `deneb`, `filtro` + constructores Vega (`vBar`, `vColumn`, `vLine`, `vDonut`, `vHeatmap`, `withTopN`) con cross-filter incorporado. Sidebar + navegador de páginas + cuadrícula 12×10 (`cg()`). |
| `SISTEMA.md` | Este archivo — referencia de patrones (Deneb, HTML, DAX). |
| `filtros_test.json` | Ejemplo de campos del Filtro. |
| Plugin `powerbi-authoring@fabric-collection` | Trae las skills `powerbi-report-planning/design/authoring` **y** el MCP `powerbi-modeling-mcp` (vía `npx`). |
| CLI `powerbi-report-author` | `validate`, `catalog describe` (roles), `formatting describe-object`. |
| CLI `powerbi-desktop` | `status`, `reload --pid`, `screenshot` / `screenshot-all`. |

**Ejecutar con Node** (`node hybrid.js`), no con Python.

---

## 3. Empezar un proyecto nuevo

1. Plugin de Fabric instalado (una vez): `/plugin marketplace add microsoft/skills-for-fabric`
   + `/plugin install powerbi-authoring@fabric-collection`. Trae skills + MCP.
2. 2 CLIs de Fabric (una vez): `npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli`.
3. Copiar `hybrid.js` a `<proyecto>\_gen\` y ajustar la constante `REPORT` (ruta a `<Reporte>.Report`).
4. Importar en el reporte (una vez): **Deneb** y **HTML Content** desde AppSource; el **Filtro**
   (`FiltroGeneralUniversal.pbiviz`) desde archivo. Sin esto, los visuales salen vacíos.

**GUIDs de los custom visuals** (deben coincidir con los de `hybrid.js`):
- Deneb → `deneb7E15AEF80B9E4D4F8E12924291ECE89A` · rol `dataset`
- HTML Content → `htmlContent443BE3AD55E043BF878BED274D3A6855` · rol `content`
- Filtro → `filtroGeneralUniversal8A3E1F9C2B4D1E5F` · rol `fields` · acento `visualStyles.accentColor`

Para leer el GUID de un `.pbiviz`: descomprimir → `resources/<guid>.pbiviz.json` → `capabilities.dataRoles`.

---

## 4. Ciclo de trabajo

```powershell
# Modelo / medidas — por MCP (PBI ABIERTO): crear tablas, relaciones, medidas DAX + medidas HTML.
#   (conversacional; por debajo usa powerbi-modeling-mcp: table/column/measure/relationship/dax ops)

# Visuales (PBI ABIERTO): editar hybrid.js y generar
node _gen/hybrid.js

# Validar (los "Unknown visualType" de Deneb/HTML/Filtro son NORMALES; importan los errores)
powerbi-report-author validate "<ruta>\<Reporte>.Report"

# Recargar la ventana de PBI abierta
powerbi-desktop status                 # ← devuelve el PID de la instancia
powerbi-desktop reload --pid <PID>

# Capturar (esperar ~3 s: los custom visuals renderizan async)
powerbi-desktop screenshot-all --pid <PID>
```

`validate` con **0 errores** = listo (ignorar los avisos "Unknown visualType"). Si trae errores,
corregir `hybrid.js` y regenerar antes de recargar.

---

## 5. Estructura de `hybrid.js` (lo que se edita por dataset)

Solo cambian **tres zonas**; el resto (geometría, fábricas, cross-filter) se reutiliza.

### 5.1 Cabecera — ruta, GUIDs, paleta
```js
const REPORT = 'C:/ruta/a/MiReporte.Report';
const DENEB  = 'deneb7E15AEF80B9E4D4F8E12924291ECE89A';
const HTML   = 'htmlContent443BE3AD55E043BF878BED274D3A6855';
const FILTRO = 'filtroGeneralUniversal8A3E1F9C2B4D1E5F';
const TEAL='#0C8599', ORANGE='#E8590C', SIDEBAR='#0E2A3D', /* ...paleta */ ;
```

### 5.2 Fábricas de visuales (se usan, no se editan)
| Fábrica | Produce |
|---------|---------|
| `htmlCard(entity, 'Medida HTML', cg(...))` | HTML Content (rol `content`) — una medida DAX que devuelve HTML (§6). |
| `deneb([proj...], specVega, cg(...))` | Deneb (rol `dataset`) con cross-filter incluido (§8). |
| `filtro([{entity,column}...], box, accent)` | Barra de filtros (rol `fields`, color = acento) (§7). |

Constructores de spec Vega listos: `vBar`, `vColumn`, `vLine`, `vDonut`, `vHeatmap`, y
`withTopN(spec, catF, valF, n)` para top-N dentro de la spec (§8).

### 5.3 Funciones por página
Cada página (`page1()`, `page2()`, …) es una lista de llamadas a esas fábricas, posicionadas
con `cg(col0, row0, col1, row1)` en una cuadrícula 12×10 (a la derecha de un sidebar). Ahí se
cambian medidas, campos y qué visual va en cada casilla.

**Regla de diseño (no negociable):** KPIs/tarjetas → `htmlCard`; gráficas y tablas
interactivas → `deneb`; filtros → `filtro`. Los visuales nativos quedan solo para mapas
geográficos y el navegador de páginas (que arma la skill de Fabric).

---

## 6. HTML Content (`htmlCard`) — orientación y tema

La medida DAX devuelve un string HTML completo; PBI la evalúa en el contexto de filtro, así que
las tarjetas reaccionan a slicers y al cross-filter de Deneb. La medida se crea por MCP (PBI abierto).

**Orientación = forma del contenedor.** El CSS del contenedor debe coincidir con el espacio:
tira ancha y baja → `flex-direction:row`; sidebar alto y angosto → `flex-direction:column`.

**Tema = fondo de la página.** Página clara → tarjetas claras; página oscura → tarjetas oscuras.

**⚠️ Altura (regla obligatoria):** la 1.ª línea del CSS debe ser
`html,body{height:100%;overflow:hidden;}` y el contenedor principal debe usar **`height:100vh`**
(no `100%`); si no, queda un hueco blanco al fondo que crece al redimensionar.

**⚠️ Unicode en TMDL:** los acentos dentro de un string DAX en `.tmdl` pueden salir mal → usar
ASCII plano ("SATISFACCION") o entidades HTML (`&#211;`) en el texto HTML. Los nombres de medidas
sí pueden llevar acentos.

**Fuentes responsive:** `clamp(min, valor_en_vh/vw, max)` para todos los font-size, padding y gap.

Ver la skill `html-kpi-cards` para plantillas de tarjetas, badges de delta, semáforos y tablas.

---

## 7. Filtros — visual Filtro (`filtro`)

Un solo visual maneja N columnas: muestra los primeros campos como pills desplegables + panel
"Más Filtros" para el resto, con búsqueda y multi-select. Filtra la página vía cross-filter nativo
(gráficas Deneb y tarjetas HTML reaccionan).

- **Rol de datos:** `fields` (cada campo = una columna de una tabla). **Acento:** objeto
  `visualStyles.accentColor` (fill sólido) = color de acento del dashboard. Sin acento queda con
  su color por defecto — igualarlo siempre a la paleta.
- **Posición:** barra horizontal (pills en fila), como tira superior ancha y baja.
- **Importar (una vez por reporte):** PBI → Inicio → Más objetos visuales → Importar desde archivo →
  `FiltroGeneralUniversal.pbiviz`. No viaja dentro del `.pbip`.
- Los tabs de navegación que dibuja el visual son decorativos; la navegación entre páginas la arma
  la skill de Fabric (navegador de páginas).

Ver la skill `powerbi-filter`.

---

## 8. Deneb (`deneb`) — estética + interactividad

`dataset` es la lista de campos que alimentan el visual (se referencian en la spec por su
`nativeQueryRef`). `vega` es la spec Vega-Lite, que `hybrid.js` serializa dentro del `visual.json`.

**Interactividad (hover + click) — patrón para "funcionalidad":**
```js
"params": [
  {"name":"hov","select":{"type":"point","on":"mouseover","fields":["Cat"]}},
  {"name":"sel","select":{"type":"point","fields":["Cat"]}}
],
"opacity": {"condition":[{"param":"sel","value":1},{"param":"hov","empty":false,"value":0.85}],"value":0.25},
"usermeta": {"deneb":{"interactivity":{"tooltip":true,"selection":true,"dataPointLimit":300}}}
```
El cross-highlight interno lo da `opacity`; el **cross-filter a toda la página** lo da
`interactivity.selection:true` + el param `point` de click (PBI lo propaga como filtro nativo, y
las tarjetas HTML reaccionan porque son medidas evaluadas en contexto). Hacen falta las dos cosas.

**⚠️ Deneb NO acepta filtros de visual PBIR** (TopN/Advanced → "error en uno o más filtros"). El
filtrado (top-N, excluir vacíos) va **dentro** de la spec con `transform`:
`withTopN(spec, catF, valF, n)` aplica `{filter: isValid && != ''}` + `{window rank}` + `{filter rk<=n}`.

**Ranking por dimensión:** usar columnas **estables** de dimensión (p. ej. `dim_Estacion[Nombre]`)
+ medidas (`[Total ...]` para salidas, una medida re-ruteada para llegadas), no columnas volátiles
del hecho (evita el revert por `cache.abf`, §1).

Ver la skill `deneb-chart-generator` para plantillas por tipo.

---

## 9. Estética de negocio y layout

Dashboards de **negocio**: la estructura y la información importan tanto como que se vea bien.

- **Layout:** lo más importante arriba/izquierda; controles agrupados (Filtro como tira superior,
  nunca slicers dispersos); sidebar de KPIs libera la fila superior para una gráfica grande;
  márgenes/gutters consistentes (la cuadrícula los garantiza).
- **Que NO parezca "hecho por IA":** sin emojis; glifos funcionales sí (delta `▲▼` = `&#9650;`/`&#9660;`,
  `•` separador); texto sobrio del dominio; **una sola paleta de acento** en tarjetas, gráficas y
  el acento del Filtro; tipografía Segoe UI; radios consistentes.
- **Navegación entre páginas:** navegador de páginas de la skill de Fabric (no los tabs decorativos
  del Filtro).
- **Multipágina:** una función por página en `hybrid.js`, mismo estilo y paleta en todas para que el
  reporte se sienta como un solo producto. Cada página lleva su propia barra de Filtro con los campos
  relevantes.

---

## 10. Gotchas (errores ya resueltos — no repetir)

| Síntoma | Causa | Fix |
|---------|-------|-----|
| Deneb "error en uno o más filtros" | filtro de visual PBIR en un Deneb | filtrar dentro de la spec Vega con `withTopN` (transform) |
| Deneb / HTML en blanco | visual no importado, GUID equivocado, o render async | importar (§3); comparar GUID; esperar ~3 s y recapturar |
| Filtro vacío / "importa el visual" | `.pbiviz` no importado en ese reporte | importarlo (§7); es por reporte |
| Hueco blanco al fondo de una tarjeta HTML | falta `height:100vh` en el contenedor | 1.ª línea `html,body{height:100%;overflow:hidden}` + contenedor `height:100vh` (§6) |
| Tarjeta que no escala al redimensionar | px fijos | `clamp()` en font-size/padding/gap |
| `SATISFACCIÓN` sale mal | escape unicode en string DAX (.tmdl) | ASCII plano o entidades HTML (§6) |
| Al recargar desaparecen columnas/medidas del MCP | `reload` revirtió el modelo desde `cache.abf` | columnas estables de dimensión + medidas; si hace falta, exportar TMDL y borrar `cache.abf` (§1) |
| Gráfica sin reacción al mouse | solo param de click | añadir param `mouseover` + `opacity` condicional (§8) |
| Clic en barra no cambia las tarjetas | falta `interactivity.selection:true` o el param click | habilitarlos (§8) |
| Filtro con color que no combina | `accent` no pasado | pasar `accent` = paleta del dashboard (§7) |
| `validate` muestra "Unknown visualType" | Deneb/HTML/Filtro no son nativos | es normal; solo importan los errores |
| `node`/CLI no se reconoce | Node no instalado o PATH no recargado | instalar Node LTS; reabrir terminal tras `npm i -g` |
| Medida nueva con `dataType` explícito falla | limitación del MCP | omitir `dataType` al crear la medida |
| Columna oculta usada como categoría → visual en error | columna `isHidden` en eje/categoría | dejar visibles las columnas de eje |

---

## 11. Flujo end-to-end ("vamos a hacer un dashboard nuevo")

1. Plugin de Fabric + 2 CLIs instalados; `hybrid.js` copiado al proyecto con `REPORT` ajustado.
2. Importar Deneb + HTML Content (AppSource) y el Filtro (`.pbiviz`) en el reporte.
3. Auditar el modelo (`powerbi-dax-auditor`) con PBI abierto.
4. Preguntar **intención** (qué responde, qué se ve primero) y **paleta** (acento del Filtro y de
   gráficas/tarjetas).
5. Modelo + medidas DAX por MCP (PBI abierto), incluidas las medidas HTML (§6, §13).
6. Diseñar con las skills de Fabric (planning → design) y adaptar las funciones por página de
   `hybrid.js` (Filtro arriba, KPIs, Deneb con cross-filter).
7. `node _gen/hybrid.js` → `powerbi-report-author validate` → `powerbi-desktop reload --pid` →
   captura. Verificar cross-filter (clic en barra → tarjetas cambian) y color del Filtro.
8. Iterar correcciones en lenguaje natural. ¿Más páginas? Repetir 5–7 por página.

---

## 12. Ejemplo — una página en `hybrid.js`

```js
function pageResumen() {
  const P = 'Resumen';
  // Barra de filtros arriba (acento = paleta)
  write(P, filtro(
    [{entity:'fact_Trips', column:'MemberType'}, {entity:'dim_Date', column:'Month Year'}],
    { x:272, y:64, w:1616, h:64 }, TEAL));
  // Tira de KPIs (una medida HTML con varias tarjetas flex)
  write(P, htmlCard('fact_Trips', 'KPI Strip HTML', cg(1,1,13,3)));
  // Gráfica de línea con cross-filter
  write(P, deneb(
    [projCol('dim_Date','Month Year'), projMeas('fact_Trips','Total Trips')],
    vLine('Month Year','Total Trips'), cg(1,3,8,7)));
  // Top-N estaciones (filtrado dentro de la spec)
  write(P, deneb(
    [projCol('dim_Station','StationName'), projMeas('fact_Trips','Total Trips')],
    withTopN(vBar('StationName','Total Trips'),'StationName','Total Trips',10), cg(8,3,13,7)));
}
```

El generador real de referencia es el `hybrid.js` del proyecto Divvy (reconstruido con este flujo,
3 páginas: Resumen, Patrones, Estaciones).

---

## 13. Patrones avanzados — delta badge (Fase 1) e insight text (Fase 2)

Estos patrones son de las **medidas DAX** (independientes del motor); se crean por MCP.

### Fase 1 — KPIs con delta badge (cambio vs período anterior)
Badge verde ▲ / rojo ▼ con el % de cambio. Aparece solo cuando hay período comparable.

**CSS del badge:**
```css
.footer { display:flex; align-items:center; justify-content:space-between; gap:4px; }
.bu { font-weight:700; padding:2px 7px; border-radius:20px; background:#e6f9f0; color:#1a7a4a; }
.bd { font-weight:700; padding:2px 7px; border-radius:20px; background:#fce8ec; color:#c0142d; }
```

**DAX (auto-detecta el último período con datos si no hay selección):**
```dax
VAR _sel = SELECTEDVALUE(dim_Date[Month Number])
VAR _per = SUMMARIZE(fact_Trips, dim_Date[Year], dim_Date[Month Number])
VAR _aY  = MAXX(_per, dim_Date[Year])
VAR _aM  = MAXX(FILTER(_per, dim_Date[Year]=_aY), dim_Date[Month Number])
VAR _m   = IF(ISBLANK(_sel), _aM, _sel)
VAR _y   = IF(ISBLANK(_sel), _aY, COALESCE(SELECTEDVALUE(dim_Date[Year]), _aY))
VAR _mp  = IF(_m>1, _m-1, 12)
VAR _yp  = IF(_m>1, _y, _y-1)
VAR _v   = CALCULATE([Total Trips], dim_Date[Month Number]=_m, dim_Date[Year]=_y)
VAR _vp  = CALCULATE([Total Trips], dim_Date[Month Number]=_mp, dim_Date[Year]=_yp)
VAR _d   = DIVIDE(_v-_vp, _vp, 0)
VAR _b   = IF(ISBLANK(_vp), "",
             IF(_d>=0, "<span class='bu'>&#9650; "&FORMAT(ABS(_d),"0.0%")&"</span>",
                       "<span class='bd'>&#9660; "&FORMAT(ABS(_d),"0.0%")&"</span>"))
```
Delta invertido (métricas donde bajar es bueno): `VAR _d = DIVIDE(_vp-_v, _vp, 0)`.

### Fase 2 — insight text dentro del Deneb (subtitle)
Una línea DAX que resume el estado ("[X] lidera con Y% del total…"), embebida como capa `text` en
la spec Vega. Para que el texto sea el mismo en todas las filas del dataset, calcularlo con
`GROUPBY(CALCULATETABLE(Hecho, REMOVEFILTERS(Hecho[Dim])), ...)` y en Vega usar `aggregate:"min"`.
Requiere `usermeta.deneb.combination.type:"layer"` y convertir la gráfica a `layer` con `padding.top`.

Ver `html-kpi-cards` y `deneb-chart-generator` para las plantillas completas.

---

## 14. MODO AUTO — dashboard completo desde un solo prompt

Cuando el analista describe el dashboard y espera el resultado terminado sin intervenir, Claude
ejecuta todo: descubre el modelo, crea medidas, adapta `hybrid.js`, genera, valida, recarga,
captura y autocorrige.

### 14.1 Cuándo entra
- El prompt ya trae la **intención completa** (qué mostrar, de qué datos) → no preguntar; el prompt
  ES la intención. Si falta, UNA sola pregunta. Si no se conoce la ruta del `.pbip`, preguntar solo eso.

### 14.2 Protocolo
1. **Arranque** (si no está hecho): plugin de Fabric + CLIs; copiar `hybrid.js` con `REPORT` ajustado;
   confirmar que Deneb/HTML/Filtro están importados; leer este archivo.
2. **Esquema:** describir el modelo por MCP → mapear la intención a tablas/columnas/medidas reales
   (no inventar; si falta algo, crear la medida que lo derive).
3. **Diseño:** paleta, KPIs, gráficas y layout (skills de Fabric planning/design). Escribir las
   medidas nuevas (base + HTML + insights) por MCP y las funciones por página en `hybrid.js`.
4. **Ejecutar:** `node _gen/hybrid.js` → `validate` (corregir si hay errores) → `reload --pid` →
   `screenshot-all`.
5. **Verificar por captura** (§14.3). Iterar (máx 3 vueltas automáticas); si persiste, entregar lo
   construido + reporte honesto de lo que falta.

### 14.3 Checklist de la captura
1. ¿Diálogos de error de PBI? (medida inválida, visual no reconocido) → corregir primero.
2. ¿Los visuales tienen datos? Deneb/HTML en blanco = medida rota, dataset mal referenciado, GUID
   equivocado, o render aún async (esperar ~3 s y recapturar).
3. ¿El layout coincide? Sin solapes ni huecos; Filtro arriba; alineación de la cuadrícula.
4. ¿Estética coherente? Una paleta de acento; tema de tarjetas = fondo; sin cortes de texto.
5. ¿El Filtro se ve como barra de pills? Si dice "importa el visual" → falta importar el `.pbiviz`
   (único paso que puede requerir al analista).

Lo que la captura NO verifica: el cross-filter al hacer clic. Se garantiza por construcción
(`selection:true` + params en cada Deneb, §8) y se le indica al analista cómo probarlo.

### 14.4 Límites conocidos
- **Importar un `.pbiviz`** (Filtro) es el único paso manual restante; detectarlo y pedirlo una vez.
- **Diálogos de PBI al abrir/recargar** pueden tapar el reporte en la captura; avisar o cerrarlos.
- Los **datos** no se leen (solo el esquema); escribir DAX robusto a valores inexistentes
  (DIVIDE, COALESCE, ISBLANK).
