# Personalización — traducir lo que pide el usuario a `CFG`

Regla base: **lo que el usuario especifica manda sobre cualquier default.** No negocies, no
propongas alternativas, no preguntes "¿estás seguro?". Aplícalo y sigue.

Casi todo se resuelve cambiando `CFG` en `hybrid.js`. La geometría, la paleta y el cromo se
recalculan solos.

---

## 1 · Color

> "lo quiero de color verde" · "usa el azul de la marca" · "más sobrio"

Cambia **una sola línea**:

```js
accent: '#2B8A3E',
```

De ahí se derivan solas: la paleta de serie (para donas y multi-serie), el color del sidebar o la
barra superior, el extremo bajo del heatmap, el fondo de página, los bordes de tarjeta y el acento
del Filtro. **No pongas colores sueltos en las specs** — rompe la coherencia y es lo que hace que
un dashboard parezca hecho por IA.

Mapa de colores por nombre (usa estos, son sobrios y tienen buen contraste):

| Pide | Hex | | Pide | Hex |
|---|---|---|---|---|
| verde | `#2B8A3E` | | morado | `#6A0DAD` |
| azul | `#1C7ED6` | | rojo / vino | `#C92A2A` |
| teal / turquesa | `#0C8599` | | naranja | `#E8590C` |
| índigo | `#3B5BDB` | | gris / neutro | `#495057` |

Si el usuario da un hex, úsalo tal cual. Si da un color de marca ("el azul de Bancolombia"),
pídele el hex solo si no lo puedes deducir; si no, elige el más cercano de la tabla.

**Tema oscuro:** `theme: 'dark'`. Cambia fondo de página, fondo de tarjetas, texto y rejilla.
⚠️ Al pasar a oscuro hay que **rehacer el CSS de las medidas HTML** (fondo y color de texto): el
tema solo controla los visuales que genera `hybrid.js`, no el HTML que vive dentro de las medidas
DAX. Ver `html-kpi-cards`.

---

## 2 · Layout: navegación y filtro

> "quiero el menú de páginas arriba" · "el filtro a la izquierda" · "sin filtro"

```js
nav:    'top',    // 'left' = sidebar (default) · 'top' = barra superior
filter: 'left',   // 'top' (default) · 'left' = riel vertical · 'none'
```

Las cuatro combinaciones funcionan y la cuadrícula se recalcula sola:

| `nav` | `filter` | Resultado |
|---|---|---|
| `left` | `top` | Sidebar oscuro + barra de pills ancha. **Default.** El más probado. |
| `left` | `left` | Sidebar + riel de filtro pegado a él. Deja el ancho máximo a las gráficas. |
| `top` | `top` | Barra superior con marca + navegador; filtro debajo. Estilo web/SaaS. |
| `top` | `left` | Barra superior + riel lateral. El que más área de contenido deja. |

Notas por posición:
- **`filter: 'left'`** → riel de 236 px de ancho. El visual apila las pills; se le pasa
  `alignment: 'flex-start'` automáticamente. Con más de 5 campos, del 6º en adelante van a
  "+ Más Filtros" — con riel vertical conviene no pasar de 5.
- **`nav: 'top'`** → el navegador se dimensiona a ~140 px por página. Con más de 6 páginas se
  aprieta; a partir de ahí, recomienda `nav: 'left'` (una sola frase, y si insiste, obedece).
- **`filter: 'none'`** → sin barra. Útil si el usuario quiere solo slicers nativos o ningún filtro.

---

## 3 · Número de páginas

> "que sean 5" · "solo una página" · "agrégale una de detalle"

El array `PAGES` al final de `hybrid.js` define cuántas hay. Una entrada = una página:

```js
{
  id: 'a1b2c3d4e5f601020304',   // 20 hex chars. ESTABLE: no lo cambies entre ejecuciones
  name: 'Resumen',              // lo que se ve en el navegador de páginas
  title: 'Resumen ejecutivo',   // encabezado dentro de la página
  filters: [['dim_Fecha','Año'], ['dim_Fecha','Mes']],
  body: () => [ /* visuales, posicionados con cg() */ ],
}
```

⚠️ **El `id` debe ser estable.** Si lo cambias entre ejecuciones, el generador borra la carpeta
vieja y crea otra: Power BI lo ve como "página borrada + página nueva" y hay que cerrar y reabrir.
Genera los ids una vez y consérvalos durante todo el proyecto.

⚠️ **Agregar o quitar páginas exige close+reopen de Power BI**, no basta `reload` (ver GOTCHAS).
Si el usuario pide "agrégale una página" a un dashboard ya hecho, cuenta con ese ciclo.

Al pasar de 3 a N páginas, no repitas la misma página N veces: cada una debe responder una
pregunta de negocio distinta. Si no se te ocurren 5 preguntas reales con los datos que hay, dilo
y propón las que sí — es mejor que cinco páginas huecas.

---

## 4 · Cuadrícula: dónde va cada visual

`cg(col0, fila0, col1, fila1)` sobre una rejilla de **12 columnas × 10 filas**. El segundo par es
**exclusivo**: `cg(1,1,7,4)` ocupa las columnas 1-6 y las filas 1-3.

```js
cg(1, 1, 13, 3)    // tira completa de ancho, 2 filas de alto → tarjetas KPI
cg(1, 3, 13, 7)    // bloque grande → la gráfica principal
cg(1, 7,  7, 11)   // mitad izquierda inferior
cg(7, 7, 13, 11)   // mitad derecha inferior
```

Guías: KPIs arriba ocupando el ancho; la gráfica que responde la pregunta principal grande y a la
izquierda; los rankings a la derecha. Nunca dejes una fila a medias ni un hueco de una sola celda.

---

## 5 · Filtro personalizado

> "quiero un filtro personalizado para este dashboard que tenga…"

Hay dos niveles. **Empieza siempre por el nivel 1**; solo pasa al 2 si lo que piden no se puede
configurar.

### Nivel 1 — configurar `FiltroGeneralUniversal` (minutos)

Cubre: qué campos aparecen y en qué orden, color de acento, tamaño de fuente, alineación,
horizontal o vertical. Es lo que resuelve el 90 % de las peticiones.

```js
filtro(campos, FILTER_BOX, {
  accent: '#2B8A3E',
  fontSize: 12,                 // ⚠ nunca lo subas sin subir también el alto de la barra
  alignment: 'space-between',   // 'flex-start' | 'center' | 'flex-end'
})
```

Los primeros 5 campos salen como pills; del 6º en adelante van al panel "+ Más Filtros".
El orden de `campos` es el orden de las pills.

### Nivel 2 — compilar un `.pbiviz` a medida (una hora larga)

Solo si piden comportamiento que el visual no tiene: un tipo de control distinto (rango de
fechas, slider numérico), lógica de dependencia entre campos, textos o normalizaciones
específicas del negocio.

Plantilla de partida incluida en esta skill:
`~/.claude/skills/powerbi-dashboard/assets/filtro-template/` (TypeScript, `pbiviz` CLI). Ya
normaliza valores conocidos y ordena de forma inteligente (días de semana, meses, numéricos,
rangos "N-M"), y está libre de `stopPropagation`.

```powershell
npm i -g powerbi-visuals-tools
copy -r ~\.claude\skills\powerbi-dashboard\assets\filtro-template <proyecto>\_filtro
cd <proyecto>\_filtro
# editar pbiviz.json: displayName + un guid NUEVO (si repites el guid, choca con el existente)
npm install
pbiviz package                      # → dist\<nombre>.pbiviz
```

Después: el usuario lo importa en el reporte y tú actualizas `CFG.guids.filtro` con el GUID nuevo.

⚠️ **Regla crítica al escribir el TypeScript: cero `stopPropagation` y cero `preventDefault` en
los handlers de clic.** Si el evento no llega al host, Power BI nunca selecciona el visual, nunca
lo eleva, y el desplegable se dibuja **detrás** de las demás gráficas. Para distinguir
sub-elementos (una "×" dentro de una pill) usa `ev.target.closest('.clase')` dentro de un único
handler, no handlers anidados. Subir el `z` en el PBIR **no** es la solución: hace que su área
transparente bloquee el hover de todo lo que tape, y el `z` se reasigna al reimportar.

---

## 6 · Cambios sobre un dashboard ya construido

| Pide | Qué tocar | ¿Basta `reload`? |
|---|---|---|
| Otro color | `CFG.accent` | Sí |
| Mover el filtro / la navegación | `CFG.nav`, `CFG.filter` | Sí |
| Cambiar una gráfica | la línea en `body()` | Sí |
| Cambiar un KPI | la **medida DAX** por MCP (no `hybrid.js`) | Sí |
| Agregar o quitar páginas | `PAGES` | **No** — close + reopen |
| Otro tema (claro↔oscuro) | `CFG.theme` + rehacer el CSS de las medidas HTML | Sí |

Tras cualquier cambio: `node _gen/hybrid.js` → `validate` → recargar → captura. El generador
reescribe las páginas completas, así que los cambios manuales que el usuario haya hecho en Power
BI Desktop sobre esas páginas **se pierden**. Avísale si sospechas que editó algo a mano.
