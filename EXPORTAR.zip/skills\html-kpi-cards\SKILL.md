---
name: html-kpi-cards
description: >
  Construye medidas DAX que generan HTML dinámico para tarjetas KPI, tablas formateadas
  y badges de estado en Power BI usando el visual HTML Content (Nova Silva o similar).
  Activar cuando el usuario pida tarjetas KPI bonitas, mencione "HTML Content",
  quiera tarjetas con hover, animaciones, iconos, colores condicionales, o cualquier
  visualización de métricas que vaya más allá de las tarjetas nativas de Power BI.
  También activar con frases como "card con hover", "tarjeta morada", "KPI visual",
  "badge de estado", "semáforo de métricas". Las medidas resultantes son reactivas
  a filtros de Power BI y se suben directamente al modelo via MCP si está conectado.
---

# HTML KPI Cards

Genera medidas DAX que producen HTML reactivo a filtros para Power BI.

## Regla de diseño: negocio primero

Jerarquía de decisión:
1. **El analista da referencia de estilo** (imagen, colores, descripción) → seguirla fielmente
2. **El analista no especifica** → aplicar el estilo default de dashboard de negocio:
   - Número prominente (32-40px, bold, color acento oscuro)
   - Etiqueta pequeña debajo (11-12px, color suave)
   - Hover que cambia el fondo al color acento (gradiente) y texto a blanco
   - Bordes sutiles, sombra suave, border-radius generoso
   - Fondo blanco en reposo para máxima legibilidad

---

## Principio fundamental

La medida DAX construye un string HTML completo. Power BI evalúa la medida en el
contexto de filtro actual → las tarjetas se actualizan automáticamente con cualquier
slicer, cross-filter o drill-through.

**CRÍTICO de sintaxis DAX**: Solo comillas simples dentro del HTML. Nunca comillas
dobles anidadas dentro del string DAX — rompen la expresión.

---

## Orientación y tema (deben coincidir con el espacio y la página)

La medida es la misma idea, pero el CSS del `body` cambia según DÓNDE va la tarjeta:

| Espacio | `flex-direction` | Ejemplo |
|---------|------------------|---------|
| Tira superior ancha y baja | `row` | 4 KPIs en fila |
| Sidebar alto y angosto (≈200px × alto completo) | `column` | 4 KPIs apilados |

**Tema = fondo de la página.** Página clara → tarjeta clara (`#fff`, texto oscuro).
Página oscura → tarjeta oscura. Nunca tarjeta oscura sobre página clara (error común).

---

## ⚠️ `html { height:100% }` — primera línea de TODO CSS en HTML Content

El visual HTML Content renderiza en un iframe. Si `html` no tiene `height:100%`, entonces
`body { height:100% }` se resuelve contra la altura `auto` del `html` (que colapsa al
contenido), dejando un **espacio vacío al fondo** que crece cuando el usuario redimensiona
el contenedor visual en Power BI.

**Regla absoluta:** la primera línea del bloque CSS de cualquier medida HTML Content debe ser:

```css
html,body { height:100%; overflow:hidden; }
```

El `overflow:hidden` elimina el scrollbar residual. Esta línea va ANTES del reset `* {}`.

---

## ⚠️ Bug de unicode en archivos .tmdl

Si la medida se escribe directamente en un `.tmdl` (PBI cerrado), los escapes unicode
dentro del string HTML (`Ó` para Ó, `í` para í, etc.) **aparecen literalmente**
en el HTML renderizado — PBI NO los resuelve dentro de un string DAX.

→ En el texto HTML usar **ASCII plano** (`SATISFACCION`, `Dias`, `Resolucion`) o
**entidades HTML** (`&#211;` = Ó). Los nombres de medidas DAX (`[Promedio Satisfacción]`)
sí pueden llevar acentos; el problema es solo el texto visible dentro del string HTML.

(Vía MCP con PBI abierto el bug no aparece, pero usar ASCII por consistencia.)

---

## Dónde se escribe la medida

- **PBI abierto** → subir via MCP `measure_operations → Create` a la tabla de medidas.
- **PBI cerrado** → escribir la medida en el `.tmdl` de la tabla de medidas
  (ruta en `pbi.config.json` → `measuresTmdl`). Cuidar el bug de unicode de arriba.

El visual que la muestra es un `html_card` en el spec del dashboard
(`{"type":"html_card","entity":"DAX Medidas","measure":"<nombre>"}`). Ver `SISTEMA.md §6`.

---

## Plantilla base: 4 KPI Cards (columna vertical, responsive)

Esta es la plantilla canónica — sidebar vertical, responsive con `clamp()`.
Para tira horizontal (fila): cambiar `flex-direction:column` por `row` y ajustar el hover
a `translateY(-3px)`.

```dax
KPI Cards HTML =
VAR _v1 = [Medida1]
VAR _v2 = FORMAT([Medida2], "0.0")
VAR _v3 = FORMAT([Medida3], "0%;-0%;0%")
VAR _v4 = [Medida4]

VAR _css =
"html,body { height:100%; overflow:hidden; }
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; display:flex; flex-direction:column;
       gap:clamp(5px,1.4vh,12px); padding:clamp(8px,1.8vh,16px) clamp(6px,1.4vw,14px);
       background:transparent; }
.card { background:#fff; border:1.5px solid #e0d6f5;
        border-radius:clamp(8px,1.4vh,14px);
        padding:clamp(8px,2.2vh,18px) clamp(8px,1.8vw,18px);
        flex:1; display:flex; flex-direction:column; justify-content:center;
        box-shadow:0 2px 10px rgba(102,51,153,.08);
        transition:all .25s ease; cursor:default; }
.card:hover { background:linear-gradient(135deg,#6A0DAD,#9B59B6);
              box-shadow:0 6px 22px rgba(106,13,173,.3); transform:translateX(3px); }
.card:hover .lbl,.card:hover .ico { color:rgba(255,255,255,.75); }
.card:hover .val { color:#fff; }
.ico { font-size:clamp(8px,2vh,13px); color:#9B59B6;
       margin-bottom:clamp(2px,0.4vh,5px); font-weight:700;
       text-transform:uppercase; letter-spacing:.5px; }
.val { font-size:clamp(14px,7.5vh,52px); font-weight:800; color:#3D0080;
       line-height:1; margin-bottom:clamp(2px,0.4vh,4px); }
.lbl { font-size:clamp(8px,2vh,12px); color:#7B5EA7; font-weight:500; }"

RETURN
"<!DOCTYPE html><html><head><meta charset='UTF-8'><style>" & _css & "</style></head><body>"
& "<div class='card'><div class='ico'>&#127915; ICONO 1</div><div class='val'>" & _v1 & "</div><div class='lbl'>Descripcion 1</div></div>"
& "<div class='card'><div class='ico'>&#11088; ICONO 2</div><div class='val'>" & _v2 & "</div><div class='lbl'>Descripcion 2</div></div>"
& "<div class='card'><div class='ico'>&#128337; ICONO 3</div><div class='val'>" & _v3 & "</div><div class='lbl'>Descripcion 3</div></div>"
& "<div class='card'><div class='ico'>&#128100; ICONO 4</div><div class='val'>" & _v4 & "</div><div class='lbl'>Descripcion 4</div></div>"
& "</body></html>"
```

**Notas clave:**
- `html,body { height:100%; overflow:hidden; }` — **siempre**, primera línea del CSS.
- Textos visibles en ASCII plano (sin acentos) para evitar el bug TMDL unicode.
- `clamp(min, preferred_en_vh, max)` en font-size/padding/gap → responsive al redimensionar.
- `flex:1` en cada `.card` distribuye el alto disponible entre las 4 tarjetas.
- Plantilla viva: medidas `KPI Cards Light/Dark/Vertical HTML` en proyecto Tractchun.

### Variante tira horizontal (fila superior ancha)

```css
html,body { height:100%; overflow:hidden; }
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; display:flex; flex-direction:row;
       gap:clamp(6px,1vw,14px); padding:clamp(6px,1.2vh,12px) clamp(8px,1.4vw,16px);
       background:transparent; }
.card:hover { transform:translateY(-3px); }  /* vertical en lugar de lateral */
```

---

## Paletas disponibles

| Nombre | Hover bg | Color valor | Borde |
|--------|----------|-------------|-------|
| Morado (default) | `linear-gradient(135deg,#6A0DAD,#9B59B6)` | `#3D0080` | `#e0d6f5` |
| Azul corporativo | `linear-gradient(135deg,#1565C0,#42A5F5)` | `#0D47A1` | `#BBDEFB` |
| Verde éxito | `linear-gradient(135deg,#1B5E20,#43A047)` | `#1B5E20` | `#C8E6C9` |
| Naranja acción | `linear-gradient(135deg,#E65100,#FF9800)` | `#BF360C` | `#FFE0B2` |
| Gris neutro | `linear-gradient(135deg,#37474F,#78909C)` | `#1C313A` | `#CFD8DC` |

---

## Color condicional (semáforo)

Para KPIs que deben cambiar de color según rendimiento:

```dax
VAR _color = IF([Real] >= [Meta], "#27AE60", "#E74C3C")
VAR _icon  = IF([Real] >= [Meta], "&#8593;", "&#8595;")
-- En el HTML:
"<div class='val' style='color:" & _color & ";'>" & _icon & " " & FORMAT([Real], "0%") & "</div>"
```

---

## Variante: KPI con comparación (Real vs. Meta)

```dax
-- Mostrar valor principal + delta vs meta debajo
"<div class='val'>" & FORMAT([Real], "#,0") & "</div>"
& "<div class='delta' style='color:" & _color & ";font-size:13px;margin-top:4px;'>"
& _icon & " " & FORMAT([Real] - [Meta], "+#,0;-#,0;0") & " vs meta</div>"
```

---

## Variante: KPI cards con delta badge (Fase 1)

Un badge verde ▲ / rojo ▼ al lado de la etiqueta indica el cambio vs un período anterior.
La tarjeta muestra el badge solo si hay un período seleccionado (comportamiento honesto).

**CSS adicional** (añadir en el bloque de estilos junto a `.lbl`):

```css
.footer { display:flex; align-items:center; justify-content:space-between; gap:4px; }
.bu { font-size:clamp(7px,1.5vh,11px); font-weight:700; padding:2px 7px;
      border-radius:20px; background:#e6f9f0; color:#1a7a4a; white-space:nowrap; }
.bd { font-size:clamp(7px,1.5vh,11px); font-weight:700; padding:2px 7px;
      border-radius:20px; background:#fce8ec; color:#c0142d; white-space:nowrap; }
```

**Estructura HTML de la card** (reemplaza el `.lbl` con un footer de dos columnas):

```html
<div class='card'>
  <div class='ico'>&#128202; LABEL</div>
  <div class='val'>VALOR</div>
  <div class='footer'>
    <div class='lbl'>Descripcion</div>
    BADGE_HTML
  </div>
</div>
```

**DAX — con tabla de calendario (badges siempre visibles):**

El patrón auto-detecta el último mes con datos si no hay selección → badges aparecen
desde que se abre el dashboard, sin necesidad de que el usuario elija un período.

```dax
VAR _selected_mes = SELECTEDVALUE(d_Calendario[#Mes])

// Auto-detect: último año/mes con datos (SUMMARIZE solo incluye períodos con filas)
VAR _periodos  = SUMMARIZE(FactTable, d_Calendario[#Año], d_Calendario[#Mes])
VAR _auto_anio = MAXX(_periodos, d_Calendario[#Año])
VAR _auto_mes  = MAXX(FILTER(_periodos, d_Calendario[#Año] = _auto_anio), d_Calendario[#Mes])

// Resolver período actual: slicer o auto-detectado
VAR _mes  = IF(ISBLANK(_selected_mes), _auto_mes, _selected_mes)
VAR _anio = IF(ISBLANK(_selected_mes), _auto_anio,
               COALESCE(SELECTEDVALUE(d_Calendario[#Año]), _auto_anio))

VAR _mes_p  = IF(_mes > 1, _mes - 1, 12)
VAR _anio_p = IF(_mes > 1, _anio, _anio - 1)

// Sin fallback a grand total: siempre comparar períodos puntuales
VAR _v  = CALCULATE([Medida], d_Calendario[#Mes]=_mes,   d_Calendario[#Año]=_anio)
VAR _vp = CALCULATE([Medida], d_Calendario[#Mes]=_mes_p, d_Calendario[#Año]=_anio_p)
VAR _d  = DIVIDE(_v - _vp, _vp, 0)
VAR _b  = IF(ISBLANK(_vp), "",
             IF(_d >= 0,
                "<span class='bu'>&#9650; " & FORMAT(ABS(_d),"0.0%") & "</span>",
                "<span class='bd'>&#9660; " & FORMAT(ABS(_d),"0.0%") & "</span>"))
```

**DAX — sin tabla de calendario (vs promedio global):**

```dax
VAR _v   = [Medida]
VAR _avg = CALCULATE([Medida], REMOVEFILTERS())
VAR _d   = DIVIDE(_v - _avg, _avg, 0)
VAR _b   = IF(_d >= 0,
              "<span class='bu'>&#9650; " & FORMAT(ABS(_d),"0.0%") & " vs prom.</span>",
              "<span class='bd'>&#9660; " & FORMAT(ABS(_d),"0.0%") & " vs prom.</span>")
```

**Delta invertido** (métricas donde bajar es bueno, ej. "días de resolución"):
```dax
VAR _d = DIVIDE(_vp - _v, _vp, 0)  -- invertido: menos días → delta positivo → verde
```

Medida de referencia: `KPI Cards Delta HTML` en el proyecto Tractchun.
Ver `SISTEMA.md §13` para el patrón completo.

---

## Variante: Insight text dinámico (Fase 2)

Una línea de texto generada por DAX que resume el estado del dashboard.
Se coloca debajo de la gráfica que describe (`rowspan:1`, el más fino del grid).

**DAX genérico:**

```dax
VAR _total = [Medida]
VAR _n     = COUNTROWS(VALUES(DimTabla[Campo]))
VAR _top1  = MAXX(TOPN(1, VALUES(DimTabla[Campo]), CALCULATE([Medida]), DESC), DimTabla[Campo])
VAR _v1    = CALCULATE([Medida], DimTabla[Campo] = _top1)
VAR _pct1  = FORMAT(DIVIDE(_v1, _total), "0%")
VAR _top3  = SUMX(TOPN(3, VALUES(DimTabla[Campo]), CALCULATE([Medida]), DESC), CALCULATE([Medida]))
VAR _pct3  = FORMAT(DIVIDE(_top3, _total), "0%")
VAR _texto = _top1 & " lidera con " & _pct1 & " del total, las 3 primeras concentran " & _pct3 & " de " & _n & " categorias"
```

**CSS (visual tipo tira ancha, alto ~35px):**

```css
html,body { height:100%; overflow:hidden; }
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; height:100%; display:flex;
       align-items:center; padding:clamp(4px,1vh,8px) clamp(8px,1.5vw,14px);
       background:transparent; }
.ico { color:#9B59B6; margin-right:7px; font-size:clamp(10px,2vh,15px); flex-shrink:0; }
.txt { font-size:clamp(9px,1.8vh,13px); color:#5a5a7a; line-height:1.5; }
```

**RETURN:**
```dax
RETURN
"<!DOCTYPE html><html><head><meta charset='UTF-8'><style>" & _css & "</style></head><body>"
& "<span class='ico'>&#128161;</span><span class='txt'>" & _texto & "</span>"
& "</body></html>"
```

**Dos variantes de insight:**

| Variante | Cómo | Cuándo |
|---------|------|--------|
| `html_card` separado (`Insight Categorias HTML`) | CSS + HTML en medida DAX, `rowspan:1` debajo del chart | Cuando el dashboard tiene espacio libre y no importa el fondo |
| Dentro del Deneb (`Insight Categorias Texto`) | Texto plano → dataset Deneb → `text` mark layer en el chart | Integración total — mismo visual, sin fondo, como subtitle |

**Patrón GROUPBY para medida compatible con Deneb row context:**
La medida de texto plano DEBE usar `GROUPBY` + `CALCULATETABLE(..., REMOVEFILTERS)` para
que todas las filas del dataset retornen el mismo texto (inmune al filtro de categoría de la fila).
En el spec Vega-Lite: `"aggregate": "min"` extrae el texto ya que min = max = el único valor.

Ver `SISTEMA.md §13` (sección Fase 2b) para el patrón completo de integración Deneb.

---

## Variante: Tabla HTML con formato condicional

```dax
Tabla Detalle HTML =
VAR _filas = CONCATENATEX(
    TOPN(10, DimTabla, [Metrica], DESC),
    "<tr>"
    & "<td style='padding:8px 12px;'>" & DimTabla[Nombre] & "</td>"
    & "<td style='padding:8px 12px;font-weight:700;color:"
        & IF([Metrica] >= [Meta], "#27AE60", "#E74C3C") & ";'>"
        & FORMAT([Metrica], "0%") & "</td>"
    & "<td style='padding:8px 12px;font-size:18px;'>"
        & IF([Metrica] >= [Meta], "&#9679;", "&#9675;") & "</td>"
    & "</tr>",
    ""
)
RETURN
"<table style='width:100%;font-family:Segoe UI;font-size:13px;border-collapse:collapse;'>"
& "<tr style='background:#6A0DAD;color:white;'>"
& "<th style='padding:10px 12px;text-align:left;'>Nombre</th>"
& "<th style='padding:10px 12px;'>% Meta</th>"
& "<th style='padding:10px 12px;'>Estado</th></tr>"
& _filas
& "</table>"
```

---

## Iconos HTML (sin dependencias externas)

| HTML entity | Símbolo | Uso |
|-------------|---------|-----|
| `&#8593;` | ↑ | Crecimiento positivo |
| `&#8595;` | ↓ | Caída |
| `&#9733;` | ★ | Satisfacción / rating |
| `&#9201;` | ⏱ | Tiempo / días |
| `&#10003;` | ✓ | Meta cumplida |
| `&#9873;` | ⚑ | Alerta |
| `&#128100;` | 👤 | Personas / agentes |
| `&#128202;` | 📊 | Datos / métricas |
| `&#128181;` | 💵 | Presupuesto / dinero |

---

## Checklist antes de subir la medida

- [ ] **`html,body { height:100%; overflow:hidden; }`** — primera línea del CSS, siempre
- [ ] Solo comillas simples dentro del HTML (no dobles anidadas)
- [ ] **Orientación** (`row` vs `column`) coincide con el espacio del visual
- [ ] **Tema** (claro/oscuro) coincide con el fondo de la página
- [ ] **Texto HTML en ASCII / entidades** (sin escapes unicode si va al `.tmdl`)
- [ ] **CSS responsive** con `clamp(min, preferred_vh_vw, max)` — sin px fijos en font-size/padding/gap
- [ ] FORMAT() aplicado a todos los decimales y porcentajes
- [ ] Medidas referenciadas con corchetes: `[NombreMedida]`
- [ ] RETURN al final con el string HTML completo
- [ ] Si el analista dio referencia de estilo → paleta y tipografía la siguen
- [ ] PBI abierto → MCP; PBI cerrado → escribir al `.tmdl` de medidas
