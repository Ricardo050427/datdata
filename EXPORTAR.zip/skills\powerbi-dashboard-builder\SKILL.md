---
name: powerbi-dashboard-builder
description: >
  Metodología completa para construir dashboards de negocio en Power BI con Claude.
  Activar siempre que el usuario mencione Power BI, dashboards, reportes de negocio,
  análisis de datos con visuales, o diga frases como "arma un dashboard", "tengo datos de...",
  "crea un reporte", "quiero un dashboard de ventas/operaciones/tickets/etc",
  "vamos a armar un dashboard", "siguiendo la metodología", "empecemos el proyecto".
  También activar cuando el usuario traiga datos crudos (CSV, Excel, descripción de BD)
  y quiera convertirlos en algo visual. Este skill orquesta las 7 etapas del flujo
  completo: ingesta → intención → modelo → DAX → visuales → layout → correcciones,
  y es responsable de encadenar automáticamente las skills especializadas en cada etapa.
---

# Power BI Dashboard Builder

Flujo de 7 etapas para construir dashboards de negocio eficientes.

## CAPA DE EJECUCIÓN — el motor PBIR (leer primero)

Esta skill es la metodología; la **ejecución real** vive en el motor de scripts PBIR:

```
C:\Users\lanfa\.claude\code\primera sesion\
```

**Antes de construir o modificar visuales, leer `SISTEMA.md` de esa carpeta.** Es la
referencia técnica completa (spec de `build-dashboard`, panel de filtros, interactividad
Deneb, gotchas). Esta skill NO se basta sola para la parte visual — el motor sí.

**Dos capas que NO se solapan:**

| Necesito… | Herramienta | Power BI |
|-----------|-------------|----------|
| Crear/editar tablas, medidas DAX, relaciones | MCP `powerbi-modeling-mcp` | **ABIERTO** |
| Colocar gráficas Deneb, tarjetas HTML, barra de filtros Navara, botones, layout | Scripts PBIR (`pbi.ps1 build-dashboard`) | **CERRADO** |

El MCP **no puede** colocar un visual Deneb ni la barra de filtros. Todo lo visual
se hace por archivos con el motor. El wrapper gestiona el ciclo cerrar→escribir→abrir:

```powershell
cd "C:\Users\lanfa\.claude\code\primera sesion"
.\pbi.ps1 pbi-refresh build-dashboard --spec mi_dashboard.json
```

## ARRANQUE DE PROYECTO NUEVO

Cuando el analista diga "vamos a empezar un dashboard nuevo" (o similar):

1. **Registrar el proyecto:** `.\pbi.ps1 pbi-init "C:\ruta\MiReporte.pbip"`
   (autodetecta `.Report` / `.SemanticModel` / `.tmdl` de medidas → escribe `pbi.config.json`).
   Si aún no hay `.pbip`, pedir la ruta o crear el proyecto primero.
2. **Detectar GUIDs de custom visuals:** `.\pbi.ps1 detect-custom`
   Devuelve los IDs reales de Deneb y HTML Content instalados en este proyecto.
   **Nunca reutilizar los GUIDs de un proyecto anterior** — son distintos por versión e instalación.
3. **Leer `SISTEMA.md`** del motor para tener la mecánica fresca.
4. **Si habrá filtros:** pedir al analista que importe el `.pbiviz` de Navara (instrucciones
   exactas en `SISTEMA.md §7.3`) y confirmar "Importación correcta" antes de construir.
5. Si Power BI está abierto, **auditar el modelo** (`powerbi-dax-auditor`).
6. Pasar a Etapa 1 (ingesta) → Etapa 2 (intención + **paleta** del dashboard).

A partir de `pbi-init`, todos los comandos operan sobre ese proyecto. Cambiar de
proyecto = correr `pbi-init` con otro `.pbip`.

## ENCADENAMIENTO AUTOMÁTICO DE SKILLS

Esta skill es el orquestador. Al activarse, es responsable de invocar las skills
especializadas en el momento correcto. El analista NO necesita mencionarlas.

| Etapa | Skill que se activa automáticamente |
|-------|-------------------------------------|
| Etapa 3 — particiones NoData detectadas | `powerbi-dax-auditor` |
| Etapa 4 — construcción de medidas DAX | Reglas internas de esta skill |
| Etapa 5 — tarjetas KPI | `html-kpi-cards` → SIEMPRE, sin excepción |
| Etapa 5 — gráficas de tendencia, ranking, comparación, distribución | `deneb-chart-generator` → SIEMPRE, sin excepción |
| Etapa 7 — correcciones a visuals | `html-kpi-cards` o `deneb-chart-generator` según el visual afectado |

**REGLA CRÍTICA — Etapa 5**: Nunca proponer visuals nativos de Power BI para KPIs
ni para gráficas donde Deneb o HTML Content sean aplicables. Los visuals nativos
(Tarjeta, Gráfico de barras, Gráfico de líneas estándar) están prohibidos salvo
para mapas geográficos o cuando el analista los pida explícitamente.

---

## Regla #0 — Conectar primero

Siempre intentar conectar al modelo abierto via MCP antes de cualquier otra acción:

```
powerbi-modeling-mcp → connection_operations → ListLocalInstances
```

Si hay instancias abiertas, conectarse y leer el estado actual del modelo.
Si no hay instancias, trabajar en modo diseño (propuestas sin subir cambios).

---

## Regla #1 — La intención del analista es mandatoria

La intención declarada por el analista define TODO: qué medidas se crean primero,
qué visual es el principal, cómo se organiza el layout.

- Las sugerencias de Claude son COMPLEMENTARIAS, nunca sustitutas.
- Si el analista dice "presupuesto vs gasto" → esas son las dos métricas centrales,
  no importa qué otras columnas interesantes haya en el modelo.
- Si el analista dice "quiero ver el ranking de vendedores" → el visual principal
  es un ranking, aunque Claude crea que una tendencia sería más útil.

---

## Etapa 1 — Ingesta y Diagnóstico

Al recibir datos (CSV/Excel/descripción), reportar:

1. **Conteo**: X tablas, Y columnas, Z filas estimadas
2. **Columnas fecha detectadas**: lista con formato encontrado
3. **Posibles KPIs**: columnas numéricas candidatas a métricas
4. **Posibles dimensiones**: columnas categóricas (quién, qué, dónde, cuándo)
5. **Problemas detectados**: nulos críticos, tipos incorrectos, duplicados

Terminar siempre con la pregunta de intención → pasar a Etapa 2 inmediatamente.

---

## Etapa 2 — Intención del Dashboard

Hacer UNA sola pregunta al final del diagnóstico:

> "¿Cuál es el objetivo principal de este dashboard y qué es lo primero que debe ver el usuario al abrirlo?"

Con la respuesta, extraer y confirmar:

- **KPIs mandatorios**: los que el analista mencionó explícitamente
- **Comparaciones requeridas**: vs. meta / vs. período anterior / vs. grupo
- **Granularidad**: total general, por área, por persona, por período
- **Audiencia**: ¿quién lo usa y con qué frecuencia?

Solo después de confirmar los mandatorios, Claude puede sugerir KPIs adicionales
que complementen la intención — nunca antes.

**Ejemplos de interpretación:**

| Intención del analista | KPIs mandatorios | Visual principal |
|------------------------|-----------------|-----------------|
| "Presupuesto vs gasto" | Presupuesto, Gasto, Variación $, % Ejecución | Bullet chart o bar con referencia |
| "Desempeño de agentes" | Tickets por agente, Satisfacción, Tiempo resolución | Ranking horizontal con indicadores |
| "Ventas por región" | Ventas totales, Ventas por región, % del total | Mapa + bar chart |
| "Control de inventario" | Stock actual, Bajo mínimo, Rotación | Tabla semáforo + tendencia |

---

## Etapa 3 — Modelo Semántico

Diseñar el modelo en función de los KPIs mandatorios de Etapa 2:

- Tabla de hechos central con las métricas que soportan la intención
- Tablas de dimensiones normalizadas
- Tabla calendario si hay columna fecha (`CALENDARAUTO()` como punto de partida)
- Relaciones con dirección de filtro explícita

Si MCP conectado → verificar que el esquema en el modelo coincide.
Si hay particiones NoData → activar el skill `powerbi-dax-auditor`.

---

## Etapa 4 — Medidas DAX

Orden de creación:
1. **Primero**: las medidas mandatorias de la intención declarada
2. **Segundo**: variaciones y comparaciones de esas medidas (vs. período, vs. meta)
3. **Tercero**: medidas complementarias sugeridas por Claude (con aprobación)
4. **Siempre**: DIVIDE() para divisiones, nunca el operador /

Si MCP conectado → subir medidas directamente con `measure_operations → Create`.
Mostrar lista de medidas creadas (nombre + expresión + tabla) antes de continuar.

---

## Etapa 5 — Diseño de Visuales y Estilo

### AL ENTRAR A ESTA ETAPA: activar skills especializadas

**Para KPIs y tarjetas** → activar `html-kpi-cards` inmediatamente.
No esperar a que el analista lo pida. No preguntar si quiere HTML Content.
Simplemente construir las tarjetas con esa skill y presentarlas.

**Para cualquier gráfica** → activar `deneb-chart-generator` inmediatamente.
No proponer el equivalente nativo de Power BI. Generar el spec Vega-Lite completo.

### Jerarquía de decisión de diseño:

1. **El analista da referencia visual** (imagen, paleta, descripción) → Claude la sigue fielmente
2. **El analista no especifica** → Claude decide aplicando principios de dashboard de negocio

### Principios cuando Claude decide el diseño:

- **Claridad primero**: el dato más importante debe ser lo primero que el ojo encuentre
- **Interacción obvia**: slicers y filtros deben verse como controles
- **Economía visual**: sin decoración sin propósito
- **Contexto siempre**: todo KPI necesita una comparación visible
- **Coherencia**: misma paleta, tipografía e iconos en todo el dashboard

**Paleta default (si no se especifica):**
- Fondo claro: `#FFFFFF` / `#F8F9FA` con acento único consistente
- Fondo oscuro: `#1A1A2E` con acentos en el color dominante del cliente
- Tipografía: Segoe UI en todos los visuals

### Árbol de decisión visual (skill responsable):

| Necesidad | Visual | Skill |
|-----------|--------|-------|
| 4-6 KPIs principales | HTML Content — número grande, hover, **variar diseño por reporte** | `html-kpi-cards` |
| Tendencia temporal | Deneb line/area — peak/low, YoY% | `deneb-chart-generator` |
| Comparación por categoría | Deneb bar horizontal — ranking dinámico | `deneb-chart-generator` |
| Presupuesto vs. Real | Deneb bullet chart + HTML KPI variación | ambas |
| Distribución | Deneb beeswarm o histogram | `deneb-chart-generator` |
| Geografía | Mapa nativo Power BI | (único caso nativo permitido) |
| Tabla de detalle interactiva (cross-filtra) | Deneb (grid de marcas text) | `deneb-chart-generator` |
| Tabla de detalle de lectura (semáforos/badges) | HTML Content | `html-kpi-cards` |
| Relación entre variables | Deneb scatter — burbuja como tercera variable | `deneb-chart-generator` |
| **Filtros** | **Barra Navara (`navara_filter`)** con `accent` = paleta | `SISTEMA.md §7` |

Para cada visual: generar spec/medida COMPLETO listo para usar, nunca fragmentos.

**Interactividad obligatoria:** toda gráfica Deneb debe cross-filtrar la página — clic en
una barra/punto → las demás gráficas Y las tarjetas HTML cambian (`selection:true` en
`usermeta`, ver `SISTEMA.md §8`). Verificarlo siempre tras construir.

**Estética anti-"IA":** sin emojis (🎉📊✅) en ningún texto del dashboard. Glifos de delta
`▲▼` sí (son BI estándar). Labels concretos del dominio, no frases de relleno. Una sola
paleta de acento en tarjetas, gráficas, tablas y el filtro Navara.

### Cómo se materializan los visuales

Los specs Deneb y las medidas HTML no se quedan en el chat: se **integran al spec del
dashboard** (un JSON) y se construyen con el motor. Cada gráfica Deneb debe llevar la
interactividad hover+click (ver `deneb-chart-generator` y `SISTEMA.md §8`). Las tarjetas
HTML deben coincidir en **orientación** (fila vs columna) y **tema** (claro vs oscuro)
con el espacio y la página (ver `html-kpi-cards` y `SISTEMA.md §6`).

---

## Etapa 6 — Layout (se EJECUTA, no solo se sugiere)

El layout se construye realmente con el grid del motor (`grid:{cols,rows,margin,gutter}`
en el spec). No es una guía en texto — Claude arma el JSON y corre `build-dashboard`.

### Buenas prácticas globales (obligatorias cuando Claude decide el acomodo)

- **Lo más importante primero:** el KPI/visual que responde la intención va arriba o a la izquierda, con mayor peso visual.
- **Controles agrupados:** los filtros van en la barra Navara (tira superior), nunca slicers dispersos.
- **Sidebar de KPIs** (tarjeta HTML vertical) para liberar la fila superior a una gráfica grande.
- **Respirar:** márgenes y gutters consistentes (el grid los garantiza); sin decoración inútil.
- **Coherencia:** una sola paleta de acento, Segoe UI, mismos radios en todo el dashboard.
- **Negocio primero:** estructura e información que importan al analista; un dashboard bonito que no responde la intención está mal.

### Filtros — barra Navara (método estándar)

Todo filtro se hace con el custom visual **Navara** (`navara_filter` en el spec). Un solo
visual maneja N columnas (pills + panel "Más Filtros"). Reglas (detalle en `SISTEMA.md §7`):
- Pasar `accent` = color de acento del dashboard para que combine. **Nunca dejarlo con el
  morado por defecto si la paleta es otra.**
- El analista debe **importar el `.pbiviz` una vez por reporte** — entregarle las
  instrucciones exactas de §7.3 y esperar su confirmación antes de construir.
- Usar SOLO los apartados de filtros; los tabs decorativos de Navara NO sirven para
  navegar entre páginas.

### Botones (nativos, cuidados)

Navegación entre páginas y abrir/cerrar paneles = `action_button` nativos lo más bonitos
posible (fondo = acento o neutro de la paleta, texto contrastado, esquinas redondeadas,
alto ≥ 28px). El cross-filtrado NO se hace con botones, sino con la interacción de las
gráficas Deneb y Navara.

### Multi-página

Trabajar **una página a la vez**: un spec por página, cada uno con su `build-dashboard`.
Construir y revisar página por página. Cada página lleva su propia barra Navara. Mantener
paleta y estilo idénticos entre páginas. Detalle en `SISTEMA.md §9.4`.

### Layout de referencia (implementado)

```
┌───────────────── barra Navara (filtros, full-width) ─────────────────┐
├────────┬──────────────────────────────────┬──────────┐
│ KPIs   │  Gráfica principal (intención)   │ Gráfica  │
│ (side- │──────────────────────────────────┤ sec.     │   clic en barra
│  bar   │  Gráfica            │  Gráfica    │          │   → todo cross-
│  vert.)│  tendencia          │  comparación│          │     filtra
└────────┴──────────────────────────────────┴──────────┘
```

Plantilla viva: `gen_pagina1_pro.py` → `pagina1_pro.json`; Navara mínimo: `filtros_test.json`.

---

## Etapa 7 — Revisión y Correcciones

Una vez armado el dashboard, Claude queda en modo soporte activo.
El analista describe en lenguaje natural lo que quiere cambiar.

Claude puede atender activando la skill correspondiente:
- Ajustes a tarjetas KPI o tablas HTML → `html-kpi-cards` → subir via MCP
- Modificación de specs Deneb → `deneb-chart-generator` → entregar spec actualizado
- Medidas DAX adicionales → crear y subir via MCP directamente
- Diagnóstico de visuals con datos inesperados → revisar medidas + relaciones
- Optimización de rendimiento → revisar medidas con CALCULATE innecesarios

**Cómo entra el analista a esta etapa:**
Simplemente describe lo que ve: "esta barra debería cambiar de color cuando supera la meta"
es suficiente para que Claude interprete, active la skill correcta y entregue la solución.

**Mecánica de la corrección:**
- Cambios a visuales/layout → editar el spec y `pbi-refresh build-dashboard` (PBI cerrado).
- Cambios a medidas DAX/HTML → via MCP (PBI abierto) o editando el `.tmdl` (PBI cerrado).
- Siempre correr el lint (`build-dashboard` lo hace solo); si trae items, `fix-page`.

---

## Qué NO hacer nunca

- Proponer o construir medidas sin haber confirmado la intención (Etapa 2)
- Usar `/` para división en DAX — siempre `DIVIDE(num, den, 0)`
- Crear más de 7 KPIs en la vista principal sin aprobación del analista
- Ignorar o sustituir los KPIs mandatorios con sugerencias propias
- Subir medidas via MCP sin mostrar primero qué se va a crear
- Terminar en Etapa 6 — siempre ofrecer la Etapa 7 de correcciones
- **Usar visuals nativos de Power BI** para KPIs o gráficas — siempre HTML Content o Deneb
- **Esperar a que el analista pida Deneb o HTML Content** — activar esas skills automáticamente en Etapa 5
- **Editar archivos PBIR con Power BI abierto** — cerrar primero (usar `pbi-refresh`); el MCP sí necesita PBI abierto
- **Entregar specs Deneb/medidas como texto suelto** — integrarlas al spec del dashboard y correr `build-dashboard`
- **Olvidar el cross-filter en Deneb** (`selection:true`) — clic en barra debe cambiar gráficas Y tarjetas; ni la orientación/tema correctos en HTML (ver `SISTEMA.md` §8, §10)
- **Usar slicers nativos para filtrar** — el filtro es la barra Navara (`navara_filter`)
- **Dejar Navara con el morado por defecto** cuando la paleta del dashboard es otra — pasar `accent` = color del dashboard
- **Usar los tabs decorativos de Navara para navegar** entre páginas — la navegación es con `action_button` nativos
- **Poner emojis** (🎉📊✅🚀) o texto de relleno entusiasta — dashboards de negocio, sobrios; glifos de delta `▲▼` sí están permitidos
- **Omitir `html,body{height:100%;overflow:hidden}`** al inicio del CSS de HTML Content — sin esto queda espacio vacío al fondo
- **Usar px fijos** en CSS de HTML Content — siempre `clamp()` con `vh`/`vw` para que sea responsive
- **Repetir la misma tarjeta HTML idéntica en todos los proyectos** — variar el diseño según el reporte
- **Construir un dashboard multipágina de una sola vez** — una página a la vez, un spec por página
- **Reutilizar GUIDs de Deneb/HTML Content de otro proyecto** — correr `detect-custom` al inicio de cada proyecto nuevo
