#!/usr/bin/env python3
"""
pbir_tool.py — Editor de reportes Power BI (formato PBIR) para Claude
Permite mover visuals, gestionar páginas y modificar layout vía archivos JSON.

Uso:
  py pbir_tool.py --report <ruta_definition> <comando> [opciones]
  py pbir_tool.py --report . <comando> [opciones]   # si ya estás en /definition

Comandos disponibles:
  list-pages
  list-visuals --page <nombre o id>
  move-visual  --page <nombre> --visual <id> [--x N] [--y N] [--width N] [--height N]
  rename-page  --page <nombre> --name <nuevo nombre>
  add-page     --name <nombre> [--width N] [--height N]
  delete-page  --page <nombre>
  reorder-pages --pages p1 p2 p3 ...
  hide-page    --page <nombre>
  show-page    --page <nombre>
  set-page-size --page <nombre> --width N --height N
  delete-visual --page <nombre> --visual <id>
  visual-info  --page <nombre> --visual <id>
"""

import json
import os
import sys
import uuid
import shutil
import argparse
from pathlib import Path

import pbir_layout as layout
import pbir_templates as tpl


# ──────────────────────────────────────────────
# Helpers internos
# ──────────────────────────────────────────────

def _read_json(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def _write_json(path: str, data: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def _find_page(report_dir: str, name: str) -> str | None:
    """Resuelve nombre de página (displayName o ID) a ID de carpeta."""
    pages_dir = os.path.join(report_dir, "pages")
    if not os.path.exists(pages_dir):
        return None
    for folder in os.listdir(pages_dir):
        page_json = os.path.join(pages_dir, folder, "page.json")
        if os.path.exists(page_json):
            page = _read_json(page_json)
            if page.get("displayName", "").lower() == name.lower() or folder == name:
                return folder
    return None

def _get_bindings(visual_data: dict) -> list[str]:
    """Extrae las medidas/columnas vinculadas a un visual."""
    bindings = []
    query_state = visual_data.get("query", {}).get("queryState", {})
    for role, role_data in query_state.items():
        for proj in role_data.get("projections", []):
            field = proj.get("field", {})
            if "Measure" in field:
                m = field["Measure"]
                entity = m.get("Expression", {}).get("SourceRef", {}).get("Entity", "")
                prop = m.get("Property", "")
                bindings.append(f"[{entity}].[{prop}] ({role})")
            elif "Column" in field:
                c = field["Column"]
                entity = c.get("Expression", {}).get("SourceRef", {}).get("Entity", "")
                prop = c.get("Property", "")
                bindings.append(f"[{entity}].[{prop}] (columna, {role})")
    return bindings

def _get_visual_title(visual_data: dict) -> str:
    try:
        objects = visual_data.get("objects", {})
        if "title" in objects:
            props = objects["title"][0].get("properties", {})
            value = props.get("text", {}).get("expr", {}).get("Literal", {}).get("Value", "")
            return value.strip("'\"")
    except Exception:
        pass
    return ""


# ──────────────────────────────────────────────
# Operaciones de páginas
# ──────────────────────────────────────────────

def list_pages(report_dir: str) -> dict:
    pages_meta = _read_json(os.path.join(report_dir, "pages", "pages.json"))
    result = []
    for i, page_id in enumerate(pages_meta.get("pageOrder", [])):
        page_json = os.path.join(report_dir, "pages", page_id, "page.json")
        if not os.path.exists(page_json):
            continue
        page = _read_json(page_json)
        visuals_dir = os.path.join(report_dir, "pages", page_id, "visuals")
        visual_count = len(os.listdir(visuals_dir)) if os.path.exists(visuals_dir) else 0
        result.append({
            "order": i + 1,
            "id": page_id,
            "displayName": page.get("displayName", ""),
            "visibility": page.get("visibility", "visible"),
            "width": page.get("width", 1280),
            "height": page.get("height", 720),
            "visualCount": visual_count,
        })
    return {"pages": result, "activePage": pages_meta.get("activePageName")}


def add_page(report_dir: str, name: str, width: int = 1280, height: int = 720) -> dict:
    new_id = "ReportSection" + uuid.uuid4().hex[:20]
    page_dir = os.path.join(report_dir, "pages", new_id)
    os.makedirs(os.path.join(page_dir, "visuals"), exist_ok=True)

    page_data = {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json",
        "name": new_id,
        "displayName": name,
        "displayOption": "FitToPage",
        "height": height,
        "width": width,
    }
    _write_json(os.path.join(page_dir, "page.json"), page_data)

    pages_meta_path = os.path.join(report_dir, "pages", "pages.json")
    pages_meta = _read_json(pages_meta_path)
    pages_meta["pageOrder"].append(new_id)
    _write_json(pages_meta_path, pages_meta)

    return {"success": True, "pageId": new_id, "displayName": name}


def delete_page(report_dir: str, page: str) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}

    pages_meta_path = os.path.join(report_dir, "pages", "pages.json")
    pages_meta = _read_json(pages_meta_path)
    pages_meta["pageOrder"] = [p for p in pages_meta["pageOrder"] if p != page_id]
    if pages_meta.get("activePageName") == page_id:
        pages_meta["activePageName"] = pages_meta["pageOrder"][0] if pages_meta["pageOrder"] else ""
    _write_json(pages_meta_path, pages_meta)

    shutil.rmtree(os.path.join(report_dir, "pages", page_id))
    return {"success": True, "deleted": page, "pageId": page_id}


def rename_page(report_dir: str, page: str, new_name: str) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    page_json_path = os.path.join(report_dir, "pages", page_id, "page.json")
    page_data = _read_json(page_json_path)
    old_name = page_data.get("displayName", "")
    page_data["displayName"] = new_name
    _write_json(page_json_path, page_data)
    return {"success": True, "oldName": old_name, "newName": new_name, "pageId": page_id}


def reorder_pages(report_dir: str, page_names: list[str]) -> dict:
    pages_meta_path = os.path.join(report_dir, "pages", "pages.json")
    pages_meta = _read_json(pages_meta_path)
    current = pages_meta.get("pageOrder", [])

    resolved = []
    not_found = []
    for name in page_names:
        pid = _find_page(report_dir, name)
        if pid:
            resolved.append(pid)
        else:
            not_found.append(name)

    # Páginas no mencionadas van al final
    remaining = [p for p in current if p not in resolved]
    pages_meta["pageOrder"] = resolved + remaining
    _write_json(pages_meta_path, pages_meta)

    return {
        "success": True,
        "newOrder": resolved + remaining,
        "warnings": [f"No encontrada: '{n}'" for n in not_found] if not_found else [],
    }


def set_page_visibility(report_dir: str, page: str, hidden: bool) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    page_json_path = os.path.join(report_dir, "pages", page_id, "page.json")
    page_data = _read_json(page_json_path)
    if hidden:
        page_data["visibility"] = "HiddenInViewMode"
    else:
        page_data.pop("visibility", None)
    _write_json(page_json_path, page_data)
    return {"success": True, "page": page, "hidden": hidden}


def set_page_size(report_dir: str, page: str, width: int, height: int) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    page_json_path = os.path.join(report_dir, "pages", page_id, "page.json")
    page_data = _read_json(page_json_path)
    page_data["width"] = width
    page_data["height"] = height
    _write_json(page_json_path, page_data)
    return {"success": True, "page": page, "width": width, "height": height}


# ──────────────────────────────────────────────
# Operaciones de visuals
# ──────────────────────────────────────────────

def list_visuals(report_dir: str, page: str) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}

    visuals_dir = os.path.join(report_dir, "pages", page_id, "visuals")
    result = []
    for folder in sorted(os.listdir(visuals_dir)):
        vpath = os.path.join(visuals_dir, folder, "visual.json")
        if not os.path.exists(vpath):
            continue
        v = _read_json(vpath)
        pos = v.get("position", {})
        vdata = v.get("visual", {})
        result.append({
            "id": folder,
            "visualType": vdata.get("visualType", "unknown"),
            "title": _get_visual_title(vdata),
            "position": {
                "x": round(pos.get("x", 0), 1),
                "y": round(pos.get("y", 0), 1),
                "width": round(pos.get("width", 0), 1),
                "height": round(pos.get("height", 0), 1),
                "z": pos.get("z", 0),
            },
            "bindings": _get_bindings(vdata),
        })
    return {"page": page, "pageId": page_id, "visuals": result}


def visual_info(report_dir: str, page: str, visual: str) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    vpath = os.path.join(report_dir, "pages", page_id, "visuals", visual, "visual.json")
    if not os.path.exists(vpath):
        return {"error": f"Visual '{visual}' no encontrado"}
    v = _read_json(vpath)
    return {"id": visual, "pageId": page_id, "raw": v}


def move_visual(
    report_dir: str, page: str, visual: str,
    x: float = None, y: float = None,
    width: float = None, height: float = None,
) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}

    vpath = os.path.join(report_dir, "pages", page_id, "visuals", visual, "visual.json")
    if not os.path.exists(vpath):
        return {"error": f"Visual '{visual}' no encontrado en página '{page}'"}

    v = _read_json(vpath)
    before = dict(v.get("position", {}))

    if x is not None:      v["position"]["x"] = x
    if y is not None:      v["position"]["y"] = y
    if width is not None:  v["position"]["width"] = width
    if height is not None: v["position"]["height"] = height

    _write_json(vpath, v)
    return {
        "success": True,
        "visual": visual,
        "page": page,
        "before": {k: round(v2, 1) if isinstance(v2, float) else v2 for k, v2 in before.items()},
        "after": {k: round(v2, 1) if isinstance(v2, float) else v2 for k, v2 in v["position"].items()},
    }


def delete_visual(report_dir: str, page: str, visual: str) -> dict:
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    vpath = os.path.join(report_dir, "pages", page_id, "visuals", visual)
    if not os.path.exists(vpath):
        return {"error": f"Visual '{visual}' no encontrado"}
    shutil.rmtree(vpath)
    return {"success": True, "deleted": visual, "page": page}


# ──────────────────────────────────────────────
# Creación de visuales y dashboards
# ──────────────────────────────────────────────

def detect_custom_type(report_dir: str, prefix: str) -> str | None:
    """Busca en el reporte el visualType real de un custom visual instalado
    (ej. prefix='deneb' o 'htmlContent') para usar su GUID exacto."""
    pages_dir = os.path.join(report_dir, "pages")
    if not os.path.exists(pages_dir):
        return None
    for page_folder in os.listdir(pages_dir):
        vis_dir = os.path.join(pages_dir, page_folder, "visuals")
        if not os.path.isdir(vis_dir):
            continue
        for vfolder in os.listdir(vis_dir):
            vpath = os.path.join(vis_dir, vfolder, "visual.json")
            if not os.path.exists(vpath):
                continue
            try:
                vt = _read_json(vpath).get("visual", {}).get("visualType", "")
            except Exception:
                continue
            if vt.startswith(prefix):
                return vt
    return None


def _write_visual_container(report_dir: str, page_id: str, container: dict) -> str:
    """Escribe un visual.json en su carpeta. Devuelve el id del visual."""
    name = container["name"]
    vdir = os.path.join(report_dir, "pages", page_id, "visuals", name)
    os.makedirs(vdir, exist_ok=True)
    _write_json(os.path.join(vdir, "visual.json"), container)
    return name


def _pos_from_cell(cell: dict) -> dict:
    """Convierte {x,y,width,height} (grid) a {x,y,w,h} (templates)."""
    return {"x": cell["x"], "y": cell["y"], "w": cell["width"], "h": cell["height"]}


# Mapa de tipos del spec → fábrica de plantilla
def _build_one(vspec: dict, pos: dict, name: str, custom_types: dict) -> dict:
    t = vspec["type"]
    title = vspec.get("title")
    if t == "card":
        return tpl.card(name, pos, vspec["entity"], vspec["measure"],
                        display=vspec.get("display"))
    if t == "html_card":
        return tpl.html_card(name, pos, vspec["entity"], vspec["measure"],
                             custom_type=custom_types.get("html"))
    if t == "bar_chart":
        return tpl.bar_chart(name, pos, vspec["category"], vspec["y"],
                             series=vspec.get("series"), title=title,
                             color_id=vspec.get("color_id", 7))
    if t == "column_chart":
        return tpl.column_chart(name, pos, vspec["category"], vspec["y"],
                                series=vspec.get("series"), title=title,
                                color_id=vspec.get("color_id", 7))
    if t == "line_chart":
        return tpl.line_chart(name, pos, vspec["category"], vspec["y"],
                              series=vspec.get("series"), title=title,
                              color_id=vspec.get("color_id", 7))
    if t == "donut_chart":
        return tpl.donut_chart(name, pos, vspec["category"], vspec["y"], title=title)
    if t == "pie_chart":
        return tpl.pie_chart(name, pos, vspec["category"], vspec["y"], title=title)
    if t == "slicer":
        return tpl.slicer(name, pos, vspec["entity"], vspec["column"],
                          mode=vspec.get("mode", "Dropdown"), title=title)
    if t == "navara_filter":
        return tpl.navara_filter(name, pos, vspec["fields"], accent=vspec.get("accent"))
    if t == "custom_pill":
        return tpl.custom_pill(name, pos, vspec["entity"], vspec["column"])
    if t == "pill_slicer":
        return tpl.pill_slicer(name, pos, vspec["entity"], vspec["column"],
                               label=vspec.get("label"),
                               label_measure=vspec.get("label_measure"),
                               label_entity=vspec.get("label_entity", "DAX Medidas"))
    if t == "table":
        return tpl.table(name, pos, vspec["fields"], title=title)
    if t == "textbox":
        return tpl.textbox(name, pos, vspec["text"],
                           font_size=vspec.get("font_size", 14),
                           color_hex=vspec.get("color", "#000000"),
                           bold=vspec.get("bold", False))
    if t == "deneb":
        return tpl.deneb(name, pos, vspec["dataset"], vspec["vega"],
                         custom_type=custom_types.get("deneb"))
    if t == "action_button":
        return tpl.action_button(name, pos, vspec["text"], vspec["bookmark_id"],
                                 bg_hex=vspec.get("bg", "#6A0DAD"),
                                 text_hex=vspec.get("text_color", "#FFFFFF"),
                                 font_size=vspec.get("font_size", 12),
                                 radius=vspec.get("radius", 8),
                                 shadow=vspec.get("shadow", True),
                                 border_hex=vspec.get("border"),
                                 is_hidden=vspec.get("is_hidden", False))
    if t == "background_rect":
        return tpl.background_rect(name, pos,
                                   color_hex=vspec.get("color", "#FFFFFF"),
                                   border_hex=vspec.get("border", "#E0D6F5"),
                                   is_hidden=vspec.get("is_hidden", False))
    raise ValueError(f"Tipo de visual no soportado: '{t}'")


def build_dashboard(report_dir: str, spec_path: str) -> dict:
    """Construye un dashboard completo desde un spec JSON.

    Estructura del spec:
      {
        "page": "Pagina 1",          # usar página existente (por nombre o id)
        "newPage": "Dashboard",       # O crear una página nueva con este nombre
        "clear": false,               # borrar visuales existentes antes de construir
        "canvas": {"width":1280,"height":720},
        "grid": {"cols":12,"rows":8,"margin":24,"gutter":12},
        "visuals": [ { "type":..., "at":{col,row,colspan,rowspan} | "abs":{x,y,w,h}, ... } ]
      }
    """
    with open(spec_path, encoding="utf-8") as f:
        spec = json.load(f)

    # Resolver custom visual GUIDs reales del reporte
    custom_types = {
        "deneb": detect_custom_type(report_dir, "deneb") or tpl.DENEB_TYPE,
        "html": detect_custom_type(report_dir, "htmlContent") or tpl.HTMLCONTENT_TYPE,
    }

    canvas = spec.get("canvas", {})
    width = canvas.get("width", 1280)
    height = canvas.get("height", 720)

    # Página destino
    if spec.get("newPage"):
        res = add_page(report_dir, spec["newPage"], width, height)
        page_id = res["pageId"]
        page_name = spec["newPage"]
    else:
        page_name = spec["page"]
        page_id = _find_page(report_dir, page_name)
        if not page_id:
            return {"error": f"Página '{page_name}' no encontrada"}

    # Limpiar visuales existentes si se pide
    cleared = 0
    if spec.get("clear"):
        vis_dir = os.path.join(report_dir, "pages", page_id, "visuals")
        if os.path.isdir(vis_dir):
            for vf in os.listdir(vis_dir):
                shutil.rmtree(os.path.join(vis_dir, vf))
                cleared += 1

    # Grid
    g = spec.get("grid", {})
    grid = layout.Grid(
        width=width, height=height,
        cols=g.get("cols", 12), rows=g.get("rows", 8),
        margin=g.get("margin", 24), gutter=g.get("gutter", 12),
    )

    created, errors = [], []
    z = 1000
    for i, vspec in enumerate(spec.get("visuals", [])):
        z += 1000
        try:
            if "at" in vspec:
                cell = grid.cell(
                    vspec["at"]["col"], vspec["at"]["row"],
                    vspec["at"].get("colspan", 1), vspec["at"].get("rowspan", 1),
                )
                pos = _pos_from_cell(cell)
            elif "abs" in vspec:
                a = vspec["abs"]
                pos = {"x": a["x"], "y": a["y"], "w": a["w"], "h": a["h"]}
            else:
                raise ValueError("cada visual necesita 'at' (grid) o 'abs' (px)")

            name = vspec.get("id") or tpl.new_id()
            container = _build_one(vspec, pos, name, custom_types)
            container["position"]["z"] = z
            container["position"]["tabOrder"] = z
            _write_visual_container(report_dir, page_id, container)
            created.append({"id": name, "type": vspec["type"],
                            "pos": {k: round(v, 1) for k, v in pos.items()}})
        except Exception as e:
            errors.append({"index": i, "type": vspec.get("type"), "error": str(e)})

    # ── Filter panel (opcional) ──────────────────────────────────────────────
    fp = spec.get("filterPanel")
    if fp:
        bm_result = _build_filter_panel(report_dir, page_id, fp, grid, custom_types, z + 1000)
        created.extend(bm_result.get("created", []))
        errors.extend(bm_result.get("errors", []))

    # ── Lint final: atrapar props/keys que PBI rechazaría al abrir ────────────
    lint = validate_page(report_dir, page_name)

    return {
        "success": len(errors) == 0 and lint.get("clean", True),
        "page": page_name, "pageId": page_id,
        "customTypes": custom_types,
        "cleared": cleared,
        "created": created,
        "errors": errors,
        "lint": lint.get("issues", []),
    }


def _write_bookmark(report_dir: str, bm_name: str, display_name: str,
                    page_id: str, visible_ids: list, hidden_ids: list,
                    vtype_map: dict) -> None:
    """Escribe un archivo .bookmark.json y lo registra en bookmarks.json."""
    bm_dir = Path(report_dir) / "bookmarks"
    bm_dir.mkdir(exist_ok=True)

    containers = {}
    for vid in visible_ids:
        containers[vid] = {"singleVisual": {"visualType": vtype_map.get(vid, "slicer"), "objects": {}}}
    for vid in hidden_ids:
        containers[vid] = {"singleVisual": {
            "visualType": vtype_map.get(vid, "slicer"),
            "objects": {},
            "display": {"mode": "hidden"},
        }}

    bm = {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmark/2.1.0/schema.json",
        "displayName": display_name,
        "name": bm_name,
        "options": {
            "applyOnlyToTargetVisuals": True,
            "targetVisualNames": visible_ids + hidden_ids,
            "suppressData": True,
        },
        "explorationState": {
            "version": "1.3",
            "activeSection": page_id,
            "sections": {page_id: {"visualContainers": containers}},
        },
    }

    bm_file = bm_dir / f"{bm_name}.bookmark.json"
    _write_json(str(bm_file), bm)

    meta_file = bm_dir / "bookmarks.json"
    if meta_file.exists():
        meta = _read_json(str(meta_file))
    else:
        meta = {
            "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmarksMetadata/1.0.0/schema.json",
            "items": [],
        }
    if not any(it["name"] == bm_name for it in meta.get("items", [])):
        meta.setdefault("items", []).append({"name": bm_name})
    _write_json(str(meta_file), meta)


def _build_filter_panel(report_dir: str, page_id: str, fp: dict,
                        grid: "layout.Grid", custom_types: dict, base_z: int) -> dict:
    """
    Crea el panel de filtros desplegable:
      filtros_button (visible) → abre el panel
      cerrar_button (oculto)   → cierra el panel
      background_rect (oculto) + slicers (ocultos)
    Además escribe los 2 bookmarks.
    """
    import uuid as _uuid
    created, errors = [], []

    bm_open  = "bm_panel_open_"  + _uuid.uuid4().hex[:12]
    bm_close = "bm_panel_close_" + _uuid.uuid4().hex[:12]

    def _calc_pos(vspec):
        if "at" in vspec:
            cell = grid.cell(vspec["at"]["col"], vspec["at"]["row"],
                             vspec["at"].get("colspan", 1), vspec["at"].get("rowspan", 1))
            return _pos_from_cell(cell)
        a = vspec["abs"]
        return {"x": a["x"], "y": a["y"], "w": a["w"], "h": a["h"]}

    def _make(vspec, z_val):
        pos = _calc_pos(vspec)
        name = vspec.get("id") or tpl.new_id()
        container = _build_one(vspec, pos, name, custom_types)
        container["position"]["z"] = z_val
        container["position"]["tabOrder"] = z_val
        _write_visual_container(report_dir, page_id, container)
        created.append({"id": name, "type": vspec["type"],
                        "pos": {k: round(v, 1) for k, v in pos.items()}})
        return name

    try:
        # 1. Botón Filtros (visible) — dispara bookmark "abrir"
        filtros_spec = dict(fp["filtrosButton"])
        filtros_spec["type"] = "action_button"
        filtros_spec["bookmark_id"] = bm_open
        filtros_spec["is_hidden"] = False
        filtros_id = _make(filtros_spec, base_z + 100)

        # 2. Botón Cerrar (oculto) — dispara bookmark "cerrar"
        cerrar_spec = dict(fp["cerrarButton"])
        cerrar_spec["type"] = "action_button"
        cerrar_spec["bookmark_id"] = bm_close
        cerrar_spec["is_hidden"] = True
        cerrar_id = _make(cerrar_spec, base_z + 200)

        # 3. Fondo del panel (oculto)
        bg_spec = dict(fp.get("background", {}))
        bg_spec["type"] = "background_rect"
        bg_spec["is_hidden"] = True
        bg_id = _make(bg_spec, base_z - 100) if "at" in bg_spec or "abs" in bg_spec else None

        # 4. Slicers del panel (ocultos)
        slicer_ids = []
        for sl_spec in fp.get("slicers", []):
            sl = dict(sl_spec)
            sl["type"] = "slicer"
            sl_id = _make(sl, base_z + 150)
            slicer_ids.append(sl_id)

        # 5. Visuales adicionales en el panel (Deneb, html_card, etc.) — ocultos
        def _bm_type_for(spec_type: str) -> str:
            return {
                "slicer":           "slicer",
                "action_button":    "actionButton",
                "background_rect":  "textbox",
                "deneb":            custom_types.get("deneb", "deneb"),
                "html_card":        custom_types.get("htmlContent", "htmlContent"),
                "card":             "card",
                "bar_chart":        "barChart",
                "column_chart":     "clusteredBarChart",
                "line_chart":       "lineChart",
                "donut_chart":      "donutChart",
            }.get(spec_type, spec_type)

        extra_ids = []
        for v_spec in fp.get("visuals", []):
            v_id = _make(dict(v_spec), base_z + 150)
            extra_ids.append((v_id, v_spec.get("type", "slicer")))

        # Todos los IDs del panel
        panel_ids = ([cerrar_id]
                     + ([bg_id] if bg_id else [])
                     + slicer_ids
                     + [vid for vid, _ in extra_ids])

        vtype_map = {
            filtros_id: "actionButton",
            cerrar_id:  "actionButton",
            **({bg_id: "textbox"} if bg_id else {}),
            **{sid: "slicer" for sid in slicer_ids},
            **{vid: _bm_type_for(vt) for vid, vt in extra_ids},
        }

        # Bookmark "panel abierto": filtros OCULTO, resto VISIBLE
        _write_bookmark(report_dir, bm_open, "Panel Filtros Abierto", page_id,
                        visible_ids=panel_ids,
                        hidden_ids=[filtros_id],
                        vtype_map=vtype_map)

        # Bookmark "panel cerrado": filtros VISIBLE, resto OCULTO
        _write_bookmark(report_dir, bm_close, "Panel Filtros Cerrado", page_id,
                        visible_ids=[filtros_id],
                        hidden_ids=panel_ids,
                        vtype_map=vtype_map)

        # Actualizar los botones con los bookmark IDs correctos
        # (ya están escritos, pero el bm_open/close son generados post-creación)
        # Re-escribir los action buttons con los IDs de bookmark correctos
        def _patch_button(btn_id, bm_id):
            vpath = os.path.join(report_dir, "pages", page_id,
                                 "visuals", btn_id, "visual.json")
            v = _read_json(vpath)
            v["visual"]["visualContainerObjects"]["visualLink"][0]["properties"]["bookmark"] = \
                {"expr": {"Literal": {"Value": f"'{bm_id}'"}}}
            _write_json(vpath, v)

        _patch_button(filtros_id, bm_open)
        _patch_button(cerrar_id, bm_close)

        # Inicializar los panel visuals como ocultos en su visual.json
        for vid in panel_ids:
            vpath = os.path.join(report_dir, "pages", page_id,
                                 "visuals", vid, "visual.json")
            v = _read_json(vpath)
            v["isHidden"] = True
            _write_json(vpath, v)

    except Exception as e:
        import traceback
        errors.append({"section": "filterPanel", "error": str(e),
                       "trace": traceback.format_exc()})

    return {"created": created, "errors": errors}


def add_visual(report_dir: str, page: str, spec_json: str) -> dict:
    """Crea un solo visual desde un spec JSON inline (mismo formato que build-dashboard)."""
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    vspec = json.loads(spec_json)
    custom_types = {
        "deneb": detect_custom_type(report_dir, "deneb") or tpl.DENEB_TYPE,
        "html": detect_custom_type(report_dir, "htmlContent") or tpl.HTMLCONTENT_TYPE,
    }
    if "abs" in vspec:
        a = vspec["abs"]
        pos = {"x": a["x"], "y": a["y"], "w": a["w"], "h": a["h"]}
    else:
        return {"error": "add-visual requiere 'abs':{x,y,w,h} en el spec"}
    name = vspec.get("id") or tpl.new_id()
    container = _build_one(vspec, pos, name, custom_types)
    _write_visual_container(report_dir, page_id, container)
    return {"success": True, "id": name, "type": vspec["type"], "page": page}


def place_next_to(report_dir: str, page: str, visual: str, reference: str,
                  side: str = "right", gap: float = 12,
                  match_size: bool = True) -> dict:
    """Coloca un visual junto a otro de referencia (posicionamiento relativo)."""
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}
    ref_path = os.path.join(report_dir, "pages", page_id, "visuals", reference, "visual.json")
    vis_path = os.path.join(report_dir, "pages", page_id, "visuals", visual, "visual.json")
    if not os.path.exists(ref_path):
        return {"error": f"Visual de referencia '{reference}' no encontrado"}
    if not os.path.exists(vis_path):
        return {"error": f"Visual '{visual}' no encontrado"}
    ref_pos = _read_json(ref_path)["position"]
    new_pos = layout.place_next_to(ref_pos, side=side, gap=gap, match_size=match_size)
    v = _read_json(vis_path)
    before = dict(v["position"])
    v["position"]["x"] = new_pos["x"]
    v["position"]["y"] = new_pos["y"]
    v["position"]["width"] = new_pos["width"]
    v["position"]["height"] = new_pos["height"]
    _write_json(vis_path, v)
    return {
        "success": True, "visual": visual, "reference": reference, "side": side,
        "before": {k: round(x, 1) if isinstance(x, float) else x for k, x in before.items()},
        "after": v["position"],
    }


# ──────────────────────────────────────────────
# Validación PBIR (lint) — atrapa los errores de esquema que PBI rechaza al abrir
# ──────────────────────────────────────────────

# Propiedades válidas por objeto de formato (whitelist mínima de lo que usamos).
# Si una propiedad no está aquí, PBI puede emitir "propiedad adicional ... no se pudo resolver".
_VALID_PROPS = {
    "dropShadow": {"show", "color", "position", "preset", "angle", "transparency"},
}
# Claves que PBIR NO acepta dentro de "visual" (vienen de la UI, no del esquema de archivo).
_FORBIDDEN_VISUAL_KEYS = {"howCreated"}


def validate_page(report_dir: str, page: str) -> dict:
    """Revisa los visual.json de una página buscando props/keys que PBI rechazaría."""
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}

    vis_dir = os.path.join(report_dir, "pages", page_id, "visuals")
    issues = []
    if os.path.isdir(vis_dir):
        for vid in os.listdir(vis_dir):
            vpath = os.path.join(vis_dir, vid, "visual.json")
            if not os.path.exists(vpath):
                continue
            v = _read_json(vpath)
            visual = v.get("visual", {})

            # 1. Claves prohibidas a nivel visual (howCreated, etc.)
            for k in _FORBIDDEN_VISUAL_KEYS:
                if k in visual:
                    issues.append({"visual": vid, "type": "forbidden_key",
                                   "detail": f"/visual/{k}", "fix": "eliminar"})

            # 2. Propiedades fuera de whitelist en objetos de formato conocidos
            for scope in ("objects", "visualContainerObjects"):
                for obj_name, entries in visual.get(scope, {}).items():
                    if obj_name not in _VALID_PROPS:
                        continue
                    allowed = _VALID_PROPS[obj_name]
                    for entry in entries:
                        for prop in entry.get("properties", {}):
                            if prop not in allowed:
                                issues.append({"visual": vid, "type": "extra_prop",
                                               "detail": f"/{scope}/{obj_name}/{prop}",
                                               "fix": "eliminar"})
    return {"page": page, "pageId": page_id, "clean": len(issues) == 0, "issues": issues}


def fix_page(report_dir: str, page: str) -> dict:
    """Corrige automáticamente los problemas que validate_page detecta."""
    page_id = _find_page(report_dir, page)
    if not page_id:
        return {"error": f"Página '{page}' no encontrada"}

    vis_dir = os.path.join(report_dir, "pages", page_id, "visuals")
    fixed = []
    if os.path.isdir(vis_dir):
        for vid in os.listdir(vis_dir):
            vpath = os.path.join(vis_dir, vid, "visual.json")
            if not os.path.exists(vpath):
                continue
            v = _read_json(vpath)
            visual = v.get("visual", {})
            changed = False

            for k in list(_FORBIDDEN_VISUAL_KEYS):
                if k in visual:
                    del visual[k]
                    fixed.append({"visual": vid, "removed": f"/visual/{k}"})
                    changed = True

            for scope in ("objects", "visualContainerObjects"):
                for obj_name, entries in visual.get(scope, {}).items():
                    if obj_name not in _VALID_PROPS:
                        continue
                    allowed = _VALID_PROPS[obj_name]
                    for entry in entries:
                        props = entry.get("properties", {})
                        for prop in [p for p in props if p not in allowed]:
                            del props[prop]
                            fixed.append({"visual": vid, "removed": f"/{scope}/{obj_name}/{prop}"})
                            changed = True

            if changed:
                _write_json(vpath, v)
    return {"page": page, "pageId": page_id, "fixedCount": len(fixed), "fixed": fixed}


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def build_parser():
    p = argparse.ArgumentParser(
        description="pbir_tool — Editor de reportes Power BI para Claude",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--report", required=True, help="Ruta a la carpeta definition del .Report")
    sub = p.add_subparsers(dest="cmd", metavar="comando")

    # Páginas
    sub.add_parser("list-pages", help="Listar todas las páginas")

    ap = sub.add_parser("add-page", help="Crear una nueva página")
    ap.add_argument("--name", required=True)
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)

    dp = sub.add_parser("delete-page", help="Eliminar una página")
    dp.add_argument("--page", required=True)

    rn = sub.add_parser("rename-page", help="Renombrar una página")
    rn.add_argument("--page", required=True)
    rn.add_argument("--name", required=True)

    ro = sub.add_parser("reorder-pages", help="Reordenar páginas")
    ro.add_argument("--pages", nargs="+", required=True, metavar="PÁGINA")

    hi = sub.add_parser("hide-page")
    hi.add_argument("--page", required=True)

    sh = sub.add_parser("show-page")
    sh.add_argument("--page", required=True)

    sz = sub.add_parser("set-page-size")
    sz.add_argument("--page", required=True)
    sz.add_argument("--width", type=int, required=True)
    sz.add_argument("--height", type=int, required=True)

    # Visuals
    lv = sub.add_parser("list-visuals", help="Listar visuals de una página")
    lv.add_argument("--page", required=True)

    vi = sub.add_parser("visual-info", help="Ver JSON completo de un visual")
    vi.add_argument("--page", required=True)
    vi.add_argument("--visual", required=True)

    mv = sub.add_parser("move-visual", help="Mover / redimensionar un visual")
    mv.add_argument("--page", required=True)
    mv.add_argument("--visual", required=True)
    mv.add_argument("--x", type=float)
    mv.add_argument("--y", type=float)
    mv.add_argument("--width", type=float)
    mv.add_argument("--height", type=float)

    dv = sub.add_parser("delete-visual", help="Eliminar un visual")
    dv.add_argument("--page", required=True)
    dv.add_argument("--visual", required=True)

    # Creación / layout
    bd = sub.add_parser("build-dashboard", help="Construir dashboard completo desde spec JSON")
    bd.add_argument("--spec", required=True, help="Ruta al archivo JSON del dashboard")

    av = sub.add_parser("add-visual", help="Añadir un visual desde spec JSON inline")
    av.add_argument("--page", required=True)
    av.add_argument("--spec-json", required=True, help="Spec JSON del visual (con 'abs')")

    pn = sub.add_parser("place-next-to", help="Colocar un visual junto a otro (relativo)")
    pn.add_argument("--page", required=True)
    pn.add_argument("--visual", required=True)
    pn.add_argument("--reference", required=True)
    pn.add_argument("--side", default="right", choices=["right", "left", "top", "bottom"])
    pn.add_argument("--gap", type=float, default=12)
    pn.add_argument("--no-match-size", action="store_true", help="No heredar tamaño del ref")

    dt = sub.add_parser("detect-custom", help="Detectar GUIDs de custom visuals (deneb/htmlContent)")

    vp = sub.add_parser("validate-page", help="Lint: detectar props/keys que PBI rechazaría al abrir")
    vp.add_argument("--page", required=True)

    fp = sub.add_parser("fix-page", help="Corregir automáticamente lo que validate-page detecta")
    fp.add_argument("--page", required=True)

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.cmd:
        parser.print_help()
        sys.exit(0)

    r = args.report

    dispatch = {
        "list-pages":    lambda: list_pages(r),
        "add-page":      lambda: add_page(r, args.name, args.width, args.height),
        "delete-page":   lambda: delete_page(r, args.page),
        "rename-page":   lambda: rename_page(r, args.page, args.name),
        "reorder-pages": lambda: reorder_pages(r, args.pages),
        "hide-page":     lambda: set_page_visibility(r, args.page, True),
        "show-page":     lambda: set_page_visibility(r, args.page, False),
        "set-page-size": lambda: set_page_size(r, args.page, args.width, args.height),
        "list-visuals":  lambda: list_visuals(r, args.page),
        "visual-info":   lambda: visual_info(r, args.page, args.visual),
        "move-visual":   lambda: move_visual(r, args.page, args.visual, args.x, args.y, args.width, args.height),
        "delete-visual": lambda: delete_visual(r, args.page, args.visual),
        "build-dashboard": lambda: build_dashboard(r, args.spec),
        "add-visual":    lambda: add_visual(r, args.page, args.spec_json),
        "place-next-to": lambda: place_next_to(r, args.page, args.visual, args.reference,
                                               args.side, args.gap, not args.no_match_size),
        "detect-custom": lambda: {
            "deneb": detect_custom_type(r, "deneb"),
            "htmlContent": detect_custom_type(r, "htmlContent"),
        },
        "validate-page": lambda: validate_page(r, args.page),
        "fix-page":      lambda: fix_page(r, args.page),
    }

    result = dispatch[args.cmd]()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
