# pbi.ps1 — Wrapper repetible para pbir_tool.py
# El proyecto activo se define en pbi.config.json (misma carpeta que este script).
#
# Uso:
#   .\pbi.ps1 pbi-init "C:\ruta\MiReporte.pbip"   # registra un proyecto nuevo
#   .\pbi.ps1 list-pages
#   .\pbi.ps1 build-dashboard --spec dashboard.json
#   .\pbi.ps1 pbi-close                            # cierra Power BI y espera
#   .\pbi.ps1 pbi-open                             # abre el .pbip del proyecto activo
#   .\pbi.ps1 pbi-refresh build-dashboard --spec dashboard.json  # cierra, escribe, abre

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ConfigPath = Join-Path $ScriptDir "pbi.config.json"
$TOOL = Join-Path $ScriptDir "pbir_tool.py"

function Load-Config {
    if (-not (Test-Path $ConfigPath)) {
        Write-Host "[pbi] No hay proyecto activo. Registra uno con:" -ForegroundColor Yellow
        Write-Host '      .\pbi.ps1 pbi-init "C:\ruta\MiReporte.pbip"' -ForegroundColor Yellow
        exit 1
    }
    return Get-Content $ConfigPath -Raw | ConvertFrom-Json
}

function Init-Project {
    param([string]$PbipPath)
    if (-not $PbipPath) {
        Write-Host "[pbi] Uso: .\pbi.ps1 pbi-init `"C:\ruta\MiReporte.pbip`"" -ForegroundColor Yellow
        exit 1
    }
    if (-not (Test-Path $PbipPath)) {
        Write-Host "[pbi] No existe el archivo: $PbipPath" -ForegroundColor Red
        exit 1
    }
    $pbip = (Resolve-Path $PbipPath).Path
    $dir  = Split-Path -Parent $pbip
    $base = [System.IO.Path]::GetFileNameWithoutExtension($pbip)

    # Autodetectar carpetas hermanas .Report y .SemanticModel
    $reportDir = Join-Path $dir "$base.Report\definition"
    $semDir    = Join-Path $dir "$base.SemanticModel"
    if (-not (Test-Path $reportDir)) {
        $cand = Get-ChildItem $dir -Directory -Filter "*.Report" | Select-Object -First 1
        if ($cand) { $reportDir = Join-Path $cand.FullName "definition" }
    }
    if (-not (Test-Path $semDir)) {
        $cand = Get-ChildItem $dir -Directory -Filter "*.SemanticModel" | Select-Object -First 1
        if ($cand) { $semDir = $cand.FullName }
    }

    # Buscar el .tmdl de medidas (tabla que solo contiene measures)
    $measuresTmdl = ""
    $tablesDir = Join-Path $semDir "definition\tables"
    if (Test-Path $tablesDir) {
        $tmdl = Get-ChildItem $tablesDir -Filter "*.tmdl" | Where-Object {
            $c = Get-Content $_.FullName -Raw
            ($c -match "measure ") -and ($c -notmatch "column ")
        } | Select-Object -First 1
        if ($tmdl) { $measuresTmdl = $tmdl.FullName }
    }

    $config = [ordered]@{
        name          = $base
        pbip          = $pbip
        report        = $reportDir
        semanticModel = $semDir
        measuresTmdl  = $measuresTmdl
    }
    $config | ConvertTo-Json | Out-File $ConfigPath -Encoding utf8
    Write-Host "[pbi] Proyecto activo registrado:" -ForegroundColor Green
    Write-Host "      name:          $base"
    Write-Host "      report:        $reportDir"
    Write-Host "      semanticModel: $semDir"
    Write-Host "      measuresTmdl:  $measuresTmdl"
    if (-not (Test-Path $reportDir)) { Write-Host "      [!] no se encontro .Report\definition — corrige pbi.config.json" -ForegroundColor Yellow }
    if (-not (Test-Path $semDir))    { Write-Host "      [!] no se encontro .SemanticModel — corrige pbi.config.json" -ForegroundColor Yellow }
}

function Close-PBI {
    $procs = Get-Process -Name "PBIDesktop" -ErrorAction SilentlyContinue
    if ($procs) {
        Write-Host "[pbi] Cerrando Power BI ($($procs.Count) proceso(s))..."
        $procs | Stop-Process -Force
        $t = 0
        while ((Get-Process -Name "PBIDesktop" -ErrorAction SilentlyContinue) -and $t -lt 15) {
            Start-Sleep -Milliseconds 500
            $t++
        }
        Write-Host "[pbi] Power BI cerrado."
    } else {
        Write-Host "[pbi] Power BI ya estaba cerrado."
    }
}

function Open-PBI {
    param($cfg)
    Write-Host "[pbi] Abriendo $($cfg.pbip) ..."
    Start-Process $cfg.pbip
    Write-Host "[pbi] Power BI iniciando (puede tardar unos segundos)."
}

switch ($args[0]) {
    "pbi-init" {
        Init-Project $args[1]
    }
    "pbi-close" {
        Close-PBI
    }
    "pbi-open" {
        $cfg = Load-Config
        Open-PBI $cfg
    }
    "pbi-refresh" {
        # Cierra PBI, ejecuta el comando restante, luego reabre
        $cfg = Load-Config
        Close-PBI
        $subcmd = $args[1..($args.Length-1)]
        py $TOOL --report $cfg.report @subcmd
        Open-PBI $cfg
    }
    default {
        $cfg = Load-Config
        py $TOOL --report $cfg.report @args
    }
}
