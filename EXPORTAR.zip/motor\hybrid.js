/* Divvy HYBRID generator — Fabric pipeline (grid, sidebar, pageNavigator, positioning)
   + custom visuals: Deneb (charts), HTML Content (cards), Filtro (filters).
   Reusable: swap the model/measure/field names and the page specs for any dataset. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const REPORT = 'C:/Users/lanfa/OneDrive/Escritorio/Divvy/Divvy.Report';
const PAGES_DIR = path.join(REPORT, 'definition', 'pages');
const VC = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.9.0/schema.json';
const PAGE_SCHEMA = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json';

// ---- custom visual GUIDs (must be imported into the report by the user) ----
const DENEB = 'deneb7E15AEF80B9E4D4F8E12924291ECE89A';
const HTML = 'htmlContent443BE3AD55E043BF878BED274D3A6855';
const FILTRO = 'filtroGeneralUniversal8A3E1F9C2B4D1E5F';

// ---- palette ----
const TEAL = '#0C8599', TEAL_TINT = '#C3FAE8', ORANGE = '#E8590C', BLUE = '#1098AD', GRAY = '#495057', ARR = '#3B5BDB';
const PAGE_BG = '#EEF2F6', SIDEBAR = '#0E2A3D', SIDEBAR_HL = '#16455C', INK = '#1F2933', MUTED = '#6B7A86', CARD_BORDER = '#E7EAEE';

const vid = () => crypto.randomBytes(10).toString('hex');

// ---- geometry: sidebar + content grid ----
const CW = 1920, CH = 1080, SIDE_W = 248;
const BODY = { x: 272, y: 150, w: 1616, h: 898 };
const CCOLS = 12, CROWS = 10, GX = 20, GY = 20;
const colW = (BODY.w - (CCOLS - 1) * GX) / CCOLS;
const rowH = (BODY.h - (CROWS - 1) * GY) / CROWS;
const snap = v => Math.round(v / 8) * 8;
function cg(c0, r0, c1, r1) {
  let x = snap(BODY.x + (c0 - 1) * (colW + GX));
  let y = snap(BODY.y + (r0 - 1) * (rowH + GY));
  let w = snap((c1 - c0) * colW + (c1 - c0 - 1) * GX);
  let h = snap((r1 - r0) * rowH + (r1 - r0 - 1) * GY);
  if (x + w > CW - 32) w = (CW - 32) - x;
  if (y + h > CH - 32) h = (CH - 32) - y;
  return { x, y, w, h };
}

// ---- literals / fields ----
const litExpr = v => ({ expr: { Literal: { Value: v } } });
const solid = hex => ({ solid: { color: { expr: { Literal: { Value: `'${hex}'` } } } } });
const col = (e, p) => ({ Column: { Expression: { SourceRef: { Entity: e } }, Property: p } });
const meas = (e, p) => ({ Measure: { Expression: { SourceRef: { Entity: e } }, Property: p } });
function projCol(e, p) { return { field: col(e, p), queryRef: `${e}.${p}`, nativeQueryRef: p }; }
function projMeas(e, p) { return { field: meas(e, p), queryRef: `${e}.${p}`, nativeQueryRef: p }; }

let Z = 1000;
const pos = (b, z) => ({ x: b.x, y: b.y, z: z != null ? z : (Z += 10), height: b.h, width: b.w, tabOrder: Z });

function write(pageName, v) {
  const dir = path.join(PAGES_DIR, pageName, 'visuals', v.name);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'visual.json'), JSON.stringify(v, null, 2));
}

// =================== custom-visual factories ===================

// HTML Content: one measure returning an HTML string
function htmlCard(entity, measure, box) {
  return { $schema: VC, name: vid(), position: pos(box), visual: {
    visualType: HTML,
    query: { queryState: { content: { projections: [projMeas(entity, measure)] } } },
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('false') } }],
      border: [{ properties: { show: litExpr('false') } }],
      title: [{ properties: { show: litExpr('false') } }]
    },
    drillFilterOtherVisuals: true
  } };
}

// Filtro: one visual handling N columns (role "category"), accent color
function filtro(fields, box, accent) {
  const projections = fields.map(f => projCol(f.entity, f.column));
  const v = { $schema: VC, name: vid(), position: pos(box, 6000), visual: {
    visualType: FILTRO,
    query: { queryState: { fields: { projections } }, sortDefinition: { isDefaultSort: true } },
    drillFilterOtherVisuals: true,
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('false') } }],
      border: [{ properties: { show: litExpr('false') } }],
      title: [{ properties: { show: litExpr('false') } }],
      visualHeader: [{ properties: { show: litExpr('false') } }]
    }
  } };
  if (accent) v.visual.objects = { visualStyles: [{ properties: { accentColor: solid(accent) } }] };
  return v;
}

// ---- filters (exclude blanks + top N) ----
const fid = () => 'Filter' + crypto.randomBytes(12).toString('hex');
function notBlank(entity, prop) {
  const c = { Column: { Expression: { SourceRef: { Source: 's' } }, Property: prop } };
  const neq = val => ({ Not: { Expression: { Comparison: { ComparisonKind: 0, Left: c, Right: { Literal: { Value: val } } } } } });
  return { name: fid(), field: col(entity, prop), type: 'Advanced',
    filter: { Version: 2, From: [{ Name: 's', Entity: entity, Type: 0 }], Where: [{ Condition: { And: { Left: neq('null'), Right: neq("''") } } }] }, howCreated: 'User' };
}
function topN(entity, catProp, orderProp, n) {
  return { name: fid(), field: col(entity, catProp), type: 'TopN',
    filter: { Version: 2, From: [
      { Name: 'sub', Expression: { Subquery: { Query: { Version: 2,
        From: [{ Name: 'sq', Entity: entity, Type: 0 }],
        Select: [{ Column: { Expression: { SourceRef: { Source: 'sq' } }, Property: catProp }, Name: 'field' }],
        OrderBy: [{ Direction: 2, Expression: { Aggregation: { Expression: { Column: { Expression: { SourceRef: { Source: 'sq' } }, Property: orderProp } }, Function: 5 } } }],
        Top: n } } }, Type: 2 },
      { Name: 't', Entity: entity, Type: 0 } ],
      Where: [{ Condition: { In: { Expressions: [{ Column: { Expression: { SourceRef: { Source: 't' } }, Property: catProp } }], Table: { SourceRef: { Source: 'sub' } } } } }] }, howCreated: 'User' };
}

// Deneb: dataset (columns+measures) + Vega-Lite spec (serialized into objects.vega.jsonSpec)
function deneb(datasetFields, spec, box, filters) {
  const projections = datasetFields.map(f => f.kind === 'measure' ? projMeas(f.entity, f.prop) : projCol(f.entity, f.prop));
  const specText = JSON.stringify(spec);
  const v = { $schema: VC, name: vid(), position: pos(box), visual: {
    visualType: DENEB,
    query: { queryState: { dataset: { projections } }, sortDefinition: { isDefaultSort: true } },
    objects: {
      vega: [{ properties: {
        provider: litExpr("'vegaLite'"),
        jsonSpec: { expr: { Literal: { Value: "'" + specText.replace(/'/g, "''") + "'" } } },
        jsonConfig: litExpr("'{}'"),
        enableTooltips: litExpr('true'),
        enableContextMenu: litExpr('true'),
        enableSelection: litExpr('true'),
        selectionMode: litExpr("'simple'"),
        selectionMaxDataPoints: litExpr('200D'),
        version: litExpr("'6.4.1'")
      } }],
      stateManagement: [{ properties: { viewportHeight: litExpr((box.h - 16) + 'D'), viewportWidth: litExpr((box.w - 16) + 'D') } }]
    },
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('true'), color: solid('#FFFFFF') } }],
      border: [{ properties: { show: litExpr('true'), color: solid(CARD_BORDER), radius: litExpr('12D') } }],
      dropShadow: [{ properties: { show: litExpr('true'), preset: litExpr("'Custom'"), position: litExpr("'Outer'"), color: solid('#8C9CA8'), transparency: litExpr('82D'), shadowBlur: litExpr('16D'), shadowDistance: litExpr('4D'), angle: litExpr('90D') } }],
      title: [{ properties: { show: litExpr(spec.__title ? 'true' : 'false'), text: litExpr(`'${spec.__title || ''}'`), fontColor: solid(INK), bold: litExpr('true'), alignment: litExpr("'left'"), fontSize: litExpr('12D') } }]
    },
    drillFilterOtherVisuals: true
  } };
  if (filters) v.filterConfig = { filters };
  return v;
}

// =================== Vega-Lite spec builders (cross-filter baked in) ===================
const AX = { labelColor: '#6B7280', labelFont: 'Segoe UI', titleColor: '#6B7280', domainColor: '#E5E7EB', tickColor: '#E5E7EB' };
const GRID = { grid: true, gridColor: '#EEF2F6', gridDash: [2, 3] };
const usermeta = { deneb: { build: '', metaVersion: 1, provider: 'vegaLite', providerVersion: '5.6.0', interactivity: { tooltip: true, contextMenu: true, selection: true, selectionMode: 'single', dataPointLimit: 50 } } };
const cfg = { view: { stroke: null }, font: 'Segoe UI', axis: { labelFontSize: 11, titleFontSize: 11 } };
// hover = individual mark under cursor (no fields). Click/cross-filter is handled NATIVELY by Deneb
// (enableSelection) and exposed as datum['__selected__'] — do NOT add a Vega selection param, it conflicts.
const HOVER = [{ name: 'hover', select: { type: 'point', on: 'mouseover', clear: 'mouseout' } }];
const selDim = { condition: { test: "datum['__selected__'] == 'off'", value: 0.3 }, value: 1 };
function darken(hex, f) { const n = parseInt(hex.slice(1), 16); let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255; r = Math.round(r * (1 - f)); g = Math.round(g * (1 - f)); b = Math.round(b * (1 - f)); return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1); }
const hoverFill = (hex) => ({ condition: { param: 'hover', empty: false, value: darken(hex, 0.24) }, value: hex });
const hoverStroke = { condition: { param: 'hover', empty: false, value: '#1F2933' }, value: null };
const hoverStrokeW = { condition: { param: 'hover', empty: false, value: 2 }, value: 0 };
const base = (title) => ({ $schema: 'https://vega.github.io/schema/vega-lite/v5.json', __title: title, data: { name: 'dataset' }, width: 'container', height: 'container', autosize: { type: 'fit', contains: 'padding' }, usermeta, config: cfg });

function vBar(title, catF, valF, color) { // horizontal bars, sorted by value
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'bar', cornerRadiusEnd: 4, cursor: 'pointer' };
  s.encoding = {
    y: { field: catF, type: 'nominal', sort: '-x', axis: { title: null, ...AX, labelLimit: 160 } },
    x: { field: valF, type: 'quantitative', axis: { title: null, ...AX, ...GRID, format: '~s' } },
    color: hoverFill(color),
    opacity: selDim,
    tooltip: [{ field: catF, type: 'nominal' }, { field: valF, type: 'quantitative', format: ',' }]
  };
  return s;
}
function withTopN(spec, catF, valF, n) { // exclude blanks + keep top N, inside Vega
  spec.transform = [
    { filter: `isValid(datum['${catF}']) && datum['${catF}'] != ''` },
    { window: [{ op: 'rank', as: '__rk' }], sort: [{ field: valF, order: 'descending' }] },
    { filter: `datum.__rk <= ${n}` }
  ];
  return spec;
}
function vColumn(title, catF, valF, color, catType) { // vertical columns
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'bar', cornerRadiusEnd: 3, cursor: 'pointer' };
  s.encoding = {
    x: { field: catF, type: catType || 'ordinal', axis: { title: null, ...AX, labelAngle: 0 } },
    y: { field: valF, type: 'quantitative', axis: { title: null, ...AX, ...GRID, format: '~s' } },
    color: hoverFill(color),
    opacity: selDim,
    tooltip: [{ field: catF }, { field: valF, type: 'quantitative', format: ',' }]
  };
  return s;
}
function vLine(title, xF, valF, xType, seriesF, domain, range) { // line + hover points, optional series
  const s = base(title);
  const xEnc = { field: xF, type: xType, axis: { title: null, ...AX } };
  const yEnc = { field: valF, type: 'quantitative', axis: { title: null, ...AX, ...GRID, format: '~s' } };
  const lineMark = { type: 'line', strokeWidth: 2.5, interpolate: 'monotone' };
  const lineEnc = { x: xEnc, y: yEnc, opacity: selDim };
  const ptEnc = { x: xEnc, y: yEnc, opacity: selDim,
    size: { condition: { param: 'hover', empty: false, value: 200 }, value: 40 },
    tooltip: [{ field: xF, type: xType }, { field: valF, type: 'quantitative', format: ',' }] };
  if (seriesF) {
    const scale = domain ? { domain, range } : { domain: ['Member', 'Casual'], range: [TEAL, ORANGE] };
    const colorEnc = { field: seriesF, type: 'nominal', scale, legend: { title: null, orient: 'top', labelColor: MUTED } };
    lineEnc.color = colorEnc; ptEnc.color = colorEnc;
  } else {
    lineMark.color = TEAL;
    ptEnc.color = { condition: { param: 'hover', empty: false, value: darken(TEAL, 0.24) }, value: TEAL };
  }
  s.layer = [
    { mark: lineMark, encoding: lineEnc },
    { params: HOVER, mark: { type: 'point', filled: true, cursor: 'pointer' }, encoding: ptEnc }
  ];
  return s;
}
function vDonut(title, catF, valF, domain, range) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'arc', innerRadius: 60, cornerRadius: 2, cursor: 'pointer' };
  const scale = domain ? { domain, range } : { domain: ['Member', 'Casual'], range: [TEAL, ORANGE] };
  s.encoding = {
    theta: { field: valF, type: 'quantitative', stack: true },
    color: { field: catF, type: 'nominal', scale, legend: { title: null, orient: 'right', labelColor: MUTED } },
    opacity: selDim, stroke: hoverStroke, strokeWidth: hoverStrokeW,
    tooltip: [{ field: catF }, { field: valF, type: 'quantitative', format: ',' }]
  };
  return s;
}
function vHist(title, field, valF, color, maxbins) { // distribution: binned column
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'bar', cornerRadiusEnd: 3, cursor: 'pointer' };
  s.transform = [{ filter: `isValid(datum['${field}']) && datum['${field}'] != null` }];
  s.encoding = {
    x: { field, type: 'quantitative', bin: { maxbins: maxbins || 30 }, axis: { title: null, ...AX, labelAngle: 0 } },
    y: { field: valF, type: 'quantitative', aggregate: 'sum', axis: { title: null, ...AX, ...GRID, format: '~s' } },
    color: hoverFill(color || TEAL),
    opacity: selDim,
    tooltip: [{ field, type: 'quantitative', bin: { maxbins: maxbins || 30 } }, { field: valF, type: 'quantitative', aggregate: 'sum', format: ',' }]
  };
  return s;
}
function vHeatmap(title, xF, xOrder, yF, valF) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'rect', cornerRadius: 2, cursor: 'pointer' };
  s.encoding = {
    x: { field: xF, type: 'nominal', sort: xOrder, axis: { title: null, ...AX, labelAngle: 0 } },
    y: { field: yF, type: 'ordinal', axis: { title: 'Hora', ...AX } },
    color: { field: valF, type: 'quantitative', scale: { range: [TEAL_TINT, TEAL] }, legend: null },
    opacity: selDim, stroke: hoverStroke, strokeWidth: hoverStrokeW,
    tooltip: [{ field: yF }, { field: xF }, { field: valF, type: 'quantitative', format: ',' }]
  };
  return s;
}
// Tendencia mensual: área+línea suave, pico/mínimo marcados, eje X adaptable (año / mes).
// Trae su propio título Vega (por eso NO define __title → el título del contenedor queda apagado).
function vMonthTrend(dateF, valF, color) {
  const c = color || TEAL;
  return {
    $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
    data: { name: 'dataset' }, width: 'container', height: 'container',
    autosize: { type: 'fit', contains: 'padding' }, usermeta,
    config: { view: { stroke: null }, font: 'Segoe UI' },
    title: { text: 'Viajes por mes', subtitle: 'Tendencia mensual · pico (verde) y minimo (naranja)', font: 'Segoe UI', fontSize: 15, fontWeight: 'bold', color: INK, subtitleFont: 'Segoe UI', subtitleFontSize: 11, subtitleColor: '#8A97A3', anchor: 'start', offset: 12 },
    transform: [
      { timeUnit: 'yearmonth', field: dateF, as: 'Mes' },
      { aggregate: [{ op: 'sum', field: valF, as: 'Trips' }], groupby: ['Mes'] },
      { window: [{ op: 'rank', as: 'rk_desc' }], sort: [{ field: 'Trips', order: 'descending' }] },
      { window: [{ op: 'rank', as: 'rk_asc' }], sort: [{ field: 'Trips', order: 'ascending' }] }
    ],
    encoding: {
      x: { field: 'Mes', type: 'temporal', axis: { title: null, grid: false, ticks: false, labelColor: '#6B7280', domainColor: '#E5E7EB', labelFontSize: 11, labelOverlap: true, labelExpr: "span(domain('x')) > 47520000000 ? (month(datum.value) == 0 ? timeFormat(datum.value, '%Y') : '') : timeFormat(datum.value, '%b')" } },
      y: { field: 'Trips', type: 'quantitative', axis: { title: null, format: '~s', grid: true, gridColor: '#EEF2F6', gridDash: [2, 3], labelColor: '#6B7280', domain: false, ticks: false } }
    },
    layer: [
      { mark: { type: 'area', interpolate: 'monotone', line: false }, encoding: { color: { value: { gradient: 'linear', x1: 0, y1: 1, x2: 0, y2: 0, stops: [{ offset: 0, color: 'white' }, { offset: 1, color: c }] } }, opacity: { condition: { test: "datum['__selected__'] == 'off'", value: 0.04 }, value: 0.25 } } },
      { mark: { type: 'line', interpolate: 'monotone', color: c, strokeWidth: 2.5 }, encoding: { opacity: { condition: { test: "datum['__selected__'] == 'off'", value: 0.25 }, value: 1 } } },
      { params: HOVER, mark: { type: 'point', filled: true, color: c, cursor: 'pointer' }, encoding: { size: { condition: { param: 'hover', empty: false, value: 170 }, value: 22 }, opacity: { value: 0.55 }, tooltip: [{ field: 'Mes', type: 'temporal', title: 'Mes', format: '%b %Y' }, { field: 'Trips', type: 'quantitative', title: 'Viajes', format: ',' }] } },
      { transform: [{ filter: 'datum.rk_desc == 1' }], mark: { type: 'point', filled: true, size: 150, color: '#2F9E44', stroke: 'white', strokeWidth: 1.5 } },
      { transform: [{ filter: 'datum.rk_desc == 1' }], mark: { type: 'text', dy: -14, fontSize: 11, fontWeight: 'bold', color: '#2F9E44' }, encoding: { text: { field: 'Trips', format: '~s' } } },
      { transform: [{ filter: 'datum.rk_asc == 1' }], mark: { type: 'point', filled: true, size: 150, color: ORANGE, stroke: 'white', strokeWidth: 1.5 } },
      { transform: [{ filter: 'datum.rk_asc == 1' }], mark: { type: 'text', dy: 16, fontSize: 11, fontWeight: 'bold', color: ORANGE }, encoding: { text: { field: 'Trips', format: '~s' } } }
    ]
  };
}

// =================== native helpers reused (map, table, pageNav, sidebar) ===================
function rect(box, hex, z, radius) {
  return { $schema: VC, name: vid(), position: pos(box, z), visual: {
    visualType: 'shape',
    objects: {
      shape: [{ properties: { tileShape: litExpr(radius ? "'rectangleRounded'" : "'rectangle'"), ...(radius ? { rectangleRoundedCurve: litExpr(radius + 'D') } : {}) } }],
      fill: [{ properties: { fillColor: solid(hex), transparency: litExpr('0D') }, selector: { id: 'default' } }],
      outline: [{ properties: { show: litExpr('false') }, selector: { id: 'default' } }]
    },
    visualContainerObjects: { background: [{ properties: { show: litExpr('false') } }], border: [{ properties: { show: litExpr('false') } }], padding: [{ properties: { top: litExpr('0D'), bottom: litExpr('0D'), left: litExpr('0D'), right: litExpr('0D') } }] }
  } };
}
function textbox(text, box, sizePx, color, semibold, z) {
  return { $schema: VC, name: vid(), position: pos(box, z), visual: {
    visualType: 'textbox',
    objects: { general: [{ properties: { paragraphs: [{ textRuns: [{ value: text, textStyle: { fontFamily: semibold ? 'Segoe UI Semibold' : 'Segoe UI', fontSize: sizePx, color } }], horizontalTextAlignment: 'left' }] } }] },
    visualContainerObjects: { background: [{ properties: { show: litExpr('false') } }], border: [{ properties: { show: litExpr('false') } }], padding: [{ properties: { top: litExpr('0D'), bottom: litExpr('0D'), left: litExpr('0D'), right: litExpr('0D') } }] }
  } };
}
function pageNav(box) {
  return { $schema: VC, name: vid(), position: pos(box, 9500), visual: {
    visualType: 'pageNavigator',
    objects: {
      layout: [{ properties: { orientation: litExpr('1D'), cellPadding: litExpr('6D') } }],
      shape: [{ properties: { tileShape: litExpr("'rectangleRounded'"), rectangleRoundedCurve: litExpr('8D') } }],
      fill: [
        { properties: { show: litExpr('true'), fillColor: solid(SIDEBAR) }, selector: { id: 'default' } },
        { properties: { show: litExpr('true'), fillColor: solid(TEAL) }, selector: { id: 'selected' } },
        { properties: { show: litExpr('true'), fillColor: solid(SIDEBAR_HL) }, selector: { id: 'hover' } }
      ],
      text: [
        { properties: { show: litExpr('true'), fontColor: solid('#AFC4D0'), fontSize: litExpr('12D') }, selector: { id: 'default' } },
        { properties: { show: litExpr('true'), fontColor: solid('#FFFFFF'), bold: litExpr('true'), fontSize: litExpr('12D') }, selector: { id: 'selected' } }
      ],
      outline: [{ properties: { show: litExpr('false') }, selector: { id: 'default' } }]
    },
    visualContainerObjects: { background: [{ properties: { show: litExpr('false') } }], border: [{ properties: { show: litExpr('false') } }], padding: [{ properties: { top: litExpr('0D'), bottom: litExpr('0D'), left: litExpr('0D'), right: litExpr('0D') } }] }
  } };
}
function azureMap(box, title) {
  const agg = (e, p, fn) => ({ Aggregation: { Expression: { Column: { Expression: { SourceRef: { Entity: e } }, Property: p } }, Function: fn } });
  const pr = (f, e, p) => ({ field: f, queryRef: `${e}.${p}`, nativeQueryRef: p, active: true });
  return { $schema: VC, name: vid(), position: pos(box), visual: {
    visualType: 'azureMap',
    query: { queryState: {
      Category: { projections: [pr(col('dim_Station', 'StationName'), 'dim_Station', 'StationName')] },
      Y: { projections: [pr(agg('dim_Station', 'Lat', 1), 'dim_Station', 'Lat')] },
      X: { projections: [pr(agg('dim_Station', 'Lng', 1), 'dim_Station', 'Lng')] },
      Size: { projections: [pr(meas('fact_Trips', 'Total Trips'), 'fact_Trips', 'Total Trips')] }
    } }, objects: {},
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('true'), color: solid('#FFFFFF') } }],
      border: [{ properties: { show: litExpr('true'), color: solid(CARD_BORDER), radius: litExpr('12D') } }],
      title: [{ properties: { show: litExpr('true'), text: litExpr(`'${title}'`), fontColor: solid(INK), bold: litExpr('true'), alignment: litExpr("'left'"), fontSize: litExpr('12D') } }]
    }
  } };
}

// ---- sidebar (same on every page) ----
function sidebar() {
  return [
    rect({ x: 0, y: 0, w: SIDE_W, h: CH }, SIDEBAR, 10),
    rect({ x: 28, y: 44, w: 40, h: 6 }, TEAL, 9600, 3),
    textbox('Divvy', { x: 28, y: 56, w: 200, h: 56 }, '30px', '#FFFFFF', true, 9600),
    textbox('Bike-share · Chicago', { x: 28, y: 104, w: 200, h: 22 }, '12px', '#8CA6B4', false, 9600),
    rect({ x: 24, y: 150, w: 200, h: 1 }, '#22485C', 9600),
    pageNav({ x: 16, y: 172, w: 216, h: 176 }),
    textbox('Mayo 2026 · Deneb + HTML + Filtro', { x: 28, y: 1008, w: 208, h: 34 }, '11px', '#6E8593', false, 9600)
  ];
}
function pageTitle(t) { return textbox(t, { x: BODY.x, y: 36, w: 700, h: 44 }, '24px', INK, true, 9000); }

function writePage(name, displayName, header, body) {
  const dir = path.join(PAGES_DIR, name);
  fs.mkdirSync(path.join(dir, 'visuals'), { recursive: true });
  const page = { $schema: PAGE_SCHEMA, name, displayName, displayOption: 'FitToPage', height: CH, width: CW,
    objects: { background: [{ properties: { color: solid(PAGE_BG), transparency: litExpr('0D') } }] } };
  fs.writeFileSync(path.join(dir, 'page.json'), JSON.stringify(page, null, 2));
  [...sidebar(), ...header, ...body].forEach(v => write(name, v));
}

// dataset field helpers
const dC = (e, p) => ({ entity: e, prop: p, kind: 'column' });
const dM = (e, p) => ({ entity: e, prop: p, kind: 'measure' });
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

// =================== PAGES ===================
const GREEN = '#2B8A3E';
const filterBar = (cols) => filtro(cols.map(c => ({ entity: c[0], column: c[1] })), { x: BODY.x, y: 92, w: BODY.w, h: 52 }, TEAL);
// apply a Vega transform filter (e.g. keep valid gender) on top of a spec
function withFilter(spec, expr) { spec.transform = [...(spec.transform || []), { filter: expr }]; return spec; }
function recolor(spec, hex) {
  if (spec.mark) { spec.mark.color = hex; }
  else if (spec.layer) spec.layer.forEach(l => {
    if (l.mark && l.mark.type === 'line') l.mark.color = hex;
    if (l.mark && l.mark.type === 'point') l.encoding.color = { condition: { param: 'hover', empty: false, value: darken(hex, 0.24) }, value: hex };
  });
  return spec;
}

const P1 = '452c5b1ac87b09394ea2';
function page1() {
  const head = [pageTitle('Resumen general'),
    filterBar([['fact_Trips', 'Era'], ['fact_Trips', 'MemberType'], ['fact_Trips', 'RideableType'], ['dim_Date', 'Day Name']])];
  const body = [
    htmlCard('fact_Trips', 'KPI Strip HTML', cg(1, 1, 13, 3)),
    deneb([dC('dim_Date', 'Date'), dM('fact_Trips', 'Total Trips')], vMonthTrend('Date', 'Total Trips', TEAL), cg(1, 3, 13, 7)),
    deneb([dC('fact_Trips', 'MemberType'), dM('fact_Trips', 'Total Trips')], vDonut('Miembros vs Casuales', 'MemberType', 'Total Trips'), cg(1, 7, 7, 11)),
    deneb([dC('fact_Trips', 'RideableType'), dM('fact_Trips', 'Total Trips')], withFilter(vBar('Viajes por tipo de bici', 'RideableType', 'Total Trips', TEAL), "datum['RideableType'] != 'Unknown'"), cg(7, 7, 13, 11))
  ];
  writePage(P1, 'Resumen general', head, body);
}

const P2 = '6a7743d47c42d4acd71d';
function page2() {
  const head = [pageTitle('Patrones de uso'),
    filterBar([['fact_Trips', 'Era'], ['fact_Trips', 'MemberType'], ['fact_Trips', 'RideableType']])];
  const body = [
    deneb([dC('fact_Trips', 'StartHour'), dM('fact_Trips', 'Total Trips')], vColumn('Viajes por hora del dia', 'StartHour', 'Total Trips', TEAL, 'ordinal'), cg(1, 1, 7, 5)),
    deneb([dC('dim_Date', 'Day Name'), dM('fact_Trips', 'Total Trips')], (() => { const s = vColumn('Viajes por dia de la semana', 'Day Name', 'Total Trips', TEAL, 'nominal'); s.encoding.x.sort = DAYS; return s; })(), cg(7, 1, 13, 5)),
    deneb([dC('fact_Trips', 'StartHour'), dC('dim_Date', 'Day Name'), dM('fact_Trips', 'Total Trips')], vHeatmap('Mapa de calor — hora x dia', 'Day Name', DAYS, 'StartHour', 'Total Trips'), cg(1, 5, 9, 8)),
    deneb([dC('dim_Date', 'Is Weekend'), dM('fact_Trips', 'Total Trips')], vBar('Entre semana vs fin de semana', 'Is Weekend', 'Total Trips', BLUE), cg(9, 5, 13, 8)),
    deneb([dC('fact_Trips', 'StartHour'), dC('fact_Trips', 'MemberType'), dM('fact_Trips', 'Total Trips')], vLine('Miembros vs Casuales por hora', 'StartHour', 'Total Trips', 'ordinal', 'MemberType'), cg(1, 8, 13, 11))
  ];
  writePage(P2, 'Patrones de uso', head, body);
}

const P3 = '7d024e5f4fc63d48e594';
function page3() {
  const head = [pageTitle('Estaciones y operación'),
    filterBar([['fact_Trips', 'Era'], ['fact_Trips', 'MemberType'], ['fact_Trips', 'RideableType']])];
  const topStart = deneb([dC('dim_Station', 'StationName'), dM('fact_Trips', 'Total Trips')], withTopN(vBar('Top estaciones de salida', 'StationName', 'Total Trips', TEAL), 'StationName', 'Total Trips', 10), cg(8, 1, 13, 6));
  const topEnd = deneb([dC('dim_Station', 'StationName'), dM('fact_Trips', 'Trips to Station')], withTopN(vBar('Top estaciones de llegada', 'StationName', 'Trips to Station', ARR), 'StationName', 'Trips to Station', 10), cg(8, 6, 13, 11));
  const netFlow = deneb([dC('dim_Station', 'StationName'), dM('fact_Trips', 'Net Flow')], withTopN(vBar('Desbalance neto (salidas − llegadas)', 'StationName', 'Net Flow', ORANGE), 'StationName', 'Net Flow', 10), cg(1, 7, 8, 11));
  const body = [
    azureMap(cg(1, 1, 8, 7), 'Estaciones por volumen'),
    netFlow, topStart, topEnd
  ];
  writePage(P3, 'Estaciones y operación', head, body);
}

const P4 = '0a1b2c3d4e5f60718293';
function page4() {
  const head = [pageTitle('Demografía  ·  era Legacy 2013–2020'),
    filterBar([['fact_Trips', 'Gender'], ['fact_Trips', 'MemberType'], ['dim_Date', 'Year']])];
  const GEN = ['Male', 'Female'], GENC = [BLUE, ORANGE];
  const validGen = "isValid(datum.Gender) && (datum.Gender=='Male' || datum.Gender=='Female')";
  const body = [
    htmlCard('fact_Trips', 'KPI Demografia HTML', cg(1, 1, 13, 3)),
    deneb([dC('fact_Trips', 'Gender'), dM('fact_Trips', 'Total Trips')], withFilter(vDonut('Género de los usuarios', 'Gender', 'Total Trips', GEN, GENC), validGen), cg(1, 3, 7, 7)),
    deneb([dC('fact_Trips', 'AgeYears'), dM('fact_Trips', 'Total Trips')], vHist('Distribución de edad', 'AgeYears', 'Total Trips', TEAL, 25), cg(7, 3, 13, 7)),
    deneb([dC('dim_Date', 'Year'), dM('fact_Trips', 'Avg Age')], vColumn('Edad media por año', 'Year', 'Avg Age', BLUE, 'ordinal'), cg(1, 7, 7, 11)),
    deneb([dC('dim_Date', 'Year'), dC('fact_Trips', 'Gender'), dM('fact_Trips', 'Total Trips')], withFilter(vLine('Viajes por género en el tiempo', 'Year', 'Total Trips', 'ordinal', 'Gender', GEN, GENC), validGen), cg(7, 7, 13, 11))
  ];
  writePage(P4, 'Demografía', head, body);
}

const P5 = '90a1b2c3d4e5f6071829';
function page5() {
  const head = [pageTitle('Insights sorprendentes  ·  valores estimados'),
    filterBar([['fact_Trips', 'Era'], ['fact_Trips', 'MemberType'], ['fact_Trips', 'RideableType']])];
  const body = [
    htmlCard('fact_Trips', 'KPI Impacto HTML', cg(1, 1, 13, 3)),
    deneb([dC('fact_Trips', 'StartHour'), dM('fact_Trips', 'Avg Speed (km/h)')], vColumn('Velocidad media por hora (km/h)', 'StartHour', 'Avg Speed (km/h)', BLUE, 'ordinal'), cg(1, 3, 7, 7)),
    deneb([dC('dim_Date', 'Date'), dM('fact_Trips', 'CO2 evitado (kg)')], recolor(vLine('CO₂ evitado en el tiempo (kg)', 'Date', 'CO2 evitado (kg)', 'temporal'), GREEN), cg(7, 3, 13, 7)),
    deneb([dC('fact_Trips', 'RideableType'), dM('fact_Trips', 'Avg Distance (km)')], vBar('Distancia media por tipo de bici (km)', 'RideableType', 'Avg Distance (km)', TEAL), cg(1, 7, 7, 11)),
    deneb([dC('dim_Date', 'Date'), dM('fact_Trips', 'Total Trips')], vLine('Viajes por día — las caídas ≈ clima/eventos', 'Date', 'Total Trips', 'temporal'), cg(7, 7, 13, 11))
  ];
  writePage(P5, 'Insights sorprendentes', head, body);
}

// ---- run ----
const ALL = [P1, P2, P3, P4, P5];
// remove any orphan page folders not in ALL, and clear visuals of pages we regenerate
for (const d of fs.readdirSync(PAGES_DIR)) {
  const full = path.join(PAGES_DIR, d);
  if (!fs.statSync(full).isDirectory()) continue;
  if (!ALL.includes(d)) { fs.rmSync(full, { recursive: true, force: true }); }
  else { const v = path.join(full, 'visuals'); if (fs.existsSync(v)) fs.rmSync(v, { recursive: true, force: true }); }
}
page1(); page2(); page3(); page4(); page5();
fs.writeFileSync(path.join(PAGES_DIR, 'pages.json'), JSON.stringify({
  $schema: 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.1.0/schema.json',
  pageOrder: ALL, activePageName: P1 }, null, 2));
console.log('Generated hybrid:', ALL.join(', '));
