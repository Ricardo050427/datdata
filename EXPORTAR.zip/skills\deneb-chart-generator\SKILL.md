---
name: deneb-chart-generator
description: >
  Genera especificaciones JSON completas de Vega-Lite para el visual Deneb en Power BI.
  Activar cuando el usuario pida gráficas personalizadas, mencione "Deneb", "Vega-Lite",
  muestre una imagen de referencia de un gráfico que quiere replicar, o pida visuales
  que los charts nativos de Power BI no pueden hacer: anotaciones condicionales,
  puntos destacados (peak/low), degradados en área, small multiples, beeswarm plots,
  bullet charts, rankings animados, o cualquier gráfica con diseño avanzado.
  También activar con frases como "gráfica como esta", "visual bonito", "chart con hover".
---

# Deneb Chart Generator

Genera specs JSON completos de Vega-Lite para Deneb en Power BI.

## Regla de diseño: negocio primero

Todo spec generado debe seguir esta jerarquía:

1. **Si el analista da referencia visual** → replicar fielmente el estilo
2. **Si el analista no especifica** → aplicar principios de dashboard de negocio:
   - Dato principal al frente, contexto en segundo plano
   - Color con propósito (no decorativo)
   - Tooltips informativos en todo elemento interactivo
   - Tipografía Segoe UI para consistencia con Power BI

---

## Principios de diseño para dashboards de negocio

- **Jerarquía visual**: el número o barra más importante debe tener mayor peso visual
- **Color semántico**: verde = bien, rojo = alerta, gris = neutro/inactivo
- **Anotaciones selectivas**: etiquetar solo los puntos que el usuario necesita leer (no todos)
- **Espacio en blanco**: los gráficos necesitan respirar — no saturar con grids y bordes

---

## Estructura base de todo spec

```json
{
  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
  "usermeta": { "deneb": { "build": "", "metaVersion": 1, "provider": "vegaLite", "providerVersion": "5.6.0" } },
  "config": { "view": { "stroke": "transparent" }, "font": "Segoe UI" },
  "description": "Descripción de la gráfica",
  "data": { "name": "dataset" },
  "layer": [ /* capas aquí */ ]
}
```

**CRÍTICO**: `"data": { "name": "dataset" }` — siempre este nombre, nunca valores inline.

---

## Interactividad (hover + click) — OBLIGATORIA

Una gráfica de dashboard debe **reaccionar al mouse**. Sin esto se ve estática y muerta.
Patrón estándar: dos `params` (uno hover, uno selección) + opacidad condicional.

```jsonc
"usermeta": { "deneb": { "interactivity": { "tooltip": true, "selection": true, "dataPointLimit": 50 } } },
"params": [
  { "name": "hov_x", "select": { "type": "point", "on": "mouseover", "fields": ["Categoría"] } },
  { "name": "sel_x", "select": { "type": "point", "fields": ["Categoría"] } }
],
"encoding": {
  "opacity": {
    "condition": [
      { "param": "sel_x", "value": 1 },
      { "param": "hov_x", "empty": false, "value": 0.85 }
    ],
    "value": 0.25
  }
}
```

Resultado: al pasar el mouse el elemento se resalta (0.85) y los demás se atenúan (0.25);
al hacer click queda seleccionado (1) y filtra los otros visuales. Usar `fields` con la
dimensión del eje. Un par `hov_/sel_` distinto por gráfica.

Helpers reutilizables `PARAMS()` y `OPACITY_COND()` en `gen_pagina1_pro.py` del motor.

---

## Cómo se integra el spec (no es texto suelto)

El spec NO se entrega solo en el chat. Se embebe en el spec del dashboard como un visual
`deneb`, y el motor lo escribe en el `visual.json`:

```jsonc
{ "type": "deneb",
  "at": { "col": 2, "row": 0, "colspan": 5, "rowspan": 4 },
  "dataset": [
    { "entity": "f_Tickets",   "property": "Categoría",    "kind": "column"  },
    { "entity": "DAX Medidas", "property": "Total Tickets", "kind": "measure" }
  ],
  "vega": { /* spec Vega-Lite completo */ } }
```

- `dataset` = campos que alimentan el visual. En la spec Vega se referencian por su
  `property` (= `nativeQueryRef`), p.ej. `"field": "Categoría"`.
- El motor serializa y empaqueta la spec automáticamente. Ver `SISTEMA.md §5 y §8`.

**Coherencia:** misma paleta, Segoe UI y radios que las tarjetas HTML del dashboard.

---

## Plantillas por tipo

### Line/Area Trend (con Peak y Low)

Capas en orden:
1. `mark: "area"` — fill con opacidad 0.15-0.25, mismo color que línea
2. `mark: "line"` — strokeWidth: 2.5, color acento
3. `mark: "point"` — todos los puntos, tamaño 40, filled true
4. `mark: "point"` (filter MAX) — PEAK: color verde `#27AE60`, filled true, size 120
5. `mark: "point"` (filter MIN) — LOW: color `#E74C3C`, filled false, size 120, strokeWidth 2
6. `mark: "text"` — valores encima, dy: -12, solo años relevantes o todos si caben
7. `mark: "text"` — YoY% debajo, dy: +18, color condicional, solo si |yoy| > umbral
8. `mark: "text"` (filter MAX) — badge "PEAK", dy: -28, bold
9. `mark: "text"` (filter MIN) — badge "LOW", dy: +30, bold

Transform para YoY:
```json
{ "window": [{"op": "lag", "field": "valor", "param": 1, "as": "valor_anterior"}] },
{ "calculate": "datum.valor_anterior ? (datum.valor - datum.valor_anterior) / datum.valor_anterior : null", "as": "yoy" }
```

### Bar Chart Horizontal (Ranking)

Capas:
1. `mark: "bar"` — barras horizontales, color por ranking (escala `purples` o custom)
2. `mark: "text"` — valor al final de barra, dx: 5
3. `mark: "text"` — número de ranking al inicio, dx: -15

Encoding:
```json
{
  "y": { "field": "categoria", "type": "nominal", "sort": "-x", "axis": { "labelLimit": 150 } },
  "x": { "field": "valor", "type": "quantitative", "axis": null },
  "color": { "field": "ranking", "type": "ordinal", "scale": { "scheme": "purples" }, "legend": null }
}
```

### Bullet Chart (Presupuesto vs. Real)

Capas:
1. `mark: "bar"` — barra de fondo = presupuesto, color gris claro `#E0E0E0`, ancho completo
2. `mark: "bar"` — barra de real, color condicional (verde si >= presupuesto, rojo si <)
3. `mark: "rule"` — línea vertical en el presupuesto, strokeWidth 3, color oscuro
4. `mark: "text"` — etiqueta % ejecución

Color condicional para barra de real:
```json
"color": {
  "condition": { "test": "datum.real >= datum.presupuesto", "value": "#27AE60" },
  "value": "#E74C3C"
}
```

### Scatter Plot con Burbuja

Capas:
1. `mark: "circle"` — con `size` encoding para tercera variable, opacity 0.7
2. `mark: "text"` — etiqueta de categoría, solo si `datum.size > umbral`
3. `mark: "rule"` — línea vertical en media de X (color gris, strokeDash)
4. `mark: "rule"` — línea horizontal en media de Y (color gris, strokeDash)

---

## Paleta de colores

**Default negocio (fondo claro):**
```json
"range": ["#6A0DAD", "#9B59B6", "#C39BD3", "#D4B8F0", "#EAD5F5"]
```

**Default negocio (fondo oscuro):**
```json
"range": ["#A855F7", "#C084FC", "#DDA0FF", "#7C3AED", "#5B21B6"]
```

**Semántico (siempre igual):**
- Positivo / cumple meta: `#27AE60`
- Neutro: `#9B59B6`
- Alerta / no cumple: `#E74C3C`
- Fondo de referencia: `#E0E0E0`

---

## Cómo leer una imagen de referencia

Cuando el analista manda una captura:

1. Identificar las **capas** presentes (área, línea, puntos, texto, badges, líneas de referencia)
2. Identificar **encodings** (campo en X, Y, color, size, text)
3. Identificar **transforms** (aggregate, calculate, filter, window para YoY)
4. Identificar **anotaciones especiales** (peak/low, umbrales, líneas de meta)
5. Preguntar si no hay campos claros: "¿qué campo va en el eje X?"
6. Construir spec capa por capa, de la más baja a la más alta

---

## Checklist antes de entregar

- [ ] `"data": { "name": "dataset" }` presente
- [ ] **Interactividad hover+click** (params `hov_`/`sel_` + opacidad condicional)
- [ ] **`usermeta.deneb.interactivity.selection: true`** para habilitar la selección
- [ ] Todos los campos existen en el modelo de Power BI (verificar con MCP si conectado)
- [ ] Campos referenciados por su `property`/`nativeQueryRef` (no por queryRef completo)
- [ ] Tooltips en cada mark principal
- [ ] Colores accesibles (no depender solo de rojo/verde)
- [ ] `"font": "Segoe UI"` en config
- [ ] JSON válido — sin comillas faltantes ni comas finales
- [ ] Spec completo — no fragmentos que el analista tenga que completar
- [ ] Si el analista dio referencia visual → el spec respeta ese estilo
