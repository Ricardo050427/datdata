# Gotchas — errores ya pagados con horas. No repetirlos.

Cada entrada aquí costó tiempo real en un proyecto. Leer **antes del primer `reload`**.

---

## A · Los cuatro que cuestan una sesión entera

### A1 · `reload` con `hasUnsavedChanges: true` destruye los custom visuals importados

**Costó 1h30 en un proyecto real.** El usuario abre el `.pbip`, importa Deneb / HTML Content /
Filtro, y **no guarda**. El primer `reload` (que por defecto trae `reloadModelDefinition: true`)
descarta ese estado sin avisar y se lleva el registro de los tres visuales. Recuperarlo exige
copiar a mano `CustomVisuals/<GUID>/` y editar `report.json` (`publicCustomVisuals`,
`resourcePackages`) desde otro proyecto que sí los tenga en disco.

**Regla:** el primer comando de la sesión es `powerbi-desktop status`. Si `hasUnsavedChanges` es
`true`, **no recargues**. Pide un Ctrl+S y mientras tanto trabaja el modelo por MCP.

**Orden correcto siempre:** (a) el usuario importa los visuales y guarda → (b) el generador
escribe las páginas → (c) close + reopen.

### A2 · `reload` no recoge páginas nuevas o borradas

Si el generador agregó o quitó páginas, `reload` devuelve `success: true` pero
`screenshot`/`screenshot-all` responden **`"Unknown pageId"`**. No es timing: se confirmó con dos
reloads y esperas de 45 s. `reload` no reconstruye la navegación interna de páginas.

**Fix:** cerrar y reabrir Power BI.

```powershell
Stop-Process -Id <pid> -Force              # CloseMainWindow() se cuelga 20 s y no cierra
Start-Process -FilePath "<ruta completa>.pbip"
powerbi-desktop status --wait-seconds 90   # esperar a que levante el bridge
```

`reload` **sí** es fiable para cambios de contenido dentro de páginas que ya existían.

### A3 · El Ctrl+S del usuario puede PISAR las páginas generadas

Es el reverso de A2. Si el generador escribió páginas nuevas en disco pero Power BI todavía no las
cargó, Desktop sigue teniendo en memoria el estado viejo; al guardar escribe **ese** estado y
borra lo generado. En un proyecto un Ctrl+S dejó `pages.json` con la única página original.

**Fix:** tras cualquier Ctrl+S del usuario, verifica `pages.json` en disco antes de seguir. Si se
generó antes del guardado, vuelve a correr el generador.

### A4 · Estás mirando el archivo equivocado

Si en la carpeta hay un `.pbix` viejo junto al `.pbip` real, o varias copias con nombre parecido,
Power BI puede abrir "Recientes" en un orden inesperado. El reporte se ve y se comporta normal,
solo que con contenido de hace una semana. **Casi una hora** de debugging de un bug inexistente.

**Regla:** tras cualquier apertura, verifica el **título de la ventana** antes de dar por buena o
mala una prueba visual. Debe coincidir exactamente con el proyecto esperado ("Divvy copia", no
solo "Divvy"). Ante duda, abre por ruta completa con `Start-Process -FilePath`, nunca por
doble-clic en Recientes ni por `open_application` genérico.

---

## B · Modelo y datos

| Síntoma | Causa | Fix |
|---|---|---|
| Al recargar desaparecen columnas/medidas creadas por MCP | `reload` revirtió el modelo desde `.SemanticModel/.pbi/cache.abf` | Apóyate en columnas **estables** de dimensión + medidas, no en columnas nuevas del hecho. Si hace falta: exportar a TMDL (`database_operations ExportToTmdlFolder`) y borrar `cache.abf` + `unappliedChanges.json` antes de recargar |
| Banners "objetos calculados deben actualizarse" / "tablas con datos incompletos" | Se borró `cache.abf`, lo que también tira la caché de **datos importados** | `model_operations RefreshWithXMLA` con `refreshType: "Full"` por MCP tras cada reopen. Confirmar con un `COUNTROWS` antes de dar por buena una captura |
| Todo el dashboard muestra el mismo número repetido | Relación a la dimensión **inactiva** | Activarla por MCP (`relationship_operations`) y revalidar con DAX |
| Los meses salen alfabéticos (abril, agosto, diciembre…) | Falta `sortByColumn` en la columna de nombre de mes | Ponerlo al crear el calendario, no después |
| Crear una medida con `dataType` explícito falla | Limitación del MCP | Omitir `dataType` |
| `VAR cardS` choca con `VAR cards` | Los nombres de VAR en DAX son **case-insensitive** | Usar nombres realmente distintos |
| Power BI se cuelga al refrescar | Se intentó cargar un dataset grande por el MCP | Que el usuario le dé a **Actualizar** en Desktop a mano; el MCP para modelo y medidas, no para volumen |

**Eficiencia desde el diseño** (no como limpieza al final): la fact solo con claves int y hechos
numéricos. Nada de IDs de texto únicos (un `RideId` de 54 M valores distintos ocupó ~1 GB de
diccionario él solo), timestamps crudos, ni floats innecesarios. Lat/long y etiquetas van a la
dimensión. Apaga "Auto date/time".

---

## C · El visual Filtro

| Síntoma | Causa | Fix |
|---|---|---|
| **Pills como rectángulos blancos vacíos, sin texto** | El visual trae `fontSize: 17` hardcodeado → cada pill mide ~57 px y se **recorta** en una barra de 44-56 px | `fontSize: 12` + barra de **≥68 px**. Ya viene así en la fábrica `filtro()` |
| "Importa el visual" / filtro vacío | El `.pbiviz` no está importado **en ese reporte** (es por reporte, no global) | Inicio → Más objetos visuales → Importar desde archivo |
| Color que no combina | No se pasó el acento | La fábrica ya lo pasa desde `PAL.accent`; no lo sobrescribas a mano |
| El desplegable se dibuja **detrás** de las gráficas | Hay un `stopPropagation`/`preventDefault` en el handler de clic del TypeScript | Quitarlos. Ver PERSONALIZACION.md §5 |

El síntoma del recorte **engaña**: parece que el visual no recibe datos (GUID malo, rol
incorrecto, no importado) y se pierde mucho tiempo ahí. El panel Compilar muestra los campos bien
enlazados; el texto simplemente queda fuera del área visible. Diagnóstico en un solo ciclo: pon
`h: 120`, regenera y recarga — si aparece el texto, era recorte.

Los tabs de navegación que dibuja el visual son **decorativos**. La navegación real la hace el
`pageNavigator` nativo.

---

## D · Deneb

| Síntoma | Causa | Fix |
|---|---|---|
| "Error en uno o más filtros" | Se le puso un filtro de visual PBIR (TopN / Advanced) | Deneb **no acepta** filtros PBIR. Filtrar dentro de la spec con `withTopN()` / `withFilter()` |
| Gráfica en blanco | Visual no importado, GUID equivocado, o render async | Importar; comparar GUID; esperar ~3 s y recapturar |
| Clic en una barra no cambia las tarjetas | Falta `interactivity.selection: true` | Ya viene en `usermeta`; no lo quites |
| El cross-filter se comporta raro | Se añadió un param de selección Vega **además** del nativo | Usar solo `datum['__selected__'] == 'off'` para la opacidad. **Nunca** un param `sel` |
| Sin reacción al pasar el mouse | Solo hay param de clic | Añadir el param `hover` (`on: 'mouseover'`) + `color` condicional |
| Tooltip que solo aparece justo sobre el trazo | Comportamiento por defecto en líneas y áreas | `select` con `nearest: true` **y** `encodings: ['x']`. ⚠️ `nearest` sin `encodings` usa distancia 2D y engancha el punto en diagonal |
| Tooltip multi-serie que muestra una sola serie | Falta pivotar | `transform` `pivot` por la serie + `groupby` la categoría |
| Barras bajas invisibles sobre fondo blanco | Degradado con tinte claro | Color sólido |
| Columna oculta usada como eje → visual en error | La columna tiene `isHidden` | Dejar visibles las columnas de eje/categoría |

**Ranking por dimensión:** usar columnas estables de la dimensión (`dim_Estacion[Nombre]`) +
medidas, no columnas volátiles del hecho — evita el revert por `cache.abf`.

**Tooltip premium (Vega puro):** si lo construyes, `"interactive": false` en el grupo **y en cada
marca hija**. Si no, la tarjeta captura el mouse y bloquea el hover y el clic de lo que tape.
Costó una iteración completa detectarlo.

---

## E · Tarjetas HTML

| Síntoma | Causa | Fix |
|---|---|---|
| Hueco blanco al fondo que crece al redimensionar | El contenedor usa `height: 100%` | `vh`/`vw`, no `%`. En este visual **sí** heredan el tamaño |
| Tarjeta que no escala al redimensionar | Píxeles fijos | `clamp()` en font-size, padding y gap, con la unidad en `vh` |
| Layout inconsistente | Se puso el flex/grid sobre `body` | Poner el grid en un **div con clase**, dentro de `<style>` |
| "SATISFACCION" sale mal | Escape unicode en un string DAX dentro del `.tmdl` | ASCII plano o entidades HTML (`&#211;`) |

Patrón que funciona (validado por el usuario, corrige mitos anteriores):

```css
.grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;
      width:100vw;height:100vh;box-sizing:border-box;padding:12px}
.card{width:100%;height:100%;transition:all .2s ease-in-out}
.value{font-size:clamp(24px,27.5vh,110px)}
.label{font-size:clamp(12px,5.5vh,22px)}
@media (max-aspect-ratio:1.6/1){.grid{grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
      grid-template-rows:none;grid-auto-rows:1fr}}
```

**Mitos corregidos:** `cqh` + `container-type:size` resultó poco fiable aquí; `height:100vh` **sí**
funciona (no falla en el iframe, como se creyó antes); `position:fixed` y `window.innerHeight`
siguen sin ser fiables.

---

## F · Herramientas y entorno

| Síntoma | Causa | Fix |
|---|---|---|
| `validate` dice "Unknown visualType" | Deneb / HTML / Filtro no son nativos | **Es normal.** Solo importan los errores |
| `node` o las CLIs "no se reconocen" | PATH no recargado tras `npm i -g` | Reabrir la terminal |
| `filterConfig` ignorado | Se puso dentro de `visual` | Va como **hermano** de `visual`, en la raíz del visualContainer |
| Filtro TopN de PBIR no funciona | `OrderBy` con `Measure` | Debe usar `Aggregation`; alias del subquery distinto al de la tabla externa; `In.Expressions` usa `SourceRef.Source` |
| Excluir vacíos deja pasar basura | Solo se filtró `!= null` | Hay que excluir null **y** cadena vacía: `And(Not(col=null), Not(col=''))` |
| Slicer nativo recortado | Altura < 76 px | Mínimo 76 px (`PBIR_SLICER_HEIGHT_BELOW_FLOOR`) |
| El panel de Filtros de PBI tapa el reporte | Es cromo del visor | No se puede ocultar por página; se colapsa a mano y el reload lo re-expande |
| `computer-use` da timeout de 300 s | Entorno | Intentar **una** vez; si falla, pasar a PowerShell (`Get-Process`/`Stop-Process`/`Start-Process`). No reintentar |
| `open_application "Power BI Desktop"` abre una ventana nueva en blanco | No enfoca la instancia existente | Enfocar por PID con `SetForegroundWindow` y confirmar el título |
