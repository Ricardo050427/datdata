---
name: powerbi-dashboard
description: >
  Construye dashboards empresariales completos en Power BI de principio a fin (Metodología 2
  híbrida: modelo y medidas DAX por MCP, gráficas Deneb, tarjetas KPI en HTML, barra de filtros,
  layout multipágina y navegación). Actívala SIEMPRE que el usuario pida crear, armar, construir
  o mejorar un dashboard o reporte de Power BI — incluso con frases mínimas como "crea un
  dashboard del reporte que tengo abierto", "hazme un dashboard", "arma el reporte", "vamos a
  construir el dashboard", "aplica la metodología 2". También al pedir agregar o rehacer páginas,
  cambiar colores o layout, o construir un filtro personalizado para un dashboard existente.
  Esta skill REEMPLAZA a cualquier otra de dashboards de Power BI (incluida
  powerbi-dashboard-builder, que es una versión antigua sin el generador hybrid.js).
---

# Dashboard de Power BI — Metodología 2 (híbrida)

Archivos de esta skill (rutas absolutas, funcionan desde cualquier proyecto):

| Archivo | Cuándo leerlo |
|---|---|
| `~/.claude/skills/powerbi-dashboard/assets/hybrid.js` | Se copia al proyecto. Es el generador. |
| `~/.claude/skills/powerbi-dashboard/reference/SISTEMA.md` | **Antes de escribir el primer visual.** Patrones de Deneb, HTML y DAX. |
| `~/.claude/skills/powerbi-dashboard/reference/GOTCHAS.md` | **Antes del primer `reload`.** Errores ya pagados con horas. |
| `~/.claude/skills/powerbi-dashboard/reference/PERSONALIZACION.md` | Cuando el usuario pide color, layout, nº de páginas o filtro a medida. |
| `~/.claude/skills/powerbi-dashboard/assets/FiltroGeneralUniversal.pbiviz` | El visual de filtros clásico, para que el usuario lo importe. |
| `~/.claude/skills/powerbi-dashboard/assets/FiltroUniversal+.pbiviz` | **Filtro Universal+**: el mismo filtro con estilos, tamaño, alineación y orientación configurables. Recomendado para reportes nuevos. |

Skills complementarias (se invocan solas): `deneb-chart-generator` (plantillas de gráfica),
`html-kpi-cards` (tarjetas y badges), `powerbi-filter` (barra de filtros),
`powerbi-dax-auditor` (auditoría del modelo).

---

## Regla de oro: decidir, no preguntar

El usuario suele dar una frase corta —"crea un dashboard del reporte que tengo abierto"— y eso
**es suficiente**. No lo interrogues. Audita el modelo, elige tú la estructura, anuncia en una
línea lo que vas a hacer ("Voy a armar 3 páginas: Resumen, Producto y Operación, con acento teal
— dime si prefieres otra cosa") y sigue trabajando sin esperar respuesta.

Si el usuario **sí** especifica algo, eso manda sobre cualquier default. Ver
`reference/PERSONALIZACION.md` para traducir cada tipo de instrucción a `CFG`.

Detente a preguntar **solo** si falta algo que no puedes deducir de los datos y que cambiaría el
resultado por completo (p. ej. no encuentras ninguna instancia de Power BI abierta y hay varios
`.pbip` candidatos en disco).

**Defaults cuando no dicen nada:** 3 páginas · lienzo 1440×1080 · navegación en sidebar
izquierdo · barra de Filtro arriba · acento derivado del dominio del negocio · tema claro ·
tipografía Segoe UI.

Estructura por defecto de las 3 páginas (adáptala al negocio real que veas en los datos):
1. **Resumen ejecutivo** — KPIs, tendencia temporal con comparativo, mix principal, ranking de la
   dimensión más importante.
2. **Análisis del "qué"** — el objeto de negocio (producto/servicio/cliente): ranking,
   rentabilidad o contribución, y algo que separe lo bueno de lo que hay que revisar.
3. **Análisis del "cómo/cuándo"** — operación: patrón temporal (mapa de calor hora × día),
   desempeño por unidad operativa, canales.

---

## Las 3 fugas de tiempo — reglas duras

Un dashboard de 3 páginas sale en una sesión. Lo que lo hace lento:

1. **Nunca crear medidas de una en una.** `measure_operations` acepta una LISTA: crea las 20-30
   medidas en **una sola llamada**. Igual con columnas y relaciones. Decenas de round-trips se
   vuelven tres.
2. **Nunca escribir un visual dos veces.** Tooltips y cross-filter se escriben desde el primer
   intento, no como pasada de pulido. Reescribir 13 gráficas cuesta más que el dashboard entero.
3. **Nunca construir todas las páginas antes de validar.** Página 1 completa → `validate` →
   recarga → screenshot → corregida → recién entonces página 2. Así una sesión que se alarga
   igual deja páginas terminadas y usables, no todas a medias.

Máximo **2 rondas** de corrección por captura. Si a la tercera algo sigue mal, déjalo anotado y
sigue — no te atores en un pixel.

---

## Procedimiento

### 0 · Situarse (2 min, no lo saltes)

```powershell
powerbi-desktop status
```

De la respuesta necesitas tres cosas:

- **El PID** de la instancia — para `reload` y `screenshot`.
- **La ruta del `.pbip`** — es lo que va en `CFG.report` (apuntando a la carpeta `<Nombre>.Report`).
- **`hasUnsavedChanges`** — ⚠️ **si es `true`, NO recargues todavía.** Hay estado vivo en Desktop
  (típicamente los custom visuals recién importados) que un `reload` descarta sin avisar. Pídele
  al usuario que guarde con Ctrl+S primero, o trabaja solo el modelo hasta que guarde. Saltarse
  esto costó 1h30 en un proyecto real (ver `reference/GOTCHAS.md`).

Verifica también el **título de la ventana** de Power BI: si en la carpeta hay un `.pbix` viejo
junto al `.pbip`, es fácil terminar mirando el archivo equivocado y debuggear un bug que no existe.

Si Power BI no está abierto, ábrelo tú (`Start-Process -FilePath "<ruta>.pbip"`); nunca le pidas
al usuario que lo abra.

**Prerrequisitos** — verifícalos, no los asumas:
- CLIs: `powerbi-report-author` y `powerbi-desktop` responden.
- Los 3 custom visuals importados **en ese reporte** (es por reporte, no global): Deneb y HTML
  Content desde AppSource; el Filtro desde `assets/FiltroGeneralUniversal.pbiviz` o el Filtro Universal+ desde `assets/FiltroUniversal+.pbiviz` (debe coincidir con `CFG.guids.filtro`). Si faltan, los
  visuales salen vacíos — es el único paso que no puedes hacer tú: pídeselo al usuario una vez y
  sigue con el modelo mientras tanto.

### 1 · Auditar y completar el modelo (MCP, PBI abierto)

- Lista tablas y columnas, y **mide cardinalidades reales con DAX** antes de opinar.
- Aplica la regla de eficiencia: la fact solo con claves int y números; nada de IDs de texto
  únicos, timestamps crudos ni floats innecesarios. Si el modelo cargado ya la viola, dilo y
  propón el arreglo — no lo optimices al final, arráncalo bien.
- Crea la tabla de calendario, márcala como tabla de fechas y **pon `sortByColumn`** en nombre de
  mes y día de semana (si no, salen alfabéticos — error clásico).
- Crea las relaciones que falten y **revisa que estén activas** (una relación inactiva hace que
  todo el dashboard muestre el mismo número repetido).
- Oculta las columnas `*Key`, pero **deja visibles las que vayan a usarse como eje o categoría**
  (una columna oculta en el eje deja el visual en error).
- Verifica con una consulta DAX de control que los totales cuadran **antes** de construir nada.

### 2 · Medidas (MCP, una sola llamada por lote)

Volumen, valor, promedios, comparativos vs periodo anterior, % de crecimiento, mix y rankings.
Con `formatString` y `displayFolder` correctos desde el inicio. Más las medidas HTML de las
tarjetas KPI (skill `html-kpi-cards`).

Omite `dataType` al crear medidas (limitación del MCP). Valida el HTML generado con
`EVALUATE ROW("len", LEN(<medida>))` antes de darlo por bueno.

### 3 · Construir, página por página

```powershell
copy ~\.claude\skills\powerbi-dashboard\assets\hybrid.js <proyecto>\_gen\hybrid.js
```

Edita **solo dos zonas** de `hybrid.js`:
- **`CFG`** (arriba): `report`, `brand`, `tagline`, `accent`, `theme`, `nav`, `filter`, `canvas`.
- **`PAGES`** (abajo): una entrada por página con `id`, `name`, `title`, `filters` y `body()`.

Todo lo demás —geometría, paleta derivada, fábricas, cross-filter— se reutiliza sin tocar.

Por cada página:

```powershell
node _gen/hybrid.js
powerbi-report-author validate "<ruta>\<Reporte>.Report"   # "Unknown visualType" = normal
powerbi-desktop reload --pid <PID>
powerbi-desktop screenshot-all --pid <PID>
```

Luego **evalúa tú mismo la captura** con el checklist de abajo.

⚠️ **Si agregaste o quitaste páginas, `reload` no basta**: `screenshot` responderá
`"Unknown pageId"` aunque `reload` diga `success:true`. Hay que cerrar y reabrir Power BI. Ver
`reference/GOTCHAS.md` — es el gotcha que más tiempo cuesta si no se conoce.

**Reglas de construcción no negociables:**
- KPIs y tarjetas → `htmlCard`. Gráficas y tablas → `deneb`. Filtros → `filtro`. Los visuales
  nativos quedan solo para mapas geográficos y el navegador de páginas.
- Cross-filter en todas las Deneb: clic en una barra debe cambiar las tarjetas y el resto de la
  página. Va incluido en las fábricas; no lo desactives.
- Tooltips desde el primer intento (SISTEMA.md §8.1).

### 4 · Checklist de la captura

1. ¿Hay diálogos de error de Power BI encima? → corrígelos primero, la captura no vale.
2. ¿Los visuales tienen datos? Deneb o HTML en blanco = medida rota, dataset mal referenciado,
   GUID equivocado, o render aún async (espera ~3 s y recaptura).
3. ¿El Filtro se ve como barra de pills con texto? Si son rectángulos blancos vacíos, es recorte
   vertical, no un problema de datos (GOTCHAS).
4. ¿El layout coincide? Sin solapes ni huecos; alineación de cuadrícula.
5. ¿Estética coherente? Una sola paleta; tema de tarjetas = fondo de página; sin texto cortado.

Lo que la captura **no** verifica: el cross-filter al hacer clic. Se garantiza por construcción;
indícale al usuario cómo probarlo.

### 5 · Cierre

Muestra las capturas y un resumen corto: tamaño del modelo, medidas creadas y —lo más valioso—
**los hallazgos de negocio que encontraste en los datos**, no solo lo que construiste.

---

## Calidad — lo que hace que no parezca "hecho por IA"

- Sin emojis. Glifos funcionales sí (`▲▼` como `&#9650;`/`&#9660;`, `•` como separador).
- Una sola paleta de acento en tarjetas, gráficas y el acento del Filtro. Nunca colores sueltos.
- Lo más importante arriba/izquierda; controles agrupados; márgenes consistentes.
- Texto sobrio del dominio del negocio, no rótulos genéricos tipo "Gráfica 1".
- Todas las páginas se sienten un solo producto: misma paleta, tipografía y layout.
- Sin acentos dentro de strings DAX en `.tmdl` → usa ASCII plano o entidades HTML (`&#211;`).
  Los nombres de medidas sí pueden llevar acentos.
