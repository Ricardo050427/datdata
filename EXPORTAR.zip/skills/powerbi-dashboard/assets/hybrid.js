/* ============================================================================
   hybrid.js — generador de dashboards Power BI (Metodología 2, híbrida)

   Pipeline de Fabric (PBIR, cuadrícula, navegador de páginas) + custom visuals
   propios: Deneb (gráficas), HTML Content (tarjetas), Filtro (barra de filtros).

   PLANTILLA REUTILIZABLE. Para un proyecto nuevo solo se tocan dos zonas:
     1) CFG          — ruta del reporte, marca, color, layout, lienzo
     2) PAGES        — una entrada por página, al final del archivo

   Todo lo demás (geometría, paleta derivada, fábricas, cross-filter) se reutiliza
   sin cambios. Ejecutar con:  node _gen/hybrid.js
   ============================================================================ */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/* ============================================================================
   1 · CONFIGURACIÓN  — lo único que cambia entre proyectos
   ============================================================================ */
const CFG = {
  // Ruta a la carpeta <Reporte>.Report del proyecto .pbip (barras normales o /)
  report: 'C:/ruta/a/MiReporte.Report',

  // Identidad visual del dashboard
  brand:   'Mi Reporte',            // título de la marca (sidebar o barra superior)
  tagline: 'Subtítulo del negocio', // línea secundaria; '' para ocultarla
  footer:  '',                      // pie del sidebar; '' para ocultarlo

  // UN SOLO color de acento. Toda la paleta se deriva de aquí (ver derivePalette).
  // "lo quiero verde" → '#2B8A3E' · azul → '#1C7ED6' · morado → '#6A0DAD'
  accent: '#0C8599',

  theme:  'light',   // 'light' | 'dark'  → fondo de página y de tarjetas
  nav:    'left',    // 'left'  | 'top'   → navegador de páginas: sidebar o barra superior
  filter: 'top',     // 'top'   | 'left'  | 'none' → posición de la barra de Filtro

  canvas: { w: 1440, h: 1080 },   // lienzo del reporte

  // GUIDs de los custom visuals. Deben coincidir con los importados en el reporte.
  // Para leer el GUID de un .pbiviz: descomprimir → resources/<guid>.pbiviz.json
  guids: {
    deneb:  'deneb7E15AEF80B9E4D4F8E12924291ECE89A',
    html:   'htmlContent443BE3AD55E043BF878BED274D3A6855',
    filtro: 'filtroGeneralUniversal8A3E1F9C2B4D1E5F',
  },
};

/* ============================================================================
   2 · PALETA DERIVADA  — no editar: sale sola del CFG.accent
   ============================================================================ */
function hexToHsl(hex) {
  const n = parseInt(hex.slice(1), 16);
  let r = ((n >> 16) & 255) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0; const l = (mx + mn) / 2;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  if (d !== 0) {
    if (mx === r) h = ((g - b) / d) % 6;
    else if (mx === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60; if (h < 0) h += 360;
  }
  return { h, s, l };
}
function hslToHex(h, s, l) {
  h = ((h % 360) + 360) % 360; s = Math.min(1, Math.max(0, s)); l = Math.min(1, Math.max(0, l));
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = l - c / 2;
  let r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
  const to = v => Math.round((v + m) * 255).toString(16).padStart(2, '0');
  return '#' + to(r) + to(g) + to(b);
}
function darken(hex, f) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  r = Math.round(r * (1 - f)); g = Math.round(g * (1 - f)); b = Math.round(b * (1 - f));
  return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

const A = hexToHsl(CFG.accent);
const dark = CFG.theme === 'dark';

const PAL = {
  accent:     CFG.accent,
  accentDark: darken(CFG.accent, 0.24),                       // hover de las marcas
  accentTint: hslToHex(A.h, Math.max(0.25, A.s * 0.55), 0.90), // extremo bajo del heatmap
  // Serie categórica: acento + hues repartidos. Sirve para donuts y multi-serie
  // con CUALQUIER acento (si el acento es verde, la serie 2 no será verde).
  // Saturación y luminosidad acotadas a una banda sobria: sin neones ni tonos
  // que se pierdan sobre fondo blanco.
  series: [
    CFG.accent,
    ...[150, 60, 210, 300, 105].map(dh =>
      hslToHex(A.h + dh, Math.min(0.68, Math.max(0.42, A.s * 0.9)), Math.min(0.50, Math.max(0.36, A.l)))),
  ],
  // Cromo (sidebar / barra superior): mismo hue que el acento, muy oscuro.
  chrome:     hslToHex(A.h, Math.max(0.30, A.s * 0.55), 0.13),
  chromeHi:   hslToHex(A.h, Math.max(0.28, A.s * 0.50), 0.21),
  chromeText: hslToHex(A.h, 0.18, 0.72),
  chromeMute: hslToHex(A.h, 0.14, 0.55),
  // Superficies
  pageBg:     dark ? hslToHex(A.h, 0.16, 0.11) : hslToHex(A.h, 0.16, 0.96),
  cardBg:     dark ? hslToHex(A.h, 0.14, 0.16) : '#FFFFFF',
  cardBorder: dark ? hslToHex(A.h, 0.12, 0.24) : hslToHex(A.h, 0.14, 0.91),
  ink:        dark ? '#EEF2F6' : '#1F2933',
  muted:      dark ? hslToHex(A.h, 0.10, 0.62) : '#6B7A86',
  grid:       dark ? hslToHex(A.h, 0.10, 0.22) : hslToHex(A.h, 0.12, 0.94),
  axis:       dark ? '#9AA7B2' : '#6B7280',
  good:       '#2F9E44',
  bad:        '#E03131',
};

/* ============================================================================
   3 · GEOMETRÍA  — se recalcula sola según CFG.nav / CFG.filter
   ============================================================================ */
const CW = CFG.canvas.w, CH = CFG.canvas.h;
const M = 24;                                   // margen exterior
const NAV_W = 248, NAV_H = 72;                  // sidebar izquierdo / barra superior
const FILTER_H = 68;                            // ⚠ mínimo 68px (ver gotcha del Filtro)
const FILTER_W = 236;                           // ancho del riel de filtro vertical
const TITLE_H = 56;

const navLeft = CFG.nav === 'left';
const filterTop = CFG.filter === 'top';
const filterLeft = CFG.filter === 'left';
const hasFilter = CFG.filter !== 'none';

// Zona de contenido: lo que queda tras descontar navegación, título y filtro.
const CONTENT_X0 = navLeft ? NAV_W + M : M;
const CONTENT_Y0 = navLeft ? M : NAV_H + M;

const TITLE_BOX = { x: CONTENT_X0, y: CONTENT_Y0, w: CW - CONTENT_X0 - M, h: TITLE_H };

const FILTER_BOX = filterTop
  ? { x: CONTENT_X0, y: CONTENT_Y0 + TITLE_H, w: CW - CONTENT_X0 - M, h: FILTER_H }
  : filterLeft
    ? { x: CONTENT_X0, y: CONTENT_Y0 + TITLE_H, w: FILTER_W, h: CH - (CONTENT_Y0 + TITLE_H) - M }
    : null;

const BODY = {
  x: CONTENT_X0 + (filterLeft ? FILTER_W + M : 0),
  y: CONTENT_Y0 + TITLE_H + (filterTop ? FILTER_H + 12 : 0),
  w: CW - CONTENT_X0 - M - (filterLeft ? FILTER_W + M : 0),
  h: CH - (CONTENT_Y0 + TITLE_H + (filterTop ? FILTER_H + 12 : 0)) - M,
};

const CCOLS = 12, CROWS = 10, GX = 16, GY = 16;
const colW = (BODY.w - (CCOLS - 1) * GX) / CCOLS;
const rowH = (BODY.h - (CROWS - 1) * GY) / CROWS;
const snap = v => Math.round(v / 4) * 4;

/** Coloca un visual en la cuadrícula 12×10. Columnas/filas 1-indexadas,
 *  el segundo par es EXCLUSIVO: cg(1,1,7,4) ocupa las columnas 1-6, filas 1-3. */
function cg(c0, r0, c1, r1) {
  let x = snap(BODY.x + (c0 - 1) * (colW + GX));
  let y = snap(BODY.y + (r0 - 1) * (rowH + GY));
  let w = snap((c1 - c0) * colW + (c1 - c0 - 1) * GX);
  let h = snap((r1 - r0) * rowH + (r1 - r0 - 1) * GY);
  if (x + w > CW - M) w = (CW - M) - x;
  if (y + h > CH - M) h = (CH - M) - y;
  return { x, y, w, h };
}

/* ============================================================================
   4 · PRIMITIVAS PBIR
   ============================================================================ */
const REPORT = CFG.report.replace(/\\/g, '/');
const PAGES_DIR = path.join(REPORT, 'definition', 'pages');
const VC = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.9.0/schema.json';
const PAGE_SCHEMA = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json';
const { deneb: DENEB, html: HTML, filtro: FILTRO } = CFG.guids;

const vid = () => crypto.randomBytes(10).toString('hex');
const litExpr = v => ({ expr: { Literal: { Value: v } } });
const solid = hex => ({ solid: { color: { expr: { Literal: { Value: `'${hex}'` } } } } });
const col = (e, p) => ({ Column: { Expression: { SourceRef: { Entity: e } }, Property: p } });
const meas = (e, p) => ({ Measure: { Expression: { SourceRef: { Entity: e } }, Property: p } });
const projCol = (e, p) => ({ field: col(e, p), queryRef: `${e}.${p}`, nativeQueryRef: p });
const projMeas = (e, p) => ({ field: meas(e, p), queryRef: `${e}.${p}`, nativeQueryRef: p });

let Z = 1000;
const pos = (b, z) => ({ x: b.x, y: b.y, z: z != null ? z : (Z += 10), height: b.h, width: b.w, tabOrder: Z });

function write(pageName, v) {
  const dir = path.join(PAGES_DIR, pageName, 'visuals', v.name);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'visual.json'), JSON.stringify(v, null, 2));
}

/* ============================================================================
   5 · FÁBRICAS DE CUSTOM VISUALS  — se usan, no se editan
   ============================================================================ */

/** HTML Content: una medida DAX que devuelve un string HTML completo.
 *  La medida se crea por MCP; reacciona a filtros porque se evalúa en contexto. */
function htmlCard(entity, measure, box) {
  return { $schema: VC, name: vid(), position: pos(box), visual: {
    visualType: HTML,
    query: { queryState: { content: { projections: [projMeas(entity, measure)] } } },
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('false') } }],
      border: [{ properties: { show: litExpr('false') } }],
      title: [{ properties: { show: litExpr('false') } }],
    },
    drillFilterOtherVisuals: true,
  } };
}

/** Barra de Filtro: un visual maneja N columnas (rol `fields`).
 *  ⚠ fontSize 12 es OBLIGATORIO: el default del visual es 17px y las pills
 *  (~57px de alto) se recortan en una barra normal, quedando en blanco. */
function filtro(fields, box, opts = {}) {
  const projections = fields.map(f => projCol(f.entity, f.column));
  const v = { $schema: VC, name: vid(), position: pos(box, 6000), visual: {
    visualType: FILTRO,
    query: { queryState: { fields: { projections } }, sortDefinition: { isDefaultSort: true } },
    drillFilterOtherVisuals: true,
    objects: { visualStyles: [{ properties: {
      fontSize: litExpr((opts.fontSize || 12) + 'D'),
      alignment: litExpr(`'${opts.alignment || (filterLeft ? 'flex-start' : 'space-between')}'`),
      accentColor: solid(opts.accent || PAL.accent),
    } }] },
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('false') } }],
      border: [{ properties: { show: litExpr('false') } }],
      title: [{ properties: { show: litExpr('false') } }],
      visualHeader: [{ properties: { show: litExpr('false') } }],
    },
  } };
  return v;
}

/** Deneb: dataset (columnas + medidas) + spec Vega-Lite serializada.
 *  El cross-filter va incluido por construcción (enableSelection + __selected__). */
function deneb(datasetFields, spec, box, filters) {
  const projections = datasetFields.map(f => f.kind === 'measure' ? projMeas(f.entity, f.prop) : projCol(f.entity, f.prop));
  const specText = JSON.stringify(spec);
  const v = { $schema: VC, name: vid(), position: pos(box), visual: {
    visualType: DENEB,
    query: { queryState: { dataset: { projections } }, sortDefinition: { isDefaultSort: true } },
    objects: {
      vega: [{ properties: {
        provider: litExpr(`'${spec.__provider || 'vegaLite'}'`),
        jsonSpec: { expr: { Literal: { Value: "'" + specText.replace(/'/g, "''") + "'" } } },
        jsonConfig: litExpr("'{}'"),
        enableTooltips: litExpr('true'),
        enableContextMenu: litExpr('true'),
        enableSelection: litExpr('true'),
        selectionMode: litExpr("'simple'"),
        selectionMaxDataPoints: litExpr('200D'),
        version: litExpr("'6.4.1'"),
      } }],
      stateManagement: [{ properties: { viewportHeight: litExpr((box.h - 16) + 'D'), viewportWidth: litExpr((box.w - 16) + 'D') } }],
    },
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('true'), color: solid(PAL.cardBg) } }],
      border: [{ properties: { show: litExpr('true'), color: solid(PAL.cardBorder), radius: litExpr('12D') } }],
      dropShadow: [{ properties: { show: litExpr(dark ? 'false' : 'true'), preset: litExpr("'Custom'"), position: litExpr("'Outer'"), color: solid('#8C9CA8'), transparency: litExpr('82D'), shadowBlur: litExpr('16D'), shadowDistance: litExpr('4D'), angle: litExpr('90D') } }],
      title: [{ properties: { show: litExpr(spec.__title ? 'true' : 'false'), text: litExpr(`'${(spec.__title || '').replace(/'/g, "''")}'`), fontColor: solid(PAL.ink), bold: litExpr('true'), alignment: litExpr("'left'"), fontSize: litExpr('12D') } }],
    },
    drillFilterOtherVisuals: true,
  } };
  // ⚠ filterConfig es HERMANO de `visual`, no va dentro.
  if (filters) v.filterConfig = { filters };
  return v;
}

/* ============================================================================
   6 · CONSTRUCTORES DE SPEC VEGA-LITE  — cross-filter incorporado
   ============================================================================ */
const AX = { labelColor: PAL.axis, labelFont: 'Segoe UI', titleColor: PAL.axis, domainColor: PAL.grid, tickColor: PAL.grid };
const GRID = { grid: true, gridColor: PAL.grid, gridDash: [2, 3] };
const usermeta = { deneb: { build: '', metaVersion: 1, provider: 'vegaLite', providerVersion: '5.6.0',
  interactivity: { tooltip: true, contextMenu: true, selection: true, selectionMode: 'single', dataPointLimit: 50 } } };
const cfgV = { view: { stroke: null }, font: 'Segoe UI', axis: { labelFontSize: 11, titleFontSize: 11 } };

// Hover = marca bajo el cursor (sin `fields`). El clic/cross-filter lo maneja
// Deneb NATIVAMENTE (enableSelection) y lo expone como datum['__selected__'].
// ⚠ NO añadir un param de selección Vega: entra en conflicto con el nativo.
const HOVER = [{ name: 'hover', select: { type: 'point', on: 'mouseover', clear: 'mouseout' } }];
const selDim = { condition: { test: "datum['__selected__'] == 'off'", value: 0.3 }, value: 1 };
const hoverFill = hex => ({ condition: { param: 'hover', empty: false, value: darken(hex, 0.24) }, value: hex });
const hoverStroke = { condition: { param: 'hover', empty: false, value: PAL.ink }, value: null };
const hoverStrokeW = { condition: { param: 'hover', empty: false, value: 2 }, value: 0 };

const base = title => ({ $schema: 'https://vega.github.io/schema/vega-lite/v5.json', __title: title,
  data: { name: 'dataset' }, width: 'container', height: 'container',
  autosize: { type: 'fit', contains: 'padding' }, usermeta, config: cfgV });

/** Barras horizontales ordenadas por valor. Ideal para rankings y nombres largos. */
function vBar(title, catF, valF, color) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'bar', cornerRadiusEnd: 4, cursor: 'pointer' };
  s.encoding = {
    y: { field: catF, type: 'nominal', sort: '-x', axis: { title: null, ...AX, labelLimit: 160 } },
    x: { field: valF, type: 'quantitative', axis: { title: null, ...AX, ...GRID, format: '~s' } },
    color: hoverFill(color || PAL.accent), opacity: selDim,
    tooltip: [{ field: catF, type: 'nominal' }, { field: valF, type: 'quantitative', format: ',' }],
  };
  return s;
}

/** Columnas verticales. catType: 'ordinal' (números) | 'nominal' (texto). */
function vColumn(title, catF, valF, color, catType, sortOrder) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'bar', cornerRadiusEnd: 3, cursor: 'pointer' };
  s.encoding = {
    x: { field: catF, type: catType || 'ordinal', axis: { title: null, ...AX, labelAngle: 0 }, ...(sortOrder ? { sort: sortOrder } : {}) },
    y: { field: valF, type: 'quantitative', axis: { title: null, ...AX, ...GRID, format: '~s' } },
    color: hoverFill(color || PAL.accent), opacity: selDim,
    tooltip: [{ field: catF }, { field: valF, type: 'quantitative', format: ',' }],
  };
  return s;
}

/** Línea con puntos al hover. seriesF opcional para multi-serie. */
function vLine(title, xF, valF, xType, seriesF, domain, range) {
  const s = base(title);
  const xEnc = { field: xF, type: xType, axis: { title: null, ...AX } };
  const yEnc = { field: valF, type: 'quantitative', axis: { title: null, ...AX, ...GRID, format: '~s' } };
  const lineMark = { type: 'line', strokeWidth: 2.5, interpolate: 'monotone' };
  const lineEnc = { x: xEnc, y: yEnc, opacity: selDim };
  const ptEnc = { x: xEnc, y: yEnc, opacity: selDim,
    size: { condition: { param: 'hover', empty: false, value: 200 }, value: 40 },
    tooltip: [{ field: xF, type: xType }, { field: valF, type: 'quantitative', format: ',' }] };
  if (seriesF) {
    const scale = domain ? { domain, range: range || PAL.series.slice(0, domain.length) } : { range: PAL.series };
    const colorEnc = { field: seriesF, type: 'nominal', scale, legend: { title: null, orient: 'top', labelColor: PAL.muted } };
    lineEnc.color = colorEnc; ptEnc.color = colorEnc;
  } else {
    lineMark.color = PAL.accent;
    ptEnc.color = { condition: { param: 'hover', empty: false, value: PAL.accentDark }, value: PAL.accent };
  }
  s.layer = [
    { mark: lineMark, encoding: lineEnc },
    { params: HOVER, mark: { type: 'point', filled: true, cursor: 'pointer' }, encoding: ptEnc },
  ];
  return s;
}

/** Dona. Sin `domain` usa la paleta de serie derivada del acento. */
function vDonut(title, catF, valF, domain, range) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'arc', innerRadius: 60, cornerRadius: 2, cursor: 'pointer' };
  const scale = domain ? { domain, range: range || PAL.series.slice(0, domain.length) } : { range: PAL.series };
  s.encoding = {
    theta: { field: valF, type: 'quantitative', stack: true },
    color: { field: catF, type: 'nominal', scale, legend: { title: null, orient: 'right', labelColor: PAL.muted } },
    opacity: selDim, stroke: hoverStroke, strokeWidth: hoverStrokeW,
    tooltip: [{ field: catF }, { field: valF, type: 'quantitative', format: ',' }],
  };
  return s;
}

/** Histograma / distribución de una columna numérica. */
function vHist(title, field, valF, color, maxbins) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'bar', cornerRadiusEnd: 3, cursor: 'pointer' };
  s.transform = [{ filter: `isValid(datum['${field}']) && datum['${field}'] != null` }];
  s.encoding = {
    x: { field, type: 'quantitative', bin: { maxbins: maxbins || 30 }, axis: { title: null, ...AX, labelAngle: 0 } },
    y: { field: valF, type: 'quantitative', aggregate: 'sum', axis: { title: null, ...AX, ...GRID, format: '~s' } },
    color: hoverFill(color || PAL.accent), opacity: selDim,
    tooltip: [{ field, type: 'quantitative', bin: { maxbins: maxbins || 30 } }, { field: valF, type: 'quantitative', aggregate: 'sum', format: ',' }],
  };
  return s;
}

/** Mapa de calor (p. ej. hora × día de la semana). */
function vHeatmap(title, xF, xOrder, yF, valF, yTitle) {
  const s = base(title); s.params = HOVER;
  s.mark = { type: 'rect', cornerRadius: 2, cursor: 'pointer' };
  s.encoding = {
    x: { field: xF, type: 'nominal', sort: xOrder, axis: { title: null, ...AX, labelAngle: 0 } },
    y: { field: yF, type: 'ordinal', axis: { title: yTitle || null, ...AX } },
    color: { field: valF, type: 'quantitative', scale: { range: [PAL.accentTint, PAL.accent] }, legend: null },
    opacity: selDim, stroke: hoverStroke, strokeWidth: hoverStrokeW,
    tooltip: [{ field: yF }, { field: xF }, { field: valF, type: 'quantitative', format: ',' }],
  };
  return s;
}

/** Tendencia temporal: área con degradado + línea + pico y mínimo marcados.
 *  Trae su propio título Vega, por eso no define __title. */
function vTrend(titleText, subtitleText, dateF, valF, unit) {
  return {
    $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
    data: { name: 'dataset' }, width: 'container', height: 'container',
    autosize: { type: 'fit', contains: 'padding' }, usermeta,
    config: { view: { stroke: null }, font: 'Segoe UI' },
    title: { text: titleText, subtitle: subtitleText || '', font: 'Segoe UI', fontSize: 15, fontWeight: 'bold',
      color: PAL.ink, subtitleFont: 'Segoe UI', subtitleFontSize: 11, subtitleColor: PAL.muted, anchor: 'start', offset: 12 },
    transform: [
      { timeUnit: unit || 'yearmonth', field: dateF, as: '__t' },
      { aggregate: [{ op: 'sum', field: valF, as: '__v' }], groupby: ['__t'] },
      { window: [{ op: 'rank', as: 'rk_desc' }], sort: [{ field: '__v', order: 'descending' }] },
      { window: [{ op: 'rank', as: 'rk_asc' }], sort: [{ field: '__v', order: 'ascending' }] },
    ],
    encoding: {
      x: { field: '__t', type: 'temporal', axis: { title: null, grid: false, ticks: false, labelColor: PAL.axis,
        domainColor: PAL.grid, labelFontSize: 11, labelOverlap: true,
        labelExpr: "span(domain('x')) > 47520000000 ? (month(datum.value) == 0 ? timeFormat(datum.value, '%Y') : '') : timeFormat(datum.value, '%b')" } },
      y: { field: '__v', type: 'quantitative', axis: { title: null, format: '~s', grid: true, gridColor: PAL.grid,
        gridDash: [2, 3], labelColor: PAL.axis, domain: false, ticks: false } },
    },
    layer: [
      { mark: { type: 'area', interpolate: 'monotone', line: false }, encoding: {
        color: { value: { gradient: 'linear', x1: 0, y1: 1, x2: 0, y2: 0,
          stops: [{ offset: 0, color: PAL.cardBg }, { offset: 1, color: PAL.accent }] } },
        opacity: { condition: { test: "datum['__selected__'] == 'off'", value: 0.04 }, value: 0.25 } } },
      { mark: { type: 'line', interpolate: 'monotone', color: PAL.accent, strokeWidth: 2.5 },
        encoding: { opacity: { condition: { test: "datum['__selected__'] == 'off'", value: 0.25 }, value: 1 } } },
      { params: HOVER, mark: { type: 'point', filled: true, color: PAL.accent, cursor: 'pointer' }, encoding: {
        size: { condition: { param: 'hover', empty: false, value: 170 }, value: 22 }, opacity: { value: 0.55 },
        tooltip: [{ field: '__t', type: 'temporal', title: 'Periodo', format: '%b %Y' },
                  { field: '__v', type: 'quantitative', title: 'Valor', format: ',' }] } },
      { transform: [{ filter: 'datum.rk_desc == 1' }], mark: { type: 'point', filled: true, size: 150, color: PAL.good, stroke: PAL.cardBg, strokeWidth: 1.5 } },
      { transform: [{ filter: 'datum.rk_desc == 1' }], mark: { type: 'text', dy: -14, fontSize: 11, fontWeight: 'bold', color: PAL.good }, encoding: { text: { field: '__v', format: '~s' } } },
      { transform: [{ filter: 'datum.rk_asc == 1' }], mark: { type: 'point', filled: true, size: 150, color: PAL.series[1], stroke: PAL.cardBg, strokeWidth: 1.5 } },
      { transform: [{ filter: 'datum.rk_asc == 1' }], mark: { type: 'text', dy: 16, fontSize: 11, fontWeight: 'bold', color: PAL.series[1] }, encoding: { text: { field: '__v', format: '~s' } } },
    ],
  };
}

/* --- modificadores de spec --------------------------------------------------
   ⚠ Deneb NO acepta filtros de visual PBIR ("error en uno o más filtros").
   Todo el filtrado va DENTRO de la spec, con transform.                       */

/** Excluye vacíos y deja el top N. Sustituye al filtro TopN de PBIR. */
function withTopN(spec, catF, valF, n) {
  spec.transform = [
    { filter: `isValid(datum['${catF}']) && datum['${catF}'] != ''` },
    { window: [{ op: 'rank', as: '__rk' }], sort: [{ field: valF, order: 'descending' }] },
    { filter: `datum.__rk <= ${n}` },
  ];
  return spec;
}
/** Añade un filtro Vega arbitrario encima de los que ya tenga la spec. */
function withFilter(spec, expr) { spec.transform = [...(spec.transform || []), { filter: expr }]; return spec; }
/** Recolorea una spec ya construida (útil para diferenciar una gráfica del resto). */
function recolor(spec, hex) {
  if (spec.mark && spec.encoding && spec.encoding.color) spec.encoding.color = hoverFill(hex);
  else if (spec.mark) spec.mark.color = hex;
  else if (spec.layer) spec.layer.forEach(l => {
    if (l.mark && l.mark.type === 'line') l.mark.color = hex;
    if (l.mark && l.mark.type === 'point') l.encoding.color = { condition: { param: 'hover', empty: false, value: darken(hex, 0.24) }, value: hex };
  });
  return spec;
}

/* ============================================================================
   7 · VISUALES NATIVOS REUTILIZADOS  (cromo, navegación, mapa)
   ============================================================================ */
function rect(box, hex, z, radius) {
  return { $schema: VC, name: vid(), position: pos(box, z), visual: {
    visualType: 'shape',
    objects: {
      shape: [{ properties: { tileShape: litExpr(radius ? "'rectangleRounded'" : "'rectangle'"), ...(radius ? { rectangleRoundedCurve: litExpr(radius + 'D') } : {}) } }],
      fill: [{ properties: { fillColor: solid(hex), transparency: litExpr('0D') }, selector: { id: 'default' } }],
      outline: [{ properties: { show: litExpr('false') }, selector: { id: 'default' } }],
    },
    visualContainerObjects: { background: [{ properties: { show: litExpr('false') } }], border: [{ properties: { show: litExpr('false') } }],
      padding: [{ properties: { top: litExpr('0D'), bottom: litExpr('0D'), left: litExpr('0D'), right: litExpr('0D') } }] },
  } };
}
function textbox(text, box, sizePx, color, semibold, z) {
  return { $schema: VC, name: vid(), position: pos(box, z), visual: {
    visualType: 'textbox',
    objects: { general: [{ properties: { paragraphs: [{ textRuns: [{ value: text, textStyle: { fontFamily: semibold ? 'Segoe UI Semibold' : 'Segoe UI', fontSize: sizePx, color } }], horizontalTextAlignment: 'left' }] } }] },
    visualContainerObjects: { background: [{ properties: { show: litExpr('false') } }], border: [{ properties: { show: litExpr('false') } }],
      padding: [{ properties: { top: litExpr('0D'), bottom: litExpr('0D'), left: litExpr('0D'), right: litExpr('0D') } }] },
  } };
}
/** Navegador de páginas nativo. vertical=true → sidebar; false → barra superior. */
function pageNav(box, vertical) {
  return { $schema: VC, name: vid(), position: pos(box, 9500), visual: {
    visualType: 'pageNavigator',
    objects: {
      layout: [{ properties: { orientation: litExpr(vertical ? '1D' : '0D'), cellPadding: litExpr('6D') } }],
      shape: [{ properties: { tileShape: litExpr("'rectangleRounded'"), rectangleRoundedCurve: litExpr('8D') } }],
      fill: [
        { properties: { show: litExpr('true'), fillColor: solid(PAL.chrome) }, selector: { id: 'default' } },
        { properties: { show: litExpr('true'), fillColor: solid(PAL.accent) }, selector: { id: 'selected' } },
        { properties: { show: litExpr('true'), fillColor: solid(PAL.chromeHi) }, selector: { id: 'hover' } },
      ],
      text: [
        { properties: { show: litExpr('true'), fontColor: solid(PAL.chromeText), fontSize: litExpr('12D') }, selector: { id: 'default' } },
        { properties: { show: litExpr('true'), fontColor: solid('#FFFFFF'), bold: litExpr('true'), fontSize: litExpr('12D') }, selector: { id: 'selected' } },
      ],
      outline: [{ properties: { show: litExpr('false') }, selector: { id: 'default' } }],
    },
    visualContainerObjects: { background: [{ properties: { show: litExpr('false') } }], border: [{ properties: { show: litExpr('false') } }],
      padding: [{ properties: { top: litExpr('0D'), bottom: litExpr('0D'), left: litExpr('0D'), right: litExpr('0D') } }] },
  } };
}
/** Mapa geográfico: el ÚNICO caso donde se usa un visual nativo de datos.
 *  cat/lat/lng son [entidad, columna]; size es [entidad, medida]. */
function azureMap(box, title, cat, lat, lng, size) {
  const agg = (e, p, fn) => ({ Aggregation: { Expression: { Column: { Expression: { SourceRef: { Entity: e } }, Property: p } }, Function: fn } });
  const pr = (f, e, p) => ({ field: f, queryRef: `${e}.${p}`, nativeQueryRef: p, active: true });
  return { $schema: VC, name: vid(), position: pos(box), visual: {
    visualType: 'azureMap',
    query: { queryState: {
      Category: { projections: [pr(col(cat[0], cat[1]), cat[0], cat[1])] },
      Y: { projections: [pr(agg(lat[0], lat[1], 1), lat[0], lat[1])] },
      X: { projections: [pr(agg(lng[0], lng[1], 1), lng[0], lng[1])] },
      Size: { projections: [pr(meas(size[0], size[1]), size[0], size[1])] },
    } }, objects: {},
    visualContainerObjects: {
      background: [{ properties: { show: litExpr('true'), color: solid(PAL.cardBg) } }],
      border: [{ properties: { show: litExpr('true'), color: solid(PAL.cardBorder), radius: litExpr('12D') } }],
      title: [{ properties: { show: litExpr('true'), text: litExpr(`'${title}'`), fontColor: solid(PAL.ink), bold: litExpr('true'), alignment: litExpr("'left'"), fontSize: litExpr('12D') } }],
    },
  } };
}

/* ============================================================================
   8 · CROMO DE PÁGINA  — sidebar o barra superior, según CFG.nav
   ============================================================================ */
function chrome(pageTitleText) {
  const out = [];
  const nPages = PAGES.length;

  if (navLeft) {
    out.push(rect({ x: 0, y: 0, w: NAV_W, h: CH }, PAL.chrome, 10));
    out.push(rect({ x: 28, y: 44, w: 40, h: 6 }, PAL.accent, 9600, 3));
    out.push(textbox(CFG.brand, { x: 28, y: 56, w: NAV_W - 48, h: 56 }, '28px', '#FFFFFF', true, 9600));
    if (CFG.tagline) out.push(textbox(CFG.tagline, { x: 28, y: 104, w: NAV_W - 48, h: 22 }, '12px', PAL.chromeMute, false, 9600));
    out.push(rect({ x: 24, y: 146, w: NAV_W - 48, h: 1 }, PAL.chromeHi, 9600));
    // 44px por página + holgura; el navegador crece con el número de páginas.
    out.push(pageNav({ x: 16, y: 168, w: NAV_W - 32, h: Math.max(120, nPages * 44 + 16) }, true));
    if (CFG.footer) out.push(textbox(CFG.footer, { x: 28, y: CH - 62, w: NAV_W - 48, h: 34 }, '11px', PAL.chromeMute, false, 9600));
  } else {
    out.push(rect({ x: 0, y: 0, w: CW, h: NAV_H }, PAL.chrome, 10));
    out.push(textbox(CFG.brand, { x: M, y: 16, w: 320, h: 40 }, '22px', '#FFFFFF', true, 9600));
    if (CFG.tagline) out.push(textbox(CFG.tagline, { x: M, y: 44, w: 320, h: 20 }, '11px', PAL.chromeMute, false, 9600));
    // Navegador horizontal a la derecha de la marca: ~140px por página.
    const navW = Math.min(CW - 380 - M, Math.max(240, nPages * 140));
    out.push(pageNav({ x: CW - M - navW, y: 16, w: navW, h: 40 }, false));
  }

  out.push(textbox(pageTitleText, TITLE_BOX, '22px', PAL.ink, true, 9000));
  return out;
}

/* ============================================================================
   9 · ESCRITURA DE PÁGINAS
   ============================================================================ */
const dC = (e, p) => ({ entity: e, prop: p, kind: 'column' });   // columna del dataset
const dM = (e, p) => ({ entity: e, prop: p, kind: 'measure' });  // medida del dataset

function writePage(page) {
  const dir = path.join(PAGES_DIR, page.id);
  fs.mkdirSync(path.join(dir, 'visuals'), { recursive: true });
  const def = { $schema: PAGE_SCHEMA, name: page.id, displayName: page.name,
    displayOption: 'FitToPage', height: CH, width: CW,
    objects: { background: [{ properties: { color: solid(PAL.pageBg), transparency: litExpr('0D') } }] } };
  fs.writeFileSync(path.join(dir, 'page.json'), JSON.stringify(def, null, 2));

  const items = [...chrome(page.title || page.name)];
  if (hasFilter && page.filters && page.filters.length) {
    items.push(filtro(page.filters.map(f => ({ entity: f[0], column: f[1] })), FILTER_BOX));
  }
  items.push(...page.body());
  items.forEach(v => write(page.id, v));
}

function build() {
  if (!fs.existsSync(PAGES_DIR)) {
    console.error('ERROR: no existe ' + PAGES_DIR + '\n  → revisa CFG.report (debe apuntar a la carpeta <Reporte>.Report)');
    process.exit(1);
  }
  const ids = PAGES.map(p => p.id);
  // Borra páginas huérfanas y limpia las que vamos a regenerar.
  for (const d of fs.readdirSync(PAGES_DIR)) {
    const full = path.join(PAGES_DIR, d);
    if (!fs.statSync(full).isDirectory()) continue;
    if (!ids.includes(d)) fs.rmSync(full, { recursive: true, force: true });
    else { const v = path.join(full, 'visuals'); if (fs.existsSync(v)) fs.rmSync(v, { recursive: true, force: true }); }
  }
  PAGES.forEach(writePage);
  fs.writeFileSync(path.join(PAGES_DIR, 'pages.json'), JSON.stringify({
    $schema: 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.1.0/schema.json',
    pageOrder: ids, activePageName: ids[0] }, null, 2));
  console.log(`OK — ${PAGES.length} página(s): ${PAGES.map(p => p.name).join(', ')}`);
  console.log(`   nav=${CFG.nav} · filtro=${CFG.filter} · acento=${CFG.accent} · lienzo ${CW}x${CH}`);
}

/* ============================================================================
   10 · PÁGINAS  — LA ÚNICA ZONA QUE SE ESCRIBE POR PROYECTO
   ------------------------------------------------------------------------
   Cada página: id (10 bytes hex, estable entre ejecuciones), name (el que se
   ve en el navegador), title (encabezado), filters ([tabla, columna]) y body().
   Los ejemplos de abajo son la FORMA; reemplazar tablas/columnas/medidas por
   las reales del modelo auditado.
   ============================================================================ */
const PAGES = [
  {
    id: 'a1b2c3d4e5f601020304', name: 'Resumen', title: 'Resumen ejecutivo',
    filters: [['dim_Fecha', 'Año'], ['dim_Fecha', 'Mes']],
    body: () => [
      htmlCard('fact_Ventas', 'KPI Strip HTML', cg(1, 1, 13, 3)),
      deneb([dC('dim_Fecha', 'Fecha'), dM('fact_Ventas', 'Total Ventas')],
        vTrend('Ventas por mes', 'Tendencia · pico y minimo marcados', 'Fecha', 'Total Ventas'), cg(1, 3, 13, 7)),
      deneb([dC('dim_Producto', 'Categoria'), dM('fact_Ventas', 'Total Ventas')],
        vDonut('Mix por categoria', 'Categoria', 'Total Ventas'), cg(1, 7, 7, 11)),
      deneb([dC('dim_Producto', 'Producto'), dM('fact_Ventas', 'Total Ventas')],
        withTopN(vBar('Top productos', 'Producto', 'Total Ventas'), 'Producto', 'Total Ventas', 10), cg(7, 7, 13, 11)),
    ],
  },
];

build();
