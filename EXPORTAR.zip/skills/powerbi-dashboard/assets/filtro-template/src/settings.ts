"use strict";

import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";

import FormattingSettingsCard = formattingSettings.SimpleCard;
import FormattingSettingsSlice = formattingSettings.Slice;
import FormattingSettingsModel = formattingSettings.Model;

class AppearanceCardSettings extends FormattingSettingsCard {
    accent = new formattingSettings.ColorPicker({
        name: "accent",
        displayName: "Color de acento",
        value: { value: "#0C8599" },
    });

    density = new formattingSettings.ItemDropdown({
        name: "density",
        displayName: "Tamaño",
        items: [
            { value: "compact", displayName: "Compacto" },
            { value: "normal", displayName: "Normal" },
            { value: "large", displayName: "Grande" },
            { value: "xlarge", displayName: "Extra grande" },
        ],
        value: { value: "large", displayName: "Grande" },
    });

    showClearAll = new formattingSettings.ToggleSwitch({
        name: "showClearAll",
        displayName: "Botón limpiar todo",
        value: true,
    });

    showCounts = new formattingSettings.ToggleSwitch({
        name: "showCounts",
        displayName: "Mostrar conteo de opciones",
        value: true,
    });

    name = "appearance";
    displayName = "Apariencia";
    slices: Array<FormattingSettingsSlice> = [this.accent, this.density, this.showClearAll, this.showCounts];
}

class LabelsCardSettings extends FormattingSettingsCard {
    normalizeValues = new formattingSettings.ToggleSwitch({
        name: "normalizeValues",
        displayName: "Normalizar valores",
        value: true,
    });

    renameTitles = new formattingSettings.ToggleSwitch({
        name: "renameTitles",
        displayName: "Títulos amigables",
        value: true,
    });

    hourFormat = new formattingSettings.ToggleSwitch({
        name: "hourFormat",
        displayName: "Formato de hora",
        value: true,
    });

    name = "labels";
    displayName = "Etiquetas";
    slices: Array<FormattingSettingsSlice> = [this.normalizeValues, this.renameTitles, this.hourFormat];
}

class SortingCardSettings extends FormattingSettingsCard {
    sortMode = new formattingSettings.ItemDropdown({
        name: "sortMode",
        displayName: "Ordenar valores",
        items: [
            { value: "auto", displayName: "Inteligente (recomendado)" },
            { value: "model", displayName: "Como venga del modelo" },
            { value: "alpha", displayName: "Alfabético" },
        ],
        value: { value: "auto", displayName: "Inteligente (recomendado)" },
    });

    name = "sorting";
    displayName = "Orden";
    slices: Array<FormattingSettingsSlice> = [this.sortMode];
}

export class VisualFormattingSettingsModel extends FormattingSettingsModel {
    appearanceCard = new AppearanceCardSettings();
    labelsCard = new LabelsCardSettings();
    sortingCard = new SortingCardSettings();

    cards = [this.appearanceCard, this.labelsCard, this.sortingCard];
}
