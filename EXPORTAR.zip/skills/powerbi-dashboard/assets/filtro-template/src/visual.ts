"use strict";

import powerbi from "powerbi-visuals-api";
import "./../style/visual.less";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import { VisualFormattingSettingsModel } from "./settings";
import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import FormattingModel = powerbi.visuals.FormattingModel;

type Option = {
    label: string;
    raw: powerbi.PrimitiveValue;
    rawText: string;
};

type FilterField = {
    key: string;
    title: string;
    tableName: string;
    columnName: string;
    options: Option[];
    isHour: boolean;
};

/** Valores conocidos del dominio Divvy -> etiqueta en español. */
const VALUE_MAP: Record<string, string> = {
    "Member": "Miembro",
    "Casual": "Casual",
    "Electric Bike": "Eléctrica",
    "Classic Bike": "Clásica",
    "Docked Bike": "Con anclaje",
    "Electric Scooter": "Scooter",
    "Mon": "Lun", "Tue": "Mar", "Wed": "Mié", "Thu": "Jue",
    "Fri": "Vie", "Sat": "Sáb", "Sun": "Dom",
    "Jan": "Ene", "Feb": "Feb", "Mar": "Mar", "Apr": "Abr",
    "May": "May", "Jun": "Jun", "Jul": "Jul", "Aug": "Ago",
    "Sep": "Sep", "Oct": "Oct", "Nov": "Nov", "Dec": "Dic",
};

/** Títulos técnicos -> títulos legibles. */
const TITLE_MAP: Record<string, string> = {
    "MemberType": "Tipo de usuario",
    "RideableType": "Tipo de bici",
    "Era": "Periodo",
    "Day Name": "Día",
    "Month": "Mes",
    "Month Year": "Mes/Año",
    "Year": "Año",
    "Is Weekend": "Semana",
    "Date": "Fecha",
    "StartHour": "Hora de inicio",
    "EndHour": "Hora de fin",
    "StartStationName": "Estación de inicio",
    "EndStationName": "Estación de fin",
    "StationName": "Estación",
    "BinLabel": "Duración",
    "DurationMin": "Duración (min)",
    "DistanceKm": "Distancia (km)",
    "FlowStatus": "Estado de flujo",
};

const DAY_ORDER = ["mon", "tue", "wed", "thu", "fri", "sat", "sun",
                   "lun", "mar", "mie", "jue", "vie", "sab", "dom"];
const MONTH_ORDER = ["jan", "feb", "mar", "apr", "may", "jun",
                     "jul", "aug", "sep", "oct", "nov", "dec",
                     "ene", "feb", "mar", "abr", "may", "jun",
                     "jul", "ago", "sep", "oct", "nov", "dic"];

export class Visual implements IVisual {
    private target: HTMLElement;
    private host: powerbi.extensibility.visual.IVisualHost;
    private fields: FilterField[] = [];
    private selectedByField = new Map<string, Set<string>>();
    private openFieldKey: string | null = null;
    private searchTerm = "";
    private restored = false;
    private formattingSettingsService: FormattingSettingsService;
    private formattingSettings: VisualFormattingSettingsModel;

    constructor(options: VisualConstructorOptions) {
        this.target = options.element;
        this.host = options.host;
        this.formattingSettingsService = new FormattingSettingsService();
        this.formattingSettings = new VisualFormattingSettingsModel();

        // Cerrar el desplegable al hacer clic fuera de él.
        document.addEventListener("mousedown", (ev: MouseEvent) => {
            if (this.openFieldKey === null) return;
            const node = ev.target as HTMLElement;
            if (node && node.closest && node.closest(".dvf-item")) return;
            this.openFieldKey = null;
            this.searchTerm = "";
            this.render();
        });
    }

    public update(options: VisualUpdateOptions): void {
        const dataView = options.dataViews?.[0];
        this.formattingSettings = this.formattingSettingsService.populateFormattingSettingsModel(
            VisualFormattingSettingsModel, dataView);

        this.applyTheme();

        const categories = dataView?.categorical?.categories;
        if (!categories?.length) {
            const empty = this.el("div", "dvf-empty",
                "Arrastra una o varias columnas al campo «Campos de filtro»");
            this.target.replaceChildren(empty);
            return;
        }

        this.fields = categories.map(c => this.buildField(c));

        // Restaurar selección desde los filtros ya guardados en el reporte.
        if (!this.restored) {
            this.restoreFromReport(options);
            this.restored = true;
        }

        // Descartar selecciones que ya no existen tras un refresco.
        this.selectedByField.forEach((set, key) => {
            const field = this.fields.find(f => f.key === key);
            if (!field) { this.selectedByField.delete(key); return; }
            const labels = new Set(field.options.map(o => o.label));
            [...set].forEach(v => { if (!labels.has(v)) set.delete(v); });
            if (set.size === 0) this.selectedByField.delete(key);
        });

        this.render();
    }

    public getFormattingModel(): FormattingModel {
        return this.formattingSettingsService.buildFormattingModel(this.formattingSettings);
    }

    // ---------------------------------------------------------------- datos

    private buildField(category: powerbi.DataViewCategoryColumn): FilterField {
        const queryName = category.source.queryName ?? category.source.displayName;
        const { tableName, columnName } = this.parseQueryName(queryName);
        const rawTitle = category.source.displayName ?? columnName ?? "Filtro";
        const isHour = /hour|hora/i.test(columnName || rawTitle);

        const seen = new Set<string>();
        const options: Option[] = [];
        category.values.forEach(v => {
            const rawText = this.toText(v);
            if (seen.has(rawText)) return;
            seen.add(rawText);
            options.push({ label: this.labelFor(rawText, isHour), raw: v, rawText });
        });

        this.sortOptions(options);

        return {
            key: queryName,
            title: this.titleFor(rawTitle),
            tableName,
            columnName,
            options,
            isHour,
        };
    }

    private labelFor(rawText: string, isHour: boolean): string {
        if (rawText === "") return "(Vacío)";
        const s = this.formattingSettings.labelsCard;

        if (isHour && s.hourFormat.value) {
            const n = Number(rawText);
            if (Number.isInteger(n) && n >= 0 && n <= 23) {
                return (n < 10 ? "0" + n : String(n)) + ":00";
            }
        }
        if (s.normalizeValues.value) {
            const hit = VALUE_MAP[rawText.trim()];
            if (hit) return hit;
        }
        return rawText;
    }

    private titleFor(rawTitle: string): string {
        if (!this.formattingSettings.labelsCard.renameTitles.value) return rawTitle;
        return TITLE_MAP[rawTitle.trim()] ?? rawTitle;
    }

    /** Quita acentos y baja a minúsculas para comparar días/meses. */
    private fold(s: string): string {
        return s.toLowerCase()
            .replace(/[áàä]/g, "a").replace(/[éèë]/g, "e")
            .replace(/[íìï]/g, "i").replace(/[óòö]/g, "o")
            .replace(/[úùü]/g, "u").trim();
    }

    private indexIn(list: string[], value: string): number {
        const f = this.fold(value).slice(0, 3);
        const i = list.indexOf(f);
        return i < 0 ? -1 : i % (list.length / 2);
    }

    private sortOptions(options: Option[]): void {
        const mode = this.formattingSettings.sortingCard.sortMode.value.value as string;
        if (mode === "model") return;

        const byLabel = (a: Option, b: Option) => a.label.localeCompare(b.label, "es");
        if (mode === "alpha") { options.sort(byLabel); return; }

        const texts = options.map(o => o.rawText);
        const allIn = (list: string[]) => texts.every(t => this.indexIn(list, t) >= 0);

        // 1) días de la semana  2) meses
        if (texts.length > 1 && allIn(DAY_ORDER)) {
            options.sort((a, b) => this.indexIn(DAY_ORDER, a.rawText) - this.indexIn(DAY_ORDER, b.rawText));
            return;
        }
        if (texts.length > 1 && allIn(MONTH_ORDER)) {
            options.sort((a, b) => this.indexIn(MONTH_ORDER, a.rawText) - this.indexIn(MONTH_ORDER, b.rawText));
            return;
        }
        // 3) numéricos puros (años, horas)
        if (texts.every(t => t !== "" && !isNaN(Number(t)))) {
            options.sort((a, b) => Number(a.rawText) - Number(b.rawText));
            return;
        }
        // 4) que empiezan con número (rangos: "0-5", "10-15", "60+")
        const lead = (t: string) => { const m = /^-?\d+/.exec(t.trim()); return m ? Number(m[0]) : NaN; };
        if (texts.every(t => !isNaN(lead(t)))) {
            options.sort((a, b) => lead(a.rawText) - lead(b.rawText) || byLabel(a, b));
            return;
        }
        // 5) alfabético con reglas del español
        options.sort(byLabel);
    }

    /** Reconstruye la selección a partir de los filtros persistidos del reporte. */
    private restoreFromReport(options: VisualUpdateOptions): void {
        try {
            const raw = (options as unknown as { jsonFilters?: unknown[] }).jsonFilters;
            if (!Array.isArray(raw)) return;

            raw.forEach(f => {
                const flt = f as { target?: { table?: string; column?: string }; values?: unknown[] };
                const t = flt?.target;
                if (!t?.table || !t?.column || !Array.isArray(flt.values)) return;

                const field = this.fields.find(x => x.tableName === t.table && x.columnName === t.column);
                if (!field) return;

                const set = new Set<string>();
                flt.values.forEach(v => {
                    const txt = this.toText(v as powerbi.PrimitiveValue);
                    const opt = field.options.find(o => o.rawText === txt);
                    if (opt) set.add(opt.label);
                });
                if (set.size) this.selectedByField.set(field.key, set);
            });
        } catch {
            /* si el formato no es el esperado, simplemente no restauramos */
        }
    }

    // ---------------------------------------------------------------- pintado

    private applyTheme(): void {
        const a = this.formattingSettings.appearanceCard;
        const accent = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(a.accent.value.value)
            ? a.accent.value.value : "#0C8599";
        this.target.style.setProperty("--dvf-accent", accent);
        this.target.style.setProperty("--dvf-accent-dark", this.shade(accent, -0.18));
        this.target.style.setProperty("--dvf-accent-soft", this.tint(accent, 0.9));
        this.target.style.setProperty("--dvf-accent-line", this.tint(accent, 0.65));
    }

    private render(): void {
        const a = this.formattingSettings.appearanceCard;
        const root = this.el("div", "dvf-root");
        root.dataset.density = String(a.density.value.value);

        const bar = this.el("div", "dvf-bar");

        this.fields.forEach(field => {
            const item = this.el("div", "dvf-item");
            const selected = this.selectedByField.get(field.key);
            const isOpen = this.openFieldKey === field.key;

            item.appendChild(this.buildPill(field, selected, isOpen));
            if (isOpen) item.appendChild(this.buildPanel(field, selected));
            bar.appendChild(item);
        });

        const activeCount = [...this.selectedByField.values()].filter(s => s.size > 0).length;
        if (a.showClearAll.value && activeCount > 0) {
            const clear = this.el("button", "dvf-clearall");
            clear.textContent = "Limpiar todo";
            const badge = this.el("span", "dvf-clearall__badge", String(activeCount));
            clear.appendChild(badge);
            clear.addEventListener("click", () => {
                this.selectedByField.clear();
                this.openFieldKey = null;
                this.applyFilters();
                this.render();
            });
            bar.appendChild(clear);
        }

        root.appendChild(bar);
        this.target.replaceChildren(root);
    }

    private buildPill(field: FilterField, selected: Set<string> | undefined, isOpen: boolean): HTMLElement {
        const n = selected?.size ?? 0;
        const pill = this.el("button", "dvf-pill");
        if (n > 0) pill.classList.add("is-active");
        if (isOpen) pill.classList.add("is-open");

        pill.appendChild(this.el("span", "dvf-pill__label", field.title));
        pill.appendChild(this.el("span", "dvf-pill__sep"));

        let summary = "Todos";
        if (n === 1) summary = [...selected!][0];
        else if (n > 1) summary = n + " seleccionados";
        pill.appendChild(this.el("span", "dvf-pill__value", summary));

        const chev = this.el("span", "dvf-pill__chev");
        chev.textContent = isOpen ? "▴" : "▾";
        pill.appendChild(chev);

        // IMPORTANTE: nada de stopPropagation aquí. El clic debe seguir subiendo
        // hasta el host de Power BI: si se detiene, Power BI no registra la
        // interacción, no selecciona el visual y por tanto no lo eleva sobre los
        // demás — el desplegable quedaría por detrás de las otras visualizaciones.
        pill.addEventListener("click", ev => {
            const onClear = (ev.target as HTMLElement)?.closest?.(".dvf-pill__clear");
            if (onClear) {
                this.selectedByField.delete(field.key);
                this.applyFilters();
                this.render();
                return;
            }
            this.openFieldKey = isOpen ? null : field.key;
            this.searchTerm = "";
            this.render();
        });

        if (n > 0) {
            const x = this.el("span", "dvf-pill__clear", "×");
            x.title = "Quitar este filtro";
            pill.appendChild(x);
        }

        return pill;
    }

    private buildPanel(field: FilterField, selected: Set<string> | undefined): HTMLElement {
        const a = this.formattingSettings.appearanceCard;
        const panel = this.el("div", "dvf-panel");

        // encabezado
        const head = this.el("div", "dvf-panel__head");
        const title = field.title + (a.showCounts.value ? "  (" + field.options.length + ")" : "");
        head.appendChild(this.el("span", "dvf-panel__title", title));

        const actions = this.el("div", "dvf-panel__actions");
        const all = this.el("button", "dvf-link", "Todos");
        all.addEventListener("click", () => {
            this.selectedByField.delete(field.key);
            this.applyFilters();
            this.render();
        });
        actions.appendChild(all);
        head.appendChild(actions);
        panel.appendChild(head);

        // buscador para listas largas
        const useSearch = field.options.length > 8;
        if (useSearch) {
            const wrap = this.el("div", "dvf-search");
            const input = document.createElement("input");
            input.type = "text";
            input.placeholder = "Buscar…";
            input.value = this.searchTerm;
            input.addEventListener("input", () => {
                this.searchTerm = input.value;
                this.filterNodes(panel);
            });
            wrap.appendChild(input);
            panel.appendChild(wrap);
            setTimeout(() => input.focus(), 0);
        }

        // rejilla de chips para valores cortos; lista con check para el resto
        const maxLen = field.options.reduce((m, o) => Math.max(m, o.label.length), 0);
        const asChips = maxLen <= 12 && field.options.length <= 32;
        const box = this.el("div", asChips ? "dvf-chips" : "dvf-list");

        field.options.forEach(opt => {
            const on = selected?.has(opt.label) ?? false;
            const node = this.el("button", asChips ? "dvf-chip" : "dvf-row");
            if (on) node.classList.add("is-on");
            node.dataset.label = opt.label.toLowerCase();

            if (!asChips) {
                const mark = this.el("span", "dvf-check");
                mark.textContent = on ? "✓" : "";
                node.appendChild(mark);
            }
            node.appendChild(this.el("span", "dvf-opt__text", opt.label));

            node.addEventListener("click", () => {
                const set = this.selectedByField.get(field.key) ?? new Set<string>();
                if (set.has(opt.label)) set.delete(opt.label); else set.add(opt.label);
                if (set.size === 0) this.selectedByField.delete(field.key);
                else this.selectedByField.set(field.key, set);
                this.applyFilters();
                this.render();
                this.openFieldKey = field.key;   // el panel sigue abierto
            });

            box.appendChild(node);
        });

        panel.appendChild(box);

        // pie
        const foot = this.el("div", "dvf-panel__foot");
        const n = selected?.size ?? 0;
        foot.appendChild(this.el("span", "dvf-panel__count",
            n === 0 ? "Sin filtro" : n + " de " + field.options.length));
        const close = this.el("button", "dvf-btn", "Cerrar");
        close.addEventListener("click", () => { this.openFieldKey = null; this.render(); });
        foot.appendChild(close);
        panel.appendChild(foot);

        return panel;
    }

    /** Filtra las opciones visibles sin repintar (conserva el foco del buscador). */
    private filterNodes(panel: HTMLElement): void {
        const term = this.searchTerm.toLowerCase().trim();
        const nodes = panel.querySelectorAll<HTMLElement>("[data-label]");
        nodes.forEach(n => {
            const hit = term === "" || (n.dataset.label ?? "").indexOf(term) >= 0;
            n.style.display = hit ? "" : "none";
        });
    }

    // ---------------------------------------------------------------- filtro

    private applyFilters(): void {
        const filters = this.fields
            .map(field => {
                const set = this.selectedByField.get(field.key);
                if (!set || set.size === 0 || !field.tableName || !field.columnName) return null;

                const values = field.options
                    .filter(o => set.has(o.label))
                    .map(o => o.raw)
                    .filter(v => v !== undefined);
                if (values.length === 0) return null;

                return {
                    $schema: "https://powerbi.com/product/schema#basic",
                    target: { table: field.tableName, column: field.columnName },
                    operator: "In",
                    values: values,
                    filterType: 1,
                };
            })
            .filter(f => f !== null);

        if (filters.length === 0) {
            this.host.applyJsonFilter(
                null as unknown as powerbi.IFilter, "general", "filter", powerbi.FilterAction.remove);
            return;
        }

        this.host.applyJsonFilter(
            filters as unknown as powerbi.IFilter, "general", "filter", powerbi.FilterAction.merge);
    }

    // ---------------------------------------------------------------- utilidades

    private el<K extends keyof HTMLElementTagNameMap>(
        tag: K, className = "", text = ""): HTMLElementTagNameMap[K] {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text) node.textContent = text;
        if (tag === "button") (node as HTMLButtonElement).type = "button";
        return node;
    }

    private toText(value: powerbi.PrimitiveValue): string {
        if (value === null || value === undefined) return "";
        return String(value);
    }

    private parseQueryName(queryName: string): { tableName: string; columnName: string } {
        const i = queryName.lastIndexOf(".");
        if (i <= 0 || i >= queryName.length - 1) return { tableName: "", columnName: "" };
        return { tableName: queryName.slice(0, i), columnName: queryName.slice(i + 1) };
    }

    private hexToRgb(hex: string): [number, number, number] {
        const h = hex.replace("#", "");
        const full = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
        const n = parseInt(full, 16);
        return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    }

    private rgbToHex(r: number, g: number, b: number): string {
        const c = (v: number) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0");
        return "#" + c(r) + c(g) + c(b);
    }

    private shade(hex: string, amt: number): string {
        const [r, g, b] = this.hexToRgb(hex);
        const f = 1 + amt;
        return this.rgbToHex(r * f, g * f, b * f);
    }

    private tint(hex: string, ratio: number): string {
        const [r, g, b] = this.hexToRgb(hex);
        return this.rgbToHex(r + (255 - r) * ratio, g + (255 - g) * ratio, b + (255 - b) * ratio);
    }
}
