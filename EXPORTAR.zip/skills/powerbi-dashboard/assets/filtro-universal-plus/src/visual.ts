"use strict";

import powerbi from "powerbi-visuals-api";
import "./../style/visual.less";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import { VisualFormattingSettingsModel } from "./settings";
import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import FormattingModel = powerbi.visuals.FormattingModel;

type FilterField = {
    key: string;
    title: string;
    tableName: string;
    columnName: string;
    labels: string[];
    valueByLabel: Map<string, powerbi.PrimitiveValue>;
};

const MONTHS = [
    ["enero", "ene", "january", "jan"], ["febrero", "feb", "february"], ["marzo", "mar", "march"],
    ["abril", "abr", "april", "apr"], ["mayo", "may"], ["junio", "jun", "june"],
    ["julio", "jul", "july"], ["agosto", "ago", "august", "aug"], ["septiembre", "sep", "sept", "september", "setiembre"],
    ["octubre", "oct", "october"], ["noviembre", "nov", "november"], ["diciembre", "dic", "december", "dec"],
];
const DAYS = [
    ["lunes", "lun", "monday", "mon"], ["martes", "mar", "tuesday", "tue"], ["miercoles", "mie", "wednesday", "wed"],
    ["jueves", "jue", "thursday", "thu"], ["viernes", "vie", "friday", "fri"], ["sabado", "sab", "saturday", "sat"],
    ["domingo", "dom", "sunday", "sun"],
];

const plain = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").trim();
const indexIn = (table: string[][], s: string) => table.findIndex(names => names.includes(plain(s)));

export class Visual implements IVisual {
    private target: HTMLElement;
    private host: powerbi.extensibility.visual.IVisualHost;
    private fields: FilterField[] = [];
    private selectedByField = new Map<string, Set<string>>();
    private openKey: string | null = null;
    private moreOpen = false;
    private moreExpanded: string | null = null;
    private search = "";
    private viewport: powerbi.IViewport = { width: 0, height: 0 };
    private formattingSettingsService = new FormattingSettingsService();
    private settings = new VisualFormattingSettingsModel();

    constructor(options: VisualConstructorOptions) {
        this.target = options.element;
        this.host = options.host;

        // Un solo manejador de clics para todo el visual. Sin stopPropagation ni preventDefault:
        // Power BI necesita recibir el clic para seleccionar el visual.
        // Power BI recorta todo lo que sale del recuadro del visual: en una barra baja los desplegables
        // no se verían, así que sus opciones se muestran en la misma fila (ver renderInline).
        this.target.addEventListener("click", (ev: MouseEvent) => this.onClick(ev));
        this.target.addEventListener("input", (ev: Event) => this.onSearch(ev));

        // Cerrar los desplegables al hacer clic fuera de ellos.
        document.addEventListener("mousedown", (ev: MouseEvent) => {
            if (this.openKey === null && !this.moreOpen) return;
            const node = ev.target as HTMLElement;
            if (node?.closest?.(".fu-item")) return;
            this.openKey = null;
            this.moreOpen = false;
            this.search = "";
            this.render();
        });
    }

    public update(options: VisualUpdateOptions): void {
        const dataView = options.dataViews?.[0];
        this.viewport = options.viewport;
        this.settings = this.formattingSettingsService.populateFormattingSettingsModel(VisualFormattingSettingsModel, dataView);

        const categories = dataView?.categorical?.categories;
        if (!categories?.length) {
            const empty = this.el("div", "fu-empty", "Arrastra una o varias columnas (Año, Mes, Sucursal…) al campo «Campos»");
            this.target.replaceChildren(empty);
            return;
        }

        this.fields = categories.map(c => this.buildField(c));
        this.syncFromReport(options);
        this.render();
    }

    public getFormattingModel(): FormattingModel {
        return this.formattingSettingsService.buildFormattingModel(this.settings);
    }

    // ---------------------------------------------------------------- datos

    private buildField(category: powerbi.DataViewCategoryColumn): FilterField {
        const queryName = category.source.queryName ?? category.source.displayName;
        const { tableName, columnName } = this.parseQueryName(queryName);
        let title = category.source.displayName ?? "Filtro";
        if (title.startsWith("#")) title = title.slice(1);

        const valueByLabel = new Map<string, powerbi.PrimitiveValue>();
        category.values.forEach(v => {
            if (v === null || v === undefined) return;
            const label = String(v);
            if (label !== "" && !valueByLabel.has(label)) valueByLabel.set(label, v);
        });

        return { key: queryName, title, tableName, columnName, labels: this.sortLabels([...valueByLabel.keys()], title), valueByLabel };
    }

    /** Orden inteligente: meses y días en su orden, años según «Comportamiento → Años» (de mayor a menor por defecto),
     *  otros números de menor a mayor y el resto alfabético. */
    private sortLabels(labels: string[], title: string): string[] {
        const t = plain(title);
        if ((t.includes("mes") || t.includes("month")) && labels.every(l => indexIn(MONTHS, l) >= 0)) {
            return labels.sort((a, b) => indexIn(MONTHS, a) - indexIn(MONTHS, b));
        }
        if (labels.length > 0 && labels.every(l => indexIn(DAYS, l) >= 0)) {
            return labels.sort((a, b) => indexIn(DAYS, a) - indexIn(DAYS, b));
        }
        if (labels.every(l => l.trim() !== "" && !isNaN(Number(l)))) {
            const esAnio = /^(ano|anio|year|ejercicio)/.test(t) || labels.every(l => /^(19|20)\d\d$/.test(l.trim()));
            const desc = esAnio && String(this.settings?.comportamiento?.yearOrder?.value?.value ?? "desc") !== "asc";
            return labels.sort((a, b) => desc ? Number(b) - Number(a) : Number(a) - Number(b));
        }
        return labels.sort((a, b) => a.localeCompare(b, "es", { numeric: true, sensitivity: "base" }));
    }

    /** La selección vive en los filtros del reporte: así sobrevive al guardar, a los marcadores y a «Restablecer». */
    private syncFromReport(options: VisualUpdateOptions): void {
        const raw = (options as unknown as { jsonFilters?: unknown[] }).jsonFilters;
        if (!Array.isArray(raw)) return;
        const next = new Map<string, Set<string>>();
        raw.forEach(f => {
            const flt = f as { target?: { table?: string; column?: string }; values?: unknown[] };
            const t = flt?.target;
            if (!t?.table || !t?.column || !Array.isArray(flt.values)) return;
            const field = this.fields.find(x => x.tableName === t.table && x.columnName === t.column);
            if (!field) return;
            const set = new Set<string>();
            flt.values.forEach(v => { const label = String(v); if (field.valueByLabel.has(label)) set.add(label); });
            if (set.size) next.set(field.key, set);
        });
        this.selectedByField = next;
    }

    private applyFilters(): void {
        const filters = this.fields.map(field => {
            const set = this.selectedByField.get(field.key);
            if (!set?.size || !field.tableName || !field.columnName) return null;
            const values = [...set].map(l => field.valueByLabel.get(l)).filter(v => v !== undefined);
            if (!values.length) return null;
            return {
                $schema: "https://powerbi.com/product/schema#basic",
                target: { table: field.tableName, column: field.columnName },
                operator: "In",
                values,
                filterType: 1,
            };
        }).filter(f => f !== null);

        if (!filters.length) {
            this.host.applyJsonFilter(null as unknown as powerbi.IFilter, "general", "filter", powerbi.FilterAction.remove);
        } else {
            this.host.applyJsonFilter(filters as unknown as powerbi.IFilter, "general", "filter", powerbi.FilterAction.merge);
        }
    }

    // ---------------------------------------------------------------- pintado

    private applyStyle(root: HTMLElement): void {
        const e = this.settings.estilo;
        const l = this.settings.distribucion;
        const color = (v: string, def: string) => /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v) ? v : def;
        const accent = color(e.accentColor.value.value, "#334155");
        const font = Math.max(8, Math.min(40, Number(e.fontSize.value) || 12));
        const auto = Math.round(font * 2.4 + 6);
        const h = Number(e.controlHeight.value) > 0 ? Math.max(18, Number(e.controlHeight.value)) : auto;

        const s = root.style;
        s.setProperty("--fu-accent", accent);
        s.setProperty("--fu-accent-soft", this.tint(accent, 0.88));
        s.setProperty("--fu-accent-line", this.tint(accent, 0.6));
        s.setProperty("--fu-text", color(e.textColor.value.value, "#1e293b"));
        s.setProperty("--fu-bg", color(e.controlBackground.value.value, "#ffffff"));
        s.setProperty("--fu-font", font + "px");
        s.setProperty("--fu-h", h + "px");
        s.setProperty("--fu-radius", Math.max(0, Number(e.cornerRadius.value) || 0) + "px");
        s.setProperty("--fu-gap", Math.max(0, Number(e.gap.value) || 0) + "px");
        s.setProperty("--fu-justify", String(e.alignment.value?.value ?? "space-between"));
        s.setProperty("--fu-valign", String(l.verticalAlign.value?.value ?? "center"));

        root.dataset.variant = String(e.variant.value?.value ?? "outline");
        root.dataset.orientation = String(l.orientation.value?.value ?? "horizontal");
        root.dataset.stretch = l.stretch.value ? "true" : "false";
    }

    private render(): void {
        const root = this.el("div", "fu-root");
        this.applyStyle(root);

        const nav = this.fields.find(f => this.isNavField(f.title));
        if (nav) root.appendChild(this.renderTabs(nav));

        const rest = this.fields.filter(f => f !== nav);
        if (this.isInline() && (this.openKey !== null || this.moreOpen)) {
            root.appendChild(this.renderInline(rest));
            this.target.replaceChildren(root);
            return;
        }

        const bar = this.el("div", "fu-bar");
        const max = Number(this.settings.distribucion.maxVisible.value) || 0;
        const visible = max > 0 ? rest.slice(0, max) : rest;
        const hidden = max > 0 ? rest.slice(max) : [];

        visible.forEach(f => bar.appendChild(this.renderItem(f)));
        if (hidden.length) bar.appendChild(this.renderMore(hidden));
        if (this.settings.comportamiento.showClear.value && this.selectedByField.size > 0) {
            const clear = this.button("× Limpiar", "fu-clear", "clear-all");
            bar.appendChild(clear);
        }
        root.appendChild(bar);
        this.target.replaceChildren(root);
        this.placeDropdowns();

        const input = this.target.querySelector<HTMLInputElement>(".fu-search");
        if (input) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
    }

    private renderTabs(field: FilterField): HTMLElement {
        const tabs = this.el("div", "fu-tabs");
        const sel = this.selectedByField.get(field.key);
        const active = sel?.size ? [...sel][0] : field.labels[0];
        field.labels.forEach(label => {
            const b = this.button(label, label === active ? "fu-tab is-active" : "fu-tab", "tab");
            b.dataset.key = field.key;
            b.dataset.label = label;
            tabs.appendChild(b);
        });
        return tabs;
    }

    private renderItem(field: FilterField): HTMLElement {
        const item = this.el("div", "fu-item");
        const sel = this.selectedByField.get(field.key);
        const n = sel?.size ?? 0;
        const open = this.openKey === field.key;

        const btn = this.button("", "fu-btn" + (n ? " has-selection" : "") + (open ? " is-open" : ""), "toggle");
        btn.dataset.key = field.key;
        btn.title = field.title;
        const value = n === 0 ? "Todos" : n === 1 ? [...(sel as Set<string>)][0] : `${n} sel.`;
        if (this.settings.comportamiento.showFieldName.value) {
            btn.appendChild(this.el("span", "fu-btn__name", n ? field.title + ":" : field.title));
            if (n) btn.appendChild(this.el("span", "fu-btn__value", value));
        } else {
            btn.appendChild(this.el("span", "fu-btn__value", n ? value : field.title));
        }
        btn.appendChild(this.el("span", "fu-btn__caret", "▾"));
        item.appendChild(btn);

        if (open) item.appendChild(this.renderDropdown(field, sel));
        return item;
    }

    private renderDropdown(field: FilterField, sel: Set<string> | undefined): HTMLElement {
        const drop = this.el("div", "fu-drop");
        drop.appendChild(this.el("div", "fu-drop__title", field.title));

        const threshold = Number(this.settings.comportamiento.searchThreshold.value) || 0;
        if (threshold > 0 && field.labels.length >= threshold) {
            const input = document.createElement("input");
            input.className = "fu-search";
            input.type = "search";
            input.placeholder = "Buscar…";
            input.value = this.search;
            drop.appendChild(input);
        }

        const list = this.el("div", "fu-drop__list");
        const all = this.button("Todos", "fu-opt fu-opt--all" + (sel?.size ? "" : " is-selected"), "all");
        all.dataset.key = field.key;
        list.appendChild(all);
        const term = plain(this.search);
        field.labels.forEach(label => {
            const opt = this.button("", "fu-opt" + (sel?.has(label) ? " is-selected" : ""), "opt");
            opt.dataset.key = field.key;
            opt.dataset.label = label;
            opt.appendChild(this.el("span", "fu-check"));
            opt.appendChild(this.el("span", "fu-opt__text", label));
            if (term && !plain(label).includes(term)) opt.hidden = true;
            list.appendChild(opt);
        });
        drop.appendChild(list);
        return drop;
    }

    private renderMore(fields: FilterField[]): HTMLElement {
        const item = this.el("div", "fu-item fu-item--more");
        const count = fields.filter(f => this.selectedByField.get(f.key)?.size).length;
        const btn = this.button("", "fu-btn fu-btn--more" + (count ? " has-selection" : "") + (this.moreOpen ? " is-open" : ""), "more");
        btn.appendChild(this.el("span", "fu-btn__value", count ? `+ Más filtros (${count})` : "+ Más filtros"));
        btn.appendChild(this.el("span", "fu-btn__caret", "▾"));
        item.appendChild(btn);
        if (!this.moreOpen) return item;

        const panel = this.el("div", "fu-drop fu-drop--more");
        panel.appendChild(this.el("div", "fu-drop__title", "Filtros adicionales"));
        const list = this.el("div", "fu-drop__list");
        fields.forEach(field => {
            const sel = this.selectedByField.get(field.key);
            const expanded = this.moreExpanded === field.key;
            const row = this.button("", "fu-more-row" + (sel?.size ? " has-selection" : ""), "more-field");
            row.dataset.key = field.key;
            row.appendChild(this.el("span", "", field.title + (sel?.size ? ` (${sel.size})` : "")));
            row.appendChild(this.el("span", "", expanded ? "−" : "+"));
            list.appendChild(row);
            if (!expanded) return;
            const chips = this.el("div", "fu-chips");
            const all = this.button("Todos", "fu-chip" + (sel?.size ? "" : " is-selected"), "all");
            all.dataset.key = field.key;
            chips.appendChild(all);
            field.labels.forEach(label => {
                const chip = this.button(label, "fu-chip" + (sel?.has(label) ? " is-selected" : ""), "opt");
                chip.dataset.key = field.key;
                chip.dataset.label = label;
                chips.appendChild(chip);
            });
            list.appendChild(chips);
        });
        panel.appendChild(list);
        item.appendChild(panel);
        return item;
    }

    /** Barra baja y horizontal: un desplegable quedaría recortado por el recuadro del visual. */
    private isInline(): boolean {
        const h = this.viewport.height || this.target.clientHeight;
        return String(this.settings.distribucion.orientation.value?.value ?? "horizontal") !== "vertical" && h > 0 && h < 240;
    }

    /** Las opciones del campo abierto (o los campos de «+ Más filtros») en la misma fila de la barra. */
    private renderInline(rest: FilterField[]): HTMLElement {
        const row = this.el("div", "fu-item fu-inline");
        const opts = this.el("div", "fu-inline__opts");
        const field = rest.find(f => f.key === this.openKey);

        if (field) {
            const sel = this.selectedByField.get(field.key);
            row.appendChild(this.button("‹ " + field.title, "fu-btn is-open fu-inline__back", "close"));
            const all = this.button("Todos", "fu-chip" + (sel?.size ? "" : " is-selected"), "all");
            all.dataset.key = field.key;
            opts.appendChild(all);
            field.labels.forEach(label => {
                const chip = this.button(label, "fu-chip" + (sel?.has(label) ? " is-selected" : ""), "opt");
                chip.dataset.key = field.key;
                chip.dataset.label = label;
                opts.appendChild(chip);
            });
        } else {
            const max = Number(this.settings.distribucion.maxVisible.value) || 0;
            row.appendChild(this.button("‹ Más filtros", "fu-btn is-open fu-inline__back", "close"));
            rest.slice(max).forEach(f => {
                const n = this.selectedByField.get(f.key)?.size ?? 0;
                const chip = this.button(f.title + (n ? ` (${n})` : ""), "fu-chip" + (n ? " is-selected" : ""), "toggle");
                chip.dataset.key = f.key;
                opts.appendChild(chip);
            });
        }
        row.appendChild(opts);
        row.appendChild(this.button("Listo", "fu-btn fu-inline__done", "close"));
        return row;
    }

    /** Si un desplegable no cabe a la derecha, se abre hacia la izquierda. */
    private placeDropdowns(): void {
        const width = this.viewport.width || this.target.clientWidth;
        this.target.querySelectorAll<HTMLElement>(".fu-drop").forEach(drop => {
            const item = drop.parentElement as HTMLElement;
            const left = item.getBoundingClientRect().left - this.target.getBoundingClientRect().left;
            if (left + Math.max(drop.offsetWidth, 220) > width) drop.classList.add("is-right");
        });
    }

    // ---------------------------------------------------------------- eventos

    private onClick(ev: MouseEvent): void {
        const node = (ev.target as HTMLElement)?.closest?.("[data-action]") as HTMLElement | null;
        if (!node) return;
        const key = node.dataset.key ?? "";
        const label = node.dataset.label ?? "";
        const multi = !!this.settings.comportamiento.multiSelect.value;

        switch (node.dataset.action) {
            case "toggle":
                this.openKey = this.openKey === key ? null : key;
                this.moreOpen = false;
                this.search = "";
                break;
            case "more":
                this.moreOpen = !this.moreOpen;
                this.openKey = null;
                break;
            case "close":
                this.openKey = null;
                this.moreOpen = false;
                this.search = "";
                break;
            case "more-field":
                this.moreExpanded = this.moreExpanded === key ? null : key;
                break;
            case "all":
                this.selectedByField.delete(key);
                if (!multi) this.openKey = null;
                this.applyFilters();
                break;
            case "opt": {
                const set = multi ? (this.selectedByField.get(key) ?? new Set<string>()) : new Set<string>();
                if (multi && set.has(label)) set.delete(label); else set.add(label);
                if (set.size) this.selectedByField.set(key, set); else this.selectedByField.delete(key);
                if (!multi) { this.openKey = null; this.search = ""; }
                this.applyFilters();
                break;
            }
            case "tab":
                this.selectedByField.set(key, new Set([label]));
                this.applyFilters();
                break;
            case "clear-all":
                this.selectedByField.clear();
                this.openKey = null;
                this.moreOpen = false;
                this.applyFilters();
                break;
            default:
                return;
        }
        this.render();
    }

    /** Filtra las opciones sin repintar, para no perder el foco del buscador. */
    private onSearch(ev: Event): void {
        const input = ev.target as HTMLInputElement;
        if (!input?.classList?.contains("fu-search")) return;
        this.search = input.value;
        const term = plain(this.search);
        input.closest(".fu-drop")?.querySelectorAll<HTMLElement>(".fu-opt:not(.fu-opt--all)").forEach(opt => {
            opt.hidden = !!term && !plain(opt.dataset.label ?? "").includes(term);
        });
    }

    // ---------------------------------------------------------------- utilidades

    private isNavField(title: string): boolean {
        const t = plain(title);
        return ["seccion", "menu", "pagina", "pestana", "nav", "tab"].some(w => t.includes(w));
    }

    private parseQueryName(queryName: string): { tableName: string; columnName: string } {
        const i = queryName.indexOf(".");
        if (i <= 0 || i >= queryName.length - 1) return { tableName: "", columnName: queryName };
        return { tableName: queryName.slice(0, i), columnName: queryName.slice(i + 1) };
    }

    private el<K extends keyof HTMLElementTagNameMap>(tag: K, className = "", text = ""): HTMLElementTagNameMap[K] {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text) node.textContent = text;
        return node;
    }

    private button(text: string, className: string, action: string): HTMLButtonElement {
        const b = this.el("button", className, text);
        b.type = "button";
        b.dataset.action = action;
        return b;
    }

    private tint(hex: string, ratio: number): string {
        const h = hex.replace("#", "");
        const full = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
        const n = parseInt(full, 16);
        const mix = (v: number) => Math.round(v + (255 - v) * ratio).toString(16).padStart(2, "0");
        return "#" + mix((n >> 16) & 255) + mix((n >> 8) & 255) + mix(n & 255);
    }
}
