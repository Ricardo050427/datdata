"use strict";

import powerbi from "powerbi-visuals-api";
import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";

import FormattingSettingsCard = formattingSettings.SimpleCard;
import FormattingSettingsSlice = formattingSettings.Slice;
import FormattingSettingsModel = formattingSettings.Model;

const rango = (min: number, max: number) => ({
    minValue: { type: powerbi.visuals.ValidatorType.Min as const, value: min },
    maxValue: { type: powerbi.visuals.ValidatorType.Max as const, value: max },
});

/** Los nombres de objeto y propiedad (visualStyles.fontSize, alignment, accentColor)
 *  coinciden con los que escribe hybrid.js de la Metodología 2. No cambiarlos. */
class EstiloCard extends FormattingSettingsCard {
    variant = new formattingSettings.ItemDropdown({
        name: "variant",
        displayName: "Estilo",
        items: [
            { value: "outline", displayName: "Contorno" },
            { value: "pills", displayName: "Píldoras" },
            { value: "soft", displayName: "Suave" },
            { value: "underline", displayName: "Subrayado" },
            { value: "segmented", displayName: "Segmentado" },
        ],
        value: { value: "outline", displayName: "Contorno" },
    });

    fontSize = new formattingSettings.NumUpDown({
        name: "fontSize",
        displayName: "Tamaño de letra",
        value: 12,
        options: rango(8, 40),
    });

    controlHeight = new formattingSettings.NumUpDown({
        name: "controlHeight",
        displayName: "Alto de los botones (0 = automático)",
        value: 0,
        options: rango(0, 120),
    });

    alignment = new formattingSettings.ItemDropdown({
        name: "alignment",
        displayName: "Alineación",
        items: [
            { value: "flex-start", displayName: "Izquierda" },
            { value: "center", displayName: "Centro" },
            { value: "flex-end", displayName: "Derecha" },
            { value: "space-between", displayName: "Repartida" },
        ],
        value: { value: "space-between", displayName: "Repartida" },
    });

    cornerRadius = new formattingSettings.NumUpDown({
        name: "cornerRadius",
        displayName: "Redondez de las esquinas",
        value: 8,
        options: rango(0, 40),
    });

    gap = new formattingSettings.NumUpDown({
        name: "gap",
        displayName: "Separación entre botones",
        value: 8,
        options: rango(0, 48),
    });

    accentColor = new formattingSettings.ColorPicker({
        name: "accentColor",
        displayName: "Color de acento",
        value: { value: "#334155" },
    });

    textColor = new formattingSettings.ColorPicker({
        name: "textColor",
        displayName: "Color del texto",
        value: { value: "#1e293b" },
    });

    controlBackground = new formattingSettings.ColorPicker({
        name: "controlBackground",
        displayName: "Fondo de los botones",
        value: { value: "#ffffff" },
    });

    name = "visualStyles";
    displayName = "Estilo, tamaño y colores";
    slices: Array<FormattingSettingsSlice> = [
        this.variant, this.fontSize, this.controlHeight, this.alignment,
        this.cornerRadius, this.gap, this.accentColor, this.textColor, this.controlBackground,
    ];
}

class DistribucionCard extends FormattingSettingsCard {
    orientation = new formattingSettings.ItemDropdown({
        name: "orientation",
        displayName: "Orientación",
        items: [
            { value: "horizontal", displayName: "Horizontal" },
            { value: "vertical", displayName: "Vertical" },
        ],
        value: { value: "horizontal", displayName: "Horizontal" },
    });

    verticalAlign = new formattingSettings.ItemDropdown({
        name: "verticalAlign",
        displayName: "Posición vertical",
        items: [
            { value: "center", displayName: "Centro" },
            { value: "flex-start", displayName: "Arriba" },
            { value: "flex-end", displayName: "Abajo" },
        ],
        value: { value: "center", displayName: "Centro" },
    });

    maxVisible = new formattingSettings.NumUpDown({
        name: "maxVisible",
        displayName: "Campos visibles antes de «+ Más filtros» (0 = todos)",
        value: 5,
        options: rango(0, 30),
    });

    stretch = new formattingSettings.ToggleSwitch({
        name: "stretch",
        displayName: "Botones del mismo ancho",
        value: false,
    });

    name = "layout";
    displayName = "Distribución";
    slices: Array<FormattingSettingsSlice> = [this.orientation, this.verticalAlign, this.maxVisible, this.stretch];
}

class ComportamientoCard extends FormattingSettingsCard {
    multiSelect = new formattingSettings.ToggleSwitch({
        name: "multiSelect",
        displayName: "Selección múltiple",
        value: true,
    });

    showFieldName = new formattingSettings.ToggleSwitch({
        name: "showFieldName",
        displayName: "Mostrar el nombre del campo",
        value: true,
    });

    showClear = new formattingSettings.ToggleSwitch({
        name: "showClear",
        displayName: "Botón «Limpiar»",
        value: true,
    });

    searchThreshold = new formattingSettings.NumUpDown({
        name: "searchThreshold",
        displayName: "Buscador a partir de N opciones (0 = nunca)",
        value: 8,
        options: rango(0, 500),
    });

    yearOrder = new formattingSettings.ItemDropdown({
        name: "yearOrder",
        displayName: "Años",
        items: [
            { value: "desc", displayName: "De mayor a menor" },
            { value: "asc", displayName: "De menor a mayor" },
        ],
        value: { value: "desc", displayName: "De mayor a menor" },
    });

    name = "behavior";
    displayName = "Comportamiento";
    slices: Array<FormattingSettingsSlice> = [this.multiSelect, this.showFieldName, this.showClear, this.searchThreshold, this.yearOrder];
}

export class VisualFormattingSettingsModel extends FormattingSettingsModel {
    estilo = new EstiloCard();
    distribucion = new DistribucionCard();
    comportamiento = new ComportamientoCard();

    cards = [this.estilo, this.distribucion, this.comportamiento];
}
