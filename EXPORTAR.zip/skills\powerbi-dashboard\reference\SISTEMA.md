# SISTEMA — referencia técnica del flujo híbrido

Patrones de los tres custom visuals y de las medidas DAX. El *procedimiento* está en `SKILL.md`;
los *errores conocidos* en `GOTCHAS.md`; la *configuración* en `PERSONALIZACION.md`.

---

## 1 · Arquitectura: dos capas

| Capa | Herramienta | Hace | Power BI |
|---|---|---|---|
| **Modelo semántico** | MCP `powerbi-modeling-mcp` (viene con el plugin de Fabric) | Tablas, medidas DAX, relaciones, refrescos | **Abierto** |
| **Visuales y layout** | Generador `hybrid.js` + 2 CLIs de Fabric | Escribir los visuales en la cuadrícula, validar, recargar, capturar | **Abierto** (se refresca con `reload`) |

Editar los visuales **no** exige cerrar Power BI: el generador escribe los archivos PBIR y
`powerbi-desktop reload --pid` refresca la ventana. (Excepción: agregar o quitar páginas — ver
GOTCHAS A2.)

**Piezas:**

| Pieza | Rol |
|---|---|
| Plugin `powerbi-authoring@fabric-collection` | Trae las skills `powerbi-report-planning/design/authoring` **y** el MCP de modelado (vía `npx`) |
| CLI `powerbi-report-author` | `validate`, `catalog describe` (roles), `formatting describe-object` |
| CLI `powerbi-desktop` | `status`, `reload --pid`, `screenshot` / `screenshot-all` |
| `hybrid.js` | Generador Node: fábricas + constructores Vega + geometría + paleta derivada |

Instalación (una vez):

```powershell
npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli
# en Claude Code:
/plugin marketplace add microsoft/skills-for-fabric
/plugin install powerbi-authoring@fabric-collection
```

**GUIDs de los custom visuals** (deben coincidir con `CFG.guids`):

- Deneb → `deneb7E15AEF80B9E4D4F8E12924291ECE89A` · rol `dataset`
- HTML Content → `htmlContent443BE3AD55E043BF878BED274D3A6855` · rol `content`
- Filtro → `filtroGeneralUniversal8A3E1F9C2B4D1E5F` · rol `fields`

Para leer el GUID de un `.pbiviz`: descomprimir → `resources/<guid>.pbiviz.json` → `capabilities`.

---

## 2 · Ciclo de trabajo

```powershell
# 1. Modelo y medidas — por MCP, conversacional, con PBI abierto
# 2. Visuales
node _gen/hybrid.js
powerbi-report-author validate "<ruta>\<Reporte>.Report"   # "Unknown visualType" = normal
powerbi-desktop status                                     # → PID
powerbi-desktop reload --pid <PID>
powerbi-desktop screenshot-all --pid <PID>                 # esperar ~3 s: render async
```

`validate` con **0 errores** = listo. Si trae errores, corregir `hybrid.js` y regenerar **antes**
de recargar.

---

## 3 · API del generador

### Fábricas de visual

| Fábrica | Produce |
|---|---|
| `htmlCard(entity, 'Medida HTML', cg(...))` | HTML Content — una medida DAX que devuelve HTML (§4) |
| `deneb([campos], spec, cg(...))` | Deneb con cross-filter incluido (§5) |
| `filtro([{entity,column}], box, opts)` | Barra de filtros (la arma `writePage` sola desde `page.filters`) |
| `azureMap(box, título, cat, lat, lng, size)` | Mapa geográfico — **el único visual nativo de datos** |

### Campos del dataset

```js
dC('dim_Producto', 'Categoria')      // columna
dM('fact_Ventas',  'Total Ventas')   // medida
```

### Constructores de spec

| Constructor | Para |
|---|---|
| `vBar(título, cat, val, color?)` | Barras horizontales ordenadas — rankings, nombres largos |
| `vColumn(título, cat, val, color?, tipo?, orden?)` | Columnas verticales — series cortas, horas, días |
| `vLine(título, x, val, tipoX, serie?, dominio?, rango?)` | Líneas, opcionalmente multi-serie |
| `vDonut(título, cat, val, dominio?, rango?)` | Dona — mix de 2-5 categorías |
| `vHist(título, campo, val, color?, bins?)` | Distribución de una columna numérica |
| `vHeatmap(título, x, ordenX, y, val, tituloY?)` | Mapa de calor — hora × día |
| `vTrend(título, subtítulo, fecha, val, unidad?)` | Tendencia con área degradada + pico y mínimo |

### Modificadores

```js
withTopN(spec, catF, valF, 10)   // excluye vacíos + deja el top 10 (DENTRO de la spec)
withFilter(spec, "datum.Tipo != 'Unknown'")
recolor(spec, '#E8590C')         // una gráfica de otro color, a propósito
```

**Regla de diseño no negociable:** KPIs y tarjetas → `htmlCard`; gráficas y tablas → `deneb`;
filtros → `filtro`. Los nativos solo para mapas geográficos y el navegador de páginas.

---

## 4 · HTML Content — orientación y tema

La medida DAX devuelve un string HTML completo; Power BI la evalúa en el contexto de filtro, así
que las tarjetas reaccionan a los slicers y al cross-filter de Deneb.

**Orientación = forma del contenedor.** Tira ancha y baja → grid de N columnas; riel alto y
angosto → grid de N filas.

**Tema = fondo de la página.** Página clara → tarjetas claras; oscura → oscuras. `CFG.theme` **no**
alcanza al HTML que vive dentro de las medidas: si cambias de tema hay que rehacer ese CSS.

Dimensionar con `vh`/`vw` y `clamp()`, nunca con `%` ni px fijos. Ver GOTCHAS §E para el patrón
completo y los mitos corregidos.

Plantillas de tarjeta, badge de delta, semáforo y tabla: skill `html-kpi-cards`.

---

## 5 · Deneb — estética + interactividad

`dataset` es la lista de campos que alimentan el visual (se referencian en la spec por su
`nativeQueryRef`). `vega` es la spec, que `hybrid.js` serializa dentro del `visual.json`.

**Interactividad — el patrón correcto:**

```js
// hover = marca bajo el cursor. SIN `fields`.
"params": [{"name":"hover","select":{"type":"point","on":"mouseover","clear":"mouseout"}}]
// color al hover
"color": {"condition":{"param":"hover","empty":false,"value":"<acento oscurecido>"},"value":"<acento>"}
// atenuar lo no seleccionado — el clic lo maneja Deneb NATIVAMENTE
"opacity": {"condition":{"test":"datum['__selected__'] == 'off'","value":0.3},"value":1}
```

⚠️ **No añadas un param de selección Vega.** El cross-filter a toda la página lo da
`usermeta.deneb.interactivity.selection: true` + el manejo nativo, expuesto como
`datum['__selected__']`. Un param `sel` propio entra en conflicto.

⚠️ **Deneb no acepta filtros de visual PBIR.** Todo el filtrado va dentro de la spec con
`transform` (`withTopN`, `withFilter`).

Plantillas por tipo de gráfica: skill `deneb-chart-generator`.

### 5.1 · Tooltip nativo — dos ajustes

1. **Que aparezca en toda la columna, no solo sobre el trazo:** `select` con
   `{"type":"point","nearest":true,"encodings":["x"],"on":"pointerover","clear":"pointerout"}`
   sobre la capa de puntos. ⚠️ `nearest` **sin** `encodings:["x"]` usa distancia 2D y engancha el
   punto en diagonal.
2. **Multi-serie:** `transform` `pivot` por la serie + `groupby` la categoría, para que una fila
   del tooltip muestre todas las series de esa categoría.

### 5.2 · Tooltip premium dibujado (Vega puro)

Cambiar `provider` a `'vega'` y dibujar la tarjeta como marcas. Vale la pena cuando se necesita:
(a) que una fila **desaparezca** si esa serie no tiene dato (Vega-Lite mostraría `NaN`); (b) un
punto de color por serie; (c) números redondeados; (d) que la tarjeta se voltee de lado.

Piezas: `rect` invisible por categoría (`name:"hoverBand"`) que recibe el `pointerover` — no el
trazo visible; señal `hoverKey` + tabla derivada `hovered` que alimenta un `mark:"group"`;
visibilidad por fila con `"opacity":{"signal":"parent.hN"}`; volteo con
`"x":{"signal":"cx + 16 + CARDW > width ? max(0, cx - 16 - CARDW) : cx + 16"}`; valores con
`format(v, ',.0f')`.

⚠️ `"interactive": false` en el grupo **y en cada marca hija**, o la tarjeta bloquea el mouse.

**Orden recomendado:** construir todo en Vega-Lite primero (valida rápido) y aplicar esto al final
como pasada de pulido, solo donde haga falta.

---

## 6 · Patrones de medida DAX

### Delta badge (cambio vs período anterior)

Badge verde ▲ / rojo ▼ con el % de cambio, que aparece solo si hay período comparable.

```css
.bu{font-weight:700;padding:2px 7px;border-radius:20px;background:#e6f9f0;color:#1a7a4a}
.bd{font-weight:700;padding:2px 7px;border-radius:20px;background:#fce8ec;color:#c0142d}
```

```dax
VAR _sel = SELECTEDVALUE(dim_Fecha[Mes Numero])
VAR _per = SUMMARIZE(fact_Ventas, dim_Fecha[Año], dim_Fecha[Mes Numero])
VAR _aY  = MAXX(_per, dim_Fecha[Año])
VAR _aM  = MAXX(FILTER(_per, dim_Fecha[Año] = _aY), dim_Fecha[Mes Numero])
VAR _m   = IF(ISBLANK(_sel), _aM, _sel)
VAR _y   = IF(ISBLANK(_sel), _aY, COALESCE(SELECTEDVALUE(dim_Fecha[Año]), _aY))
VAR _mp  = IF(_m > 1, _m - 1, 12)
VAR _yp  = IF(_m > 1, _y, _y - 1)
VAR _v   = CALCULATE([Total Ventas], dim_Fecha[Mes Numero] = _m,  dim_Fecha[Año] = _y)
VAR _vp  = CALCULATE([Total Ventas], dim_Fecha[Mes Numero] = _mp, dim_Fecha[Año] = _yp)
VAR _d   = DIVIDE(_v - _vp, _vp, 0)
VAR _b   = IF(ISBLANK(_vp), "",
             IF(_d >= 0, "<span class='bu'>&#9650; " & FORMAT(ABS(_d),"0.0%") & "</span>",
                         "<span class='bd'>&#9660; " & FORMAT(ABS(_d),"0.0%") & "</span>"))
```

Auto-detecta el último período con datos si no hay selección. Para métricas donde bajar es bueno,
invertir: `VAR _d = DIVIDE(_vp - _v, _vp, 0)`.

**Comparativo año anterior:** protégelo con un guard de comparabilidad (que el rango del año
anterior exista y esté completo), o el primer año del dataset muestra caídas del -100 %.

### Insight text dentro del Deneb

Una línea DAX que resume el estado ("[X] lidera con Y % del total…"), embebida como capa `text`.
Para que el texto sea igual en todas las filas del dataset, calcularlo con
`GROUPBY(CALCULATETABLE(Hecho, REMOVEFILTERS(Hecho[Dim])), ...)` y en Vega usar
`aggregate: "min"`. Requiere `usermeta.deneb.combination.type: "layer"`.

**Robustez:** los datos no se leen (solo el esquema). Escribe DAX a prueba de valores
inexistentes: `DIVIDE`, `COALESCE`, `ISBLANK`.

---

## 7 · Estética de negocio

- **Layout:** lo más importante arriba/izquierda; controles agrupados (el Filtro como una tira,
  nunca slicers dispersos); márgenes consistentes (la cuadrícula los garantiza).
- **Que no parezca "hecho por IA":** sin emojis; glifos funcionales sí (`&#9650;`/`&#9660;`, `•`);
  texto sobrio del dominio; **una sola paleta de acento**; Segoe UI; radios consistentes.
- **Navegación:** el `pageNavigator` nativo, no los tabs decorativos del Filtro.
- **Multipágina:** una entrada por página en `PAGES`, mismo estilo y paleta en todas, para que el
  reporte se sienta un solo producto. Cada página con su barra de Filtro y los campos relevantes.
