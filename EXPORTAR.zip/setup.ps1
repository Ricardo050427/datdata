﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Instalador automatico — Metodologia 2 (HIBRIDA)
    Skills de Fabric + generador Node (hybrid.js) + custom visuals propios
    (Deneb, HTML Content, Filtro) en vez de visuales nativos.

.DESCRIPTION
    Ejecuta este archivo desde la carpeta EXPORTAR\ con:
      PowerShell -ExecutionPolicy Bypass -File setup.ps1

    Este flujo corre sobre CLAUDE CODE (no Claude Desktop). El modelo se crea
    por el MCP de Power BI (que ahora VIENE DENTRO del plugin de skills de
    Fabric, via npx — ya no hace falta la extension de VS Code ni editar
    claude_desktop_config.json). Los visuales y el layout los arma el generador
    Node hybrid.js apoyado en las skills de Fabric (planning/design/authoring)
    y las 2 CLIs de Fabric (validate / reload / screenshot).

    Lo que AUTOMATIZA este script:
      [1] Verifica / instala Node.js (winget)         — hybrid.js + CLIs + MCP(npx)
      [2] Instala las 2 CLIs de Fabric (npm -g)        — powerbi-report-author / powerbi-desktop
      [3] Copia el motor hibrido a C:\Claude\pbi-motor (hybrid.js, SISTEMA.md, ejemplos)
      [4] Copia el visual Filtro (.pbiviz)
      [5] Registra el marketplace de skills de Fabric en Claude Code (settings.json)
          y copia las skills propias de patrones a %USERPROFILE%\.claude\skills
      [6] Resumen + pasos manuales restantes

    Lo que sigue siendo MANUAL (no se puede scriptar de forma fiable):
      - Instalar Power BI Desktop (y activar el formato PBIP)
      - Instalar Claude Code
      - Completar la instalacion del plugin de Fabric con /plugin install
        (el script ya deja el marketplace registrado)
      - Reiniciar Claude Code despues de este script
      - Importar Deneb, HTML Content y el Filtro en CADA reporte nuevo
      - Adaptar hybrid.js (ruta REPORT + specs de pagina) a cada dataset

    Ya NO se instala: Python, la extension MCP de VS Code, ni el motor .py.
#>

$ErrorActionPreference = "SilentlyContinue"
$motorDest = "C:\Claude\pbi-motor"
$here      = Split-Path -Parent $MyInvocation.MyCommand.Path

# -- Helpers de output ----------------------------------------------------------
function Write-Banner  { Write-Host ("`n" + "-"*62) -ForegroundColor DarkGray }
function Write-Step($n, $msg) { Write-Banner; Write-Host "  [$n/6] $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "        OK  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "        !   $msg" -ForegroundColor Yellow }
function Write-Fail($msg) { Write-Host "        X   $msg" -ForegroundColor Red }

Clear-Host
Write-Host ""
Write-Host "  ==========================================================" -ForegroundColor Magenta
Write-Host "    Datdata — Instalador Metodologia 2 (Hibrida)" -ForegroundColor Magenta
Write-Host "    Skills de Fabric + hybrid.js + custom visuals" -ForegroundColor Magenta
Write-Host "  ==========================================================" -ForegroundColor Magenta
Write-Host ""

# ==============================================================================
# PASO 1 — Node.js (base de todo el flujo hibrido)
# ==============================================================================
Write-Step 1 "Verificando Node.js..."

$nodeCmd = Get-Command "node" -ErrorAction SilentlyContinue
if ($nodeCmd) {
    $nodeVer = (& node --version) 2>$null
    Write-OK "Node.js ya instalado ($nodeVer)."
} else {
    Write-Warn "Node.js no encontrado. Intentando instalar con winget..."
    $wingetCmd = Get-Command "winget" -ErrorAction SilentlyContinue
    if ($wingetCmd) {
        winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements 2>&1 | Out-Null
        # Recargar PATH del proceso para ver node recien instalado
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
                    [System.Environment]::GetEnvironmentVariable("Path","User")
        $nodeCmd = Get-Command "node" -ErrorAction SilentlyContinue
        if ($nodeCmd) {
            Write-OK "Node.js instalado ($((& node --version) 2>$null))."
        } else {
            Write-Warn "Node quedo instalado pero no visible en esta sesion."
            Write-Warn "Cierra y reabre PowerShell y vuelve a ejecutar setup.ps1."
        }
    } else {
        Write-Fail "winget no disponible. Instala Node.js LTS manualmente desde nodejs.org"
        Write-Fail "y vuelve a ejecutar este script."
    }
}

# ==============================================================================
# PASO 2 — Las 2 CLIs de Fabric (validate / reload / screenshot)
# ==============================================================================
Write-Step 2 "Instalando las 2 CLIs de Fabric (npm global)..."

if (Get-Command "npm" -ErrorAction SilentlyContinue) {
    npm install -g "@microsoft/powerbi-report-authoring-cli" "@microsoft/powerbi-desktop-bridge-cli" 2>&1 | Out-Null
    $ra = Get-Command "powerbi-report-author" -ErrorAction SilentlyContinue
    $db = Get-Command "powerbi-desktop"       -ErrorAction SilentlyContinue
    if ($ra) { Write-OK "powerbi-report-author (validate / catalog / formatting)" }
    else     { Write-Warn "powerbi-report-author no visible aun (reinicia la terminal)." }
    if ($db) { Write-OK "powerbi-desktop (status / reload / screenshot)" }
    else     { Write-Warn "powerbi-desktop no visible aun (reinicia la terminal)." }
} else {
    Write-Warn "npm no disponible (Node no instalado). Se omite este paso."
    Write-Warn "Tras instalar Node, corre a mano:"
    Write-Warn "  npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli"
}

# ==============================================================================
# PASO 3 — Copiar el motor hibrido
# ==============================================================================
Write-Step 3 "Copiando el motor hibrido a $motorDest ..."

$motorSrc = Join-Path $here "motor"
if (-not (Test-Path $motorSrc)) {
    Write-Fail "No se encontro la carpeta 'motor\' junto a setup.ps1."
    Write-Fail "Asegurate de ejecutar el script desde la carpeta EXPORTAR\"
    Read-Host "Presiona Enter para salir"; exit 1
}

New-Item -ItemType Directory -Force $motorDest | Out-Null

# Solo los archivos que usa el flujo hibrido (el motor .py queda fuera).
$hybridFiles = @("hybrid.js", "SISTEMA.md", "filtros_test.json")
foreach ($f in $hybridFiles) {
    $srcF = Join-Path $motorSrc $f
    if (Test-Path $srcF) {
        Copy-Item $srcF $motorDest -Force
        Write-OK $f
    } else {
        Write-Warn "$f no encontrado en motor\ (se omite)."
    }
}

# Reemplazar la ruta hardcodeada del origen por la ruta estandar del reporte.
# (hybrid.js trae REPORT apuntando al proyecto Divvy de ejemplo — es solo la plantilla.)
$originMotor = "C:\Users\lanfa\.claude\code\primera sesion"
foreach ($fname in @("SISTEMA.md")) {
    $fp = Join-Path $motorDest $fname
    if (Test-Path $fp) {
        $content = Get-Content $fp -Raw
        $content = $content -replace [regex]::Escape($originMotor), $motorDest
        $content = $content -replace [regex]::Escape($originMotor.Replace("\","/")), $motorDest.Replace("\","/")
        Set-Content $fp $content -Encoding UTF8
        Write-OK "$fname (rutas actualizadas)"
    }
}

Write-Warn "hybrid.js es la PLANTILLA del generador: por cada dataset se copia al"
Write-Warn "proyecto y se edita la constante REPORT + los specs de pagina."

# ==============================================================================
# PASO 4 — Copiar el visual Filtro (.pbiviz)
# ==============================================================================
Write-Step 4 "Copiando el visual Filtro..."

# El .pbiviz correcto es FiltroGeneralUniversal; si no esta, cae al primero que exista.
$navaraDir = Join-Path $here "navara"
$filtroSrc = Get-ChildItem $navaraDir -Filter "FiltroGeneralUniversal*.pbiviz" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $filtroSrc) {
    $filtroSrc = Get-ChildItem $navaraDir -Filter "*.pbiviz" -ErrorAction SilentlyContinue | Select-Object -First 1
}
if ($filtroSrc) {
    $filtroDest = Join-Path $motorDest "filtro"
    New-Item -ItemType Directory -Force $filtroDest | Out-Null
    Copy-Item $filtroSrc.FullName $filtroDest -Force
    Write-OK "Filtro -> $filtroDest\$($filtroSrc.Name)"
    Write-Warn "Este .pbiviz se importa a mano UNA vez por reporte (ver tutorial)."
} else {
    Write-Warn "No se encontro ningun .pbiviz en navara\ (se omite)."
}

# ==============================================================================
# PASO 5 — Skills: marketplace de Fabric + skills propias de patrones
# ==============================================================================
Write-Step 5 "Registrando skills de Fabric + copiando skills propias..."

# 5a) Registrar el marketplace de Fabric en settings.json de Claude Code
#     (el plugin trae las skills report-* Y el MCP de modelado via npx).
$ccDir      = Join-Path $env:USERPROFILE ".claude"
$settings   = Join-Path $ccDir "settings.json"
New-Item -ItemType Directory -Force $ccDir | Out-Null

try {
    if ((Test-Path $settings) -and ((Get-Content $settings -Raw).Trim() -ne "")) {
        $cfg = Get-Content $settings -Raw | ConvertFrom-Json
    } else {
        $cfg = [PSCustomObject]@{}
    }
} catch {
    Write-Warn "settings.json existente no es JSON valido; no se toca. Registra el marketplace a mano."
    $cfg = $null
}

if ($cfg -ne $null) {
    if (-not $cfg.PSObject.Properties["extraKnownMarketplaces"]) {
        $cfg | Add-Member -NotePropertyName extraKnownMarketplaces -NotePropertyValue ([PSCustomObject]@{})
    }
    $mk = [PSCustomObject]@{
        source = [PSCustomObject]@{
            source = "git"
            url    = "https://github.com/microsoft/skills-for-fabric.git"
        }
    }
    $cfg.extraKnownMarketplaces | Add-Member -NotePropertyName "fabric-collection" -NotePropertyValue $mk -Force
    $cfg | ConvertTo-Json -Depth 12 | Set-Content $settings -Encoding UTF8
    Write-OK "Marketplace 'fabric-collection' registrado en settings.json"
    Write-Warn "Completa la instalacion del plugin desde Claude Code (Paso manual, abajo)."
}

# 5b) Copiar las skills propias que dan los patrones de custom visuals a Claude Code.
#     (Deneb, tarjetas HTML, Filtro, auditor de modelo.) La orquestacion la ponen las
#     skills de Fabric; NO se copia el viejo orquestador Python (powerbi-dashboard-builder)
#     ni la skill de M1 (powerbi-mcp-flow).
$skillsSrc  = Join-Path $here "skills"
$skillsDest = Join-Path $ccDir "skills"
$hybridSkills = @("deneb-chart-generator", "html-kpi-cards", "powerbi-filter", "powerbi-dax-auditor")
if (Test-Path $skillsSrc) {
    New-Item -ItemType Directory -Force $skillsDest | Out-Null
    foreach ($s in $hybridSkills) {
        $src = Join-Path $skillsSrc $s
        if (Test-Path $src) {
            $dest = Join-Path $skillsDest $s
            New-Item -ItemType Directory -Force $dest | Out-Null
            Copy-Item "$src\*" $dest -Recurse -Force
            Write-OK "skill: $s"
        }
    }
} else {
    Write-Warn "Carpeta 'skills\' no encontrada junto a setup.ps1 (se omite)."
}

# ==============================================================================
# RESUMEN
# ==============================================================================
Write-Banner
Write-Host ""
Write-Host "  Instalacion automatica completada." -ForegroundColor Green
Write-Host ""
Write-Host "  PASOS MANUALES PENDIENTES:" -ForegroundColor Yellow
Write-Host "    1. En Claude Code, termina de instalar el plugin de Fabric:" -ForegroundColor Gray
Write-Host "         /plugin marketplace add microsoft/skills-for-fabric" -ForegroundColor White
Write-Host "         /plugin install powerbi-authoring@fabric-collection" -ForegroundColor White
Write-Host "       (trae las skills report-* Y el MCP de modelado via npx)" -ForegroundColor DarkGray
Write-Host "    2. Reinicia Claude Code." -ForegroundColor Gray
Write-Host "    3. Instala Power BI Desktop y activa el formato PBIP" -ForegroundColor Gray
Write-Host "       (Archivo > Opciones > Vista previa > Power BI Project (.pbip))" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  POR CADA REPORTE NUEVO:" -ForegroundColor Yellow
Write-Host "    4. Importa Deneb y HTML Content desde AppSource en Power BI" -ForegroundColor Gray
Write-Host "       (Inicio > Mas objetos visuales > Desde AppSource)" -ForegroundColor DarkGray
Write-Host "    5. Importa el visual Filtro (.pbiviz) una vez por reporte" -ForegroundColor Gray
Write-Host "       (Inicio > Mas objetos visuales > Importar desde archivo)" -ForegroundColor DarkGray
Write-Host "       Archivo: $motorDest\filtro\" -ForegroundColor DarkGray
Write-Host "    6. Copia hybrid.js al proyecto y edita REPORT + los specs de pagina." -ForegroundColor Gray
Write-Host ""
Write-Host "  CICLO DE CONSTRUCCION (en Claude Code, con Node):" -ForegroundColor Cyan
Write-Host "    node _gen\hybrid.js" -ForegroundColor White
Write-Host "    powerbi-report-author validate <Reporte>.Report" -ForegroundColor White
Write-Host "    powerbi-desktop reload --pid <PID>   (y luego screenshot)" -ForegroundColor White
Write-Host ""
Write-Host ("  " + "-"*58) -ForegroundColor DarkGray
Write-Host "  Motor hibrido instalado en: $motorDest" -ForegroundColor Cyan
Write-Host ""
