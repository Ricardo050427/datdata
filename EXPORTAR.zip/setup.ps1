#Requires -Version 5.1
<#
.SYNOPSIS
    Instalador Todo-en-Uno — Metodologia 2 (Datdata + Fabric Authoring) para Power BI.

.DESCRIPTION
    Instala de forma automatica y desatendida todo el sistema de desarrollo de dashboards:
      [1] Verifica / instala Node.js LTS (winget)
      [2] Instala las CLIs oficiales de Fabric y el MCP (@microsoft/*)
      [3] Instala la suite completa de skills (Datdata + Fabric Report & Semantic Model Authoring)
      [4] Configura MCP servers y marketplaces para Claude Code y Antigravity
      [5] Valida sintaxis y conectividad de todo el entorno

    Requisitos unicos por parte del usuario:
      - Power BI Desktop con formato de proyecto (.pbip) activado.
      - Importar los 3 custom visuals (Deneb, HTML Content, Filtro) y guardar con Ctrl+S.
#>

$ErrorActionPreference = "SilentlyContinue"
$here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$ccDir      = Join-Path $env:USERPROFILE ".claude"
$ccSkills   = Join-Path $ccDir "skills"
$geminiDir  = Join-Path $env:USERPROFILE ".gemini\config"
$gemSkills  = Join-Path $geminiDir "skills"
$TOTAL      = 5

function Write-Banner { Write-Host ("`n" + "-"*64) -ForegroundColor DarkGray }
function Write-Step($n, $msg) { Write-Banner; Write-Host "  [$n/$TOTAL] $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "        OK  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "        !   $msg" -ForegroundColor Yellow }
function Write-Fail($msg) { Write-Host "        X   $msg" -ForegroundColor Red }

Clear-Host
Write-Host ""
Write-Host "  ================================================================" -ForegroundColor Magenta
Write-Host "    Datdata - Metodologia 2 Todo-en-Uno (Motor Automatizado)" -ForegroundColor Magenta
Write-Host "    Skills Fabric Authoring + hybrid.js + Deneb / HTML / Filtro" -ForegroundColor Magenta
Write-Host "  ================================================================" -ForegroundColor Magenta
Write-Host ""

# ==============================================================================
# PASO 1 - Node.js
# ==============================================================================
Write-Step 1 "Verificando entorno Node.js..."

if (Get-Command "node" -ErrorAction SilentlyContinue) {
    Write-OK "Node.js instalado ($((& node --version) 2>$null))."
} else {
    Write-Warn "Node.js no encontrado. Instalando version LTS via winget..."
    if (Get-Command "winget" -ErrorAction SilentlyContinue) {
        winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements 2>&1 | Out-Null
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
                    [System.Environment]::GetEnvironmentVariable("Path","User")
        if (Get-Command "node" -ErrorAction SilentlyContinue) {
            Write-OK "Node.js instalado exitosamente ($((& node --version) 2>$null))."
        } else {
            Write-Warn "Node.js quedo instalado pero requiere reiniciar la terminal para actualizar PATH."
        }
    } else {
        Write-Fail "winget no disponible. Descarga e instala Node.js LTS desde https://nodejs.org/"
    }
}

# ==============================================================================
# PASO 2 - CLIs de Fabric y MCP
# ==============================================================================
Write-Step 2 "Instalando herramientas CLI de Fabric (npm global)..."

if (Get-Command "npm" -ErrorAction SilentlyContinue) {
    npm install -g "@microsoft/powerbi-report-authoring-cli" "@microsoft/powerbi-desktop-bridge-cli" "@microsoft/powerbi-modeling-mcp" 2>&1 | Out-Null
    
    if (Get-Command "powerbi-report-author" -ErrorAction SilentlyContinue) {
        Write-OK "powerbi-report-author (validate, catalog, formatting, expressions)"
    } else { Write-Warn "powerbi-report-author instalado (sera visible al reabrir terminal)." }

    if (Get-Command "powerbi-desktop" -ErrorAction SilentlyContinue) {
        Write-OK "powerbi-desktop (status, reload, screenshot-all bridge)"
    } else { Write-Warn "powerbi-desktop instalado (sera visible al reabrir terminal)." }
} else {
    Write-Warn "npm no disponible en esta sesion. Ejecuta manualmente tras reiniciar la terminal:"
    Write-Warn "  npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli @microsoft/powerbi-modeling-mcp"
}

# ==============================================================================
# PASO 3 - Instalar la Suite Completa de Skills
# ==============================================================================
Write-Step 3 "Instalando la Suite Completa de Skills..."

$skillsSrc = Join-Path $here "skills"
if (-not (Test-Path $skillsSrc)) {
    Write-Fail "No se encontro la carpeta 'skills\' junto a setup.ps1."
    Write-Fail "Ejecuta setup.ps1 desde dentro del paquete descomprimido."
    exit 1
}

# 3.1 Instalar en Claude Code
New-Item -ItemType Directory -Force $ccSkills | Out-Null
$dateSuffix = Get-Date -Format "yyyyMMdd_HHmmss"

foreach ($dir in (Get-ChildItem $skillsSrc -Directory)) {
    $dest = Join-Path $ccSkills $dir.Name
    if (Test-Path $dest) {
        $bak = "$dest.bak_$dateSuffix"
        Move-Item $dest $bak -Force
    }
    New-Item -ItemType Directory -Force $dest | Out-Null
    Copy-Item "$($dir.FullName)\*" $dest -Recurse -Force
    Write-OK "Skill instalada (Claude): $($dir.Name)"
}

# 3.2 Instalar en Antigravity (si existe .gemini)
if (Test-Path (Join-Path $env:USERPROFILE ".gemini")) {
    New-Item -ItemType Directory -Force $gemSkills | Out-Null
    foreach ($dir in (Get-ChildItem $skillsSrc -Directory)) {
        $dest = Join-Path $gemSkills $dir.Name
        New-Item -ItemType Directory -Force $dest | Out-Null
        Copy-Item "$($dir.FullName)\*" $dest -Recurse -Force
    }
    Write-OK "Skills sincronizadas tambien en Antigravity (~/.gemini/config/skills/)"
}

$pbivizPath = Join-Path $ccSkills "powerbi-dashboard\assets\FiltroGeneralUniversal.pbiviz"
if (Test-Path $pbivizPath) {
    Write-OK "Visual personalizado Filtro listo en: $pbivizPath"
}

# ==============================================================================
# PASO 4 - Configuracion de MCP y Marketplace
# ==============================================================================
Write-Step 4 "Configurando Servidores MCP y Plugins..."

# 4.1 Claude Code settings.json
$settingsFile = Join-Path $ccDir "settings.json"
try {
    $cfg = $null
    if ((Test-Path $settingsFile) -and ((Get-Content $settingsFile -Raw).Trim() -ne "")) {
        Copy-Item $settingsFile "$settingsFile.bak_$dateSuffix" -Force
        $cfg = Get-Content $settingsFile -Raw | ConvertFrom-Json
    } else {
        $cfg = [PSCustomObject]@{}
    }

    if (-not $cfg.PSObject.Properties["extraKnownMarketplaces"]) {
        $cfg | Add-Member -NotePropertyName extraKnownMarketplaces -NotePropertyValue ([PSCustomObject]@{})
    }
    $mk = [PSCustomObject]@{
        source = [PSCustomObject]@{
            source = "git"
            url    = "https://github.com/microsoft/skills-for-fabric.git"
        }
    }
    $cfg.extraKnownMarketplaces | Add-Member -NotePropertyName "fabric-collection" -NotePropertyValue $mk -Force

    if (-not $cfg.PSObject.Properties["enabledPlugins"]) {
        $cfg | Add-Member -NotePropertyName enabledPlugins -NotePropertyValue ([PSCustomObject]@{})
    }
    $cfg.enabledPlugins | Add-Member -NotePropertyName "powerbi-authoring@fabric-collection" -NotePropertyValue $true -Force
    $cfg.enabledPlugins | Add-Member -NotePropertyName "fabric-skills@fabric-collection" -NotePropertyValue $true -Force

    $cfg | ConvertTo-Json -Depth 12 | Set-Content $settingsFile -Encoding UTF8
    Write-OK "Marketplace y plugins de Fabric pre-configurados en Claude Code."
} catch {
    Write-Warn "No se pudo actualizar settings.json automaticamente: $($_.Exception.Message)"
}

# 4.2 Antigravity mcp_config.json
if (Test-Path (Join-Path $env:USERPROFILE ".gemini")) {
    $mcpFile = Join-Path $geminiDir "mcp_config.json"
    try {
        $mcpCfg = $null
        if ((Test-Path $mcpFile) -and ((Get-Content $mcpFile -Raw).Trim() -ne "")) {
            Copy-Item $mcpFile "$mcpFile.bak_$dateSuffix" -Force
            $mcpCfg = Get-Content $mcpFile -Raw | ConvertFrom-Json
        } else {
            $mcpCfg = [PSCustomObject]@{ mcpServers = [PSCustomObject]@{} }
        }

        if (-not $mcpCfg.PSObject.Properties["mcpServers"]) {
            $mcpCfg | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([PSCustomObject]@{})
        }

        $pbiServer = [PSCustomObject]@{
            command = "npx"
            args    = @("-y", "@microsoft/powerbi-modeling-mcp@latest", "--start", "--skip-confirmation")
            type    = "stdio"
        }
        $mcpCfg.mcpServers | Add-Member -NotePropertyName "powerbi-modeling-mcp" -NotePropertyValue $pbiServer -Force
        $mcpCfg | ConvertTo-Json -Depth 12 | Set-Content $mcpFile -Encoding UTF8
        Write-OK "MCP de modelado Power BI configurado en Antigravity (~/.gemini/config/mcp_config.json)"
    } catch {
        Write-Warn "Aviso al configurar mcp_config.json: $($_.Exception.Message)"
    }
}

# ==============================================================================
# PASO 5 - Comprobacion Final
# ==============================================================================
Write-Step 5 "Ejecutando verificacion final del sistema..."

$hybridScript = Join-Path $ccSkills "powerbi-dashboard\assets\hybrid.js"
if (Test-Path $hybridScript) {
    $checkRes = (& node --check $hybridScript 2>&1)
    if ($LASTEXITCODE -eq 0) {
        Write-OK "Generador hybrid.js validado sintacticamente."
    } else {
        Write-Warn "hybrid.js reporto avisos de sintaxis: $checkRes"
    }
}

$skillCount = (Get-ChildItem $ccSkills -Directory | Where-Object { $_.Name -notlike "*.bak*" }).Count
Write-OK "$skillCount skills listas y verificadas en tu entorno."

# ==============================================================================
# RESUMEN Y PROXIMOS PASOS
# ==============================================================================
Write-Banner
Write-Host ""
Write-Host "  ¡INSTALACION COMPLETA Y LISTA PARA USAR!" -ForegroundColor Green
Write-Host ""
Write-Host "  TODO HA QUEDADO CONFIGURADO POR DEFECTO:" -ForegroundColor Cyan
Write-Host "    - CLIs de Fabric y bridge de Desktop instalados." -ForegroundColor Gray
Write-Host "    - Suite completa de 11+ skills instaladas y vinculadas." -ForegroundColor Gray
Write-Host "    - Servidores MCP configurados para conexion automatica." -ForegroundColor Gray
Write-Host ""
Write-Host "  PASOS UNICOS POR CADA REPORTE NUEVO:" -ForegroundColor Yellow
Write-Host "    1. Abre Power BI Desktop y guarda tu proyecto como .pbip" -ForegroundColor White
Write-Host "    2. Importa Deneb y HTML Content desde AppSource." -ForegroundColor White
Write-Host "    3. Importa el visual Filtro desde archivo:" -ForegroundColor White
Write-Host "       $pbivizPath" -ForegroundColor DarkGray
Write-Host "    4. Guarda con Ctrl+S." -ForegroundColor White
Write-Host ""
Write-Host "  PARA CONSTRUIR TU DASHBOARD:" -ForegroundColor Cyan
Write-Host '    En Claude Code o Antigravity, simplemente escribe:' -ForegroundColor Gray
Write-Host '    "Crea un dashboard del reporte que tengo abierto"' -ForegroundColor White
Write-Host ""
