#Requires -Version 5.1
<#
.SYNOPSIS
    Instalador — Metodologia 2 (hibrida) para dashboards de Power BI con Claude Code.

.DESCRIPTION
    Ejecutar desde la carpeta EXPORTAR\ con:
        PowerShell -ExecutionPolicy Bypass -File setup.ps1

    Que automatiza:
      [1] Verifica / instala Node.js (winget)
      [2] Instala las 2 CLIs de Fabric (npm -g)
      [3] Instala las 5 skills en %USERPROFILE%\.claude\skills
      [4] Registra el marketplace de skills de Fabric en Claude Code
      [5] Resumen y pasos manuales restantes

    Que sigue siendo MANUAL:
      - Instalar Power BI Desktop y activar el formato PBIP
      - Instalar Claude Code
      - /plugin install powerbi-authoring@fabric-collection (el script deja el
        marketplace registrado, pero la instalacion va desde Claude Code)
      - Importar Deneb, HTML Content y el Filtro en CADA reporte nuevo

    Todo el sistema vive en %USERPROFILE%\.claude\skills, asi que queda disponible
    en cualquier sesion y cualquier carpeta, sin copiar nada por proyecto.
#>

$ErrorActionPreference = "SilentlyContinue"
$here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$ccDir      = Join-Path $env:USERPROFILE ".claude"
$skillsDest = Join-Path $ccDir "skills"
$TOTAL      = 4

function Write-Banner { Write-Host ("`n" + "-"*62) -ForegroundColor DarkGray }
function Write-Step($n, $msg) { Write-Banner; Write-Host "  [$n/$TOTAL] $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "        OK  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "        !   $msg" -ForegroundColor Yellow }
function Write-Fail($msg) { Write-Host "        X   $msg" -ForegroundColor Red }

Clear-Host
Write-Host ""
Write-Host "  ==========================================================" -ForegroundColor Magenta
Write-Host "    Datdata - Metodologia 2 (hibrida)" -ForegroundColor Magenta
Write-Host "    Skills de Fabric + hybrid.js + Deneb / HTML / Filtro" -ForegroundColor Magenta
Write-Host "  ==========================================================" -ForegroundColor Magenta
Write-Host ""

# ==============================================================================
# PASO 1 - Node.js
# ==============================================================================
Write-Step 1 "Verificando Node.js..."

if (Get-Command "node" -ErrorAction SilentlyContinue) {
    Write-OK "Node.js ya instalado ($((& node --version) 2>$null))."
} else {
    Write-Warn "Node.js no encontrado. Intentando instalar con winget..."
    if (Get-Command "winget" -ErrorAction SilentlyContinue) {
        winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements 2>&1 | Out-Null
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
                    [System.Environment]::GetEnvironmentVariable("Path","User")
        if (Get-Command "node" -ErrorAction SilentlyContinue) {
            Write-OK "Node.js instalado ($((& node --version) 2>$null))."
        } else {
            Write-Warn "Node quedo instalado pero no visible en esta sesion."
            Write-Warn "Cierra y reabre PowerShell, y vuelve a ejecutar setup.ps1."
        }
    } else {
        Write-Fail "winget no disponible. Instala Node.js LTS desde nodejs.org y reintenta."
    }
}

# ==============================================================================
# PASO 2 - Las 2 CLIs de Fabric
# ==============================================================================
Write-Step 2 "Instalando las 2 CLIs de Fabric (npm global)..."

if (Get-Command "npm" -ErrorAction SilentlyContinue) {
    npm install -g "@microsoft/powerbi-report-authoring-cli" "@microsoft/powerbi-desktop-bridge-cli" 2>&1 | Out-Null
    if (Get-Command "powerbi-report-author" -ErrorAction SilentlyContinue) {
        Write-OK "powerbi-report-author (validate / catalog / formatting)"
    } else { Write-Warn "powerbi-report-author no visible aun (reinicia la terminal)." }
    if (Get-Command "powerbi-desktop" -ErrorAction SilentlyContinue) {
        Write-OK "powerbi-desktop (status / reload / screenshot)"
    } else { Write-Warn "powerbi-desktop no visible aun (reinicia la terminal)." }
} else {
    Write-Warn "npm no disponible (Node no instalado). Se omite este paso."
    Write-Warn "Tras instalar Node, corre a mano:"
    Write-Warn "  npm i -g @microsoft/powerbi-report-authoring-cli @microsoft/powerbi-desktop-bridge-cli"
}

# ==============================================================================
# PASO 3 - Instalar las skills
# ==============================================================================
Write-Step 3 "Instalando las skills en $skillsDest ..."

$skillsSrc = Join-Path $here "skills"
if (-not (Test-Path $skillsSrc)) {
    Write-Fail "No se encontro la carpeta 'skills\' junto a setup.ps1."
    Write-Fail "Ejecuta el script desde dentro de la carpeta EXPORTAR\."
    Read-Host "Presiona Enter para salir"; exit 1
}

New-Item -ItemType Directory -Force $skillsDest | Out-Null

foreach ($dir in (Get-ChildItem $skillsSrc -Directory)) {
    $dest = Join-Path $skillsDest $dir.Name
    # Si ya existe una version anterior, se respalda antes de sobrescribir.
    if (Test-Path $dest) {
        $bak = "$dest.bak_" + (Get-Date -Format "yyyyMMdd_HHmmss")
        Move-Item $dest $bak -Force
        Write-Warn "$($dir.Name) ya existia -> respaldado en $(Split-Path $bak -Leaf)"
    }
    New-Item -ItemType Directory -Force $dest | Out-Null
    Copy-Item "$($dir.FullName)\*" $dest -Recurse -Force
    Write-OK "skill: $($dir.Name)"
}

$pbiviz = Join-Path $skillsDest "powerbi-dashboard\assets\FiltroGeneralUniversal.pbiviz"
if (Test-Path $pbiviz) { Write-OK "visual Filtro listo para importar (ver pasos manuales)" }

# ==============================================================================
# PASO 4 - Marketplace de skills de Fabric
# ==============================================================================
Write-Step 4 "Registrando el marketplace de skills de Fabric..."

$settings = Join-Path $ccDir "settings.json"
New-Item -ItemType Directory -Force $ccDir | Out-Null

$cfg = $null
try {
    if ((Test-Path $settings) -and ((Get-Content $settings -Raw).Trim() -ne "")) {
        # Respaldo antes de tocar la configuracion del usuario.
        Copy-Item $settings "$settings.bak_$(Get-Date -Format 'yyyyMMdd_HHmmss')" -Force
        $cfg = Get-Content $settings -Raw | ConvertFrom-Json
    } else {
        $cfg = [PSCustomObject]@{}
    }
} catch {
    Write-Warn "settings.json existente no es JSON valido; no se toca."
    Write-Warn "Registra el marketplace a mano desde Claude Code (ver abajo)."
}

if ($null -ne $cfg) {
    if (-not $cfg.PSObject.Properties["extraKnownMarketplaces"]) {
        $cfg | Add-Member -NotePropertyName extraKnownMarketplaces -NotePropertyValue ([PSCustomObject]@{})
    }
    $mk = [PSCustomObject]@{
        source = [PSCustomObject]@{
            source = "git"
            url    = "https://github.com/microsoft/skills-for-fabric.git"
        }
    }
    $cfg.extraKnownMarketplaces | Add-Member -NotePropertyName "fabric-collection" -NotePropertyValue $mk -Force
    $cfg | ConvertTo-Json -Depth 12 | Set-Content $settings -Encoding UTF8
    Write-OK "Marketplace 'fabric-collection' registrado en settings.json"
}

# ==============================================================================
# RESUMEN
# ==============================================================================
Write-Banner
Write-Host ""
Write-Host "  Instalacion automatica completada." -ForegroundColor Green
Write-Host ""
Write-Host "  PASOS MANUALES PENDIENTES:" -ForegroundColor Yellow
Write-Host "    1. En Claude Code, instala el plugin de Fabric:" -ForegroundColor Gray
Write-Host "         /plugin marketplace add microsoft/skills-for-fabric" -ForegroundColor White
Write-Host "         /plugin install powerbi-authoring@fabric-collection" -ForegroundColor White
Write-Host "       (trae las skills report-* Y el MCP de modelado via npx)" -ForegroundColor DarkGray
Write-Host "    2. Reinicia Claude Code." -ForegroundColor Gray
Write-Host "    3. Power BI Desktop: activa el formato de proyecto" -ForegroundColor Gray
Write-Host "       Archivo > Opciones > Vista previa > Power BI Project (.pbip)" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  POR CADA REPORTE NUEVO (una vez por reporte):" -ForegroundColor Yellow
Write-Host "    4. Importa Deneb y HTML Content desde AppSource." -ForegroundColor Gray
Write-Host "    5. Importa el visual Filtro desde archivo:" -ForegroundColor Gray
Write-Host "       $pbiviz" -ForegroundColor DarkGray
Write-Host "    6. Guarda con Ctrl+S ANTES de pedirle el dashboard a Claude." -ForegroundColor Gray
Write-Host ""
Write-Host "  YA ESTA. Abre tu .pbip con los datos cargados y dile a Claude Code:" -ForegroundColor Cyan
Write-Host '     "Crea un dashboard del reporte que tengo abierto"' -ForegroundColor White
Write-Host ""
Write-Host ("  " + "-"*58) -ForegroundColor DarkGray
Write-Host "  Skills instaladas en: $skillsDest" -ForegroundColor Cyan
Write-Host ""
