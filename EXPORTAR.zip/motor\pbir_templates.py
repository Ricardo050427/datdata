#!/usr/bin/env python3
"""
pbir_templates.py — Fábricas de visuales para reportes Power BI PBIR.

Cada función devuelve un dict completo y válido de visual.json, listo para
escribir en pages/<page>/visuals/<id>/visual.json. Los esquemas se derivaron
de visuales reales existentes en el reporte (no son inventados), así que
producen visuales que Power BI abre sin errores.

Tipos soportados:
  - card            (tarjeta nativa de Power BI)
  - html_card       (HTML Content de Daniel Marsh-Patrick — mide DAX que devuelve HTML)
  - bar_chart       (barras horizontales)
  - column_chart    (columnas verticales)
  - line_chart      (líneas)
  - donut_chart / pie_chart
  - slicer          (segmentador)
  - table           (tabla)
  - deneb           (Vega-Lite vía custom visual Deneb)
  - textbox         (cuadro de texto)
"""

import json
import uuid

SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.10.0/schema.json"

# GUIDs de los custom visuals tal como están instalados en ESTE reporte.
# Se pueden auto-detectar con detect_custom_type(); estos son el fallback.
DENEB_TYPE = "deneb7E15AEF80B9E4D4F8E12924291ECE89A"
HTMLCONTENT_TYPE = "htmlContent443BE3AD55E043BF878BED274D3A6855"


# ──────────────────────────────────────────────
# Codificación de literales Power BI
# ──────────────────────────────────────────────

def slit(s: str) -> dict:
    """Literal de string: 'texto' (comillas simples internas se duplican)."""
    return {"expr": {"Literal": {"Value": "'" + str(s).replace("'", "''") + "'"}}}

def blit(b: bool) -> dict:
    return {"expr": {"Literal": {"Value": "true" if b else "false"}}}

def dlit(n) -> dict:
    """Literal double (sufijo D)."""
    return {"expr": {"Literal": {"Value": f"{n}D"}}}

def ilit(n) -> dict:
    """Literal long/entero (sufijo L)."""
    return {"expr": {"Literal": {"Value": f"{int(n)}L"}}}

def theme_color(color_id: int, percent: float = 0) -> dict:
    return {"expr": {"ThemeDataColor": {"ColorId": color_id, "Percent": percent}}}

def solid_color(hex_color: str) -> dict:
    """Color sólido fijo a partir de un hex '#RRGGBB'."""
    return {"solid": {"color": slit(hex_color)}}


# ──────────────────────────────────────────────
# Campos / proyecciones
# ──────────────────────────────────────────────

def field(entity: str, prop: str, kind: str = "measure") -> dict:
    """Proyección de un campo (Measure o Column)."""
    key = "Measure" if kind == "measure" else "Column"
    return {
        "field": {
            key: {
                "Expression": {"SourceRef": {"Entity": entity}},
                "Property": prop,
            }
        },
        "queryRef": f"{entity}.{prop}",
        "nativeQueryRef": prop,
    }

def _measure_ref(entity: str, prop: str) -> dict:
    return {
        "Measure": {
            "Expression": {"SourceRef": {"Entity": entity}},
            "Property": prop,
        }
    }


# ──────────────────────────────────────────────
# Posición
# ──────────────────────────────────────────────

def position(x, y, w, h, z=None, tab=None) -> dict:
    z = z if z is not None else 1000
    return {
        "x": round(float(x), 4),
        "y": round(float(y), 4),
        "z": z,
        "height": round(float(h), 4),
        "width": round(float(w), 4),
        "tabOrder": tab if tab is not None else z,
    }

def new_id() -> str:
    return uuid.uuid4().hex[:20]


def _container(name: str, pos: dict, visual: dict, extra: dict = None) -> dict:
    out = {
        "$schema": SCHEMA,
        "name": name,
        "position": pos,
        "visual": visual,
    }
    if extra:
        out.update(extra)
    return out


# ──────────────────────────────────────────────
# Objetos de contenedor comunes (título, fondo, borde)
# ──────────────────────────────────────────────

def _title_obj(text: str, align_="center", color_hex=None, bold=True):
    props = {"text": slit(text), "alignment": slit(align_), "show": blit(True)}
    if bold:
        props["bold"] = blit(True)
    if color_hex:
        props["fontColor"] = solid_color(color_hex)
    return [{"properties": props}]

def _hide_obj():
    return [{"properties": {"show": blit(False)}}]


# ──────────────────────────────────────────────
# Fábricas de visuales
# ──────────────────────────────────────────────

def card(name, pos, entity, measure, display=None, z=4000):
    """Tarjeta nativa de Power BI mostrando una medida."""
    proj = {
        "field": _measure_ref(entity, measure),
        "queryRef": f"{entity}.{measure}",
    }
    if display:
        proj["displayName"] = display
    else:
        proj["nativeQueryRef"] = measure
    visual = {
        "visualType": "card",
        "query": {"queryState": {"Values": {"projections": [proj]}}},
        "drillFilterOtherVisuals": True,
    }
    return _container(name, position(**pos, z=z), visual)


def html_card(name, pos, entity, measure, custom_type=None, z=8000):
    """Tarjeta HTML Content: renderiza una medida DAX que devuelve HTML.

    La medida debe existir en el modelo (creada vía MCP) y devolver una cadena
    HTML. Aquí solo se crea el contenedor que la apunta.
    """
    vtype = custom_type or HTMLCONTENT_TYPE
    proj = {
        "field": _measure_ref(entity, measure),
        "queryRef": f"{entity}.{measure}",
        "nativeQueryRef": measure,
    }
    visual = {
        "visualType": vtype,
        "query": {"queryState": {"content": {"projections": [proj]}}},
        "visualContainerObjects": {
            "background": _hide_obj(),
            "border": _hide_obj(),
            "title": _hide_obj(),
        },
        "drillFilterOtherVisuals": True,
    }
    return _container(name, position(**pos, z=z), visual)


def _cartesian(vtype, name, pos, category, y, series=None, title=None,
               color_id=7, z=3000):
    """Base para barChart / columnChart / lineChart."""
    qstate = {
        "Category": {"projections": [
            {**field(category["entity"], category["property"],
                     category.get("kind", "column")), "active": True}
        ]},
        "Y": {"projections": [
            field(y["entity"], y["property"], y.get("kind", "measure"))
        ]},
    }
    if series:
        qstate["Series"] = {"projections": [
            field(series["entity"], series["property"], series.get("kind", "column"))
        ]}

    objects = {
        "categoryAxis": [{"properties": {"showAxisTitle": blit(False)}}],
        "valueAxis": [{"properties": {"showAxisTitle": blit(False)}}],
        "dataPoint": [{"properties": {"fill": {"solid": {"color": theme_color(color_id)}}}}],
    }
    vco = {}
    if title:
        vco["title"] = _title_obj(title)

    visual = {
        "visualType": vtype,
        "query": {
            "queryState": qstate,
            "sortDefinition": {
                "sort": [{
                    "field": _measure_ref(y["entity"], y["property"])
                             if y.get("kind", "measure") == "measure"
                             else {"Column": {"Expression": {"SourceRef": {"Entity": y["entity"]}}, "Property": y["property"]}},
                    "direction": "Descending",
                }],
                "isDefaultSort": True,
            },
        },
        "objects": objects,
        "drillFilterOtherVisuals": True,
    }
    if vco:
        visual["visualContainerObjects"] = vco
    return _container(name, position(**pos, z=z), visual)


def bar_chart(name, pos, category, y, series=None, title=None, color_id=7, z=3000):
    return _cartesian("barChart", name, pos, category, y, series, title, color_id, z)

def column_chart(name, pos, category, y, series=None, title=None, color_id=7, z=3000):
    return _cartesian("columnChart", name, pos, category, y, series, title, color_id, z)

def line_chart(name, pos, category, y, series=None, title=None, color_id=7, z=3000):
    return _cartesian("lineChart", name, pos, category, y, series, title, color_id, z)


def donut_chart(name, pos, category, y, title=None, z=3000, donut=True):
    """Gráfica de dona (donut=True) o pastel (donut=False)."""
    vtype = "donutChart" if donut else "pieChart"
    qstate = {
        "Category": {"projections": [
            field(category["entity"], category["property"], category.get("kind", "column"))
        ]},
        "Y": {"projections": [
            field(y["entity"], y["property"], y.get("kind", "measure"))
        ]},
    }
    visual = {
        "visualType": vtype,
        "query": {"queryState": qstate},
        "drillFilterOtherVisuals": True,
    }
    if title:
        visual["visualContainerObjects"] = {"title": _title_obj(title)}
    return _container(name, position(**pos, z=z), visual)

def pie_chart(name, pos, category, y, title=None, z=3000):
    return donut_chart(name, pos, category, y, title, z, donut=False)


def slicer(name, pos, entity, column, mode="Dropdown", title=None, z=3000):
    """Segmentador. mode: 'Dropdown' | 'Basic' (lista) | 'Between' (rango)."""
    visual = {
        "visualType": "slicer",
        "query": {"queryState": {"Values": {"projections": [
            {**field(entity, column, "column"), "active": True}
        ]}}},
        "objects": {
            "data": [{"properties": {"mode": slit(mode)}}],
        },
        "drillFilterOtherVisuals": True,
    }
    if title:
        visual["visualContainerObjects"] = {"title": _title_obj(title)}
    return _container(name, position(**pos, z=z), visual)


PILLFILTER_GUID  = "pillfilterbar4754C73F9D3E4F3597CC66BCD1CF5589"
NAVARA_GUID      = "navarafilterA1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6"


def custom_pill(name, pos, entity, column, z=5000):
    """Pill filter personalizado (custom visual pillfilterbar).

    Muestra 'Campo: Todos' / 'Campo: Valor' / 'Campo: N selec.' y filtra
    otros visuales de la página via applyJsonFilter.

    El visual debe estar importado en el reporte antes de usar este tipo.
    GUID: pillfilterbar4754C73F9D3E4F3597CC66BCD1CF5589
    """
    proj = {
        "field": {
            "Column": {
                "Expression": {"SourceRef": {"Entity": entity}},
                "Property": column,
            }
        },
        "queryRef": f"{entity}.{column}",
        "nativeQueryRef": column,
    }
    visual = {
        "visualType": PILLFILTER_GUID,
        "query": {
            "queryState": {
                "category": {
                    "projections": [proj]
                }
            },
            "sortDefinition": {"isDefaultSort": True},
        },
        "drillFilterOtherVisuals": True,
        "visualContainerObjects": {
            "background": [{"properties": {"show": blit(False)}}],
            "border": [{"properties": {"show": blit(False)}}],
            "title": _hide_obj(),
            "visualHeader": [{"properties": {"show": blit(False)}}],
        },
    }
    return _container(name, position(**pos, z=z), visual)


def navara_filter(name, pos, fields, accent=None, z=5000):
    """Barra de filtros Navara — un único visual que maneja N columnas.

    fields: lista de dicts con 'entity' y 'column', e.g.:
        [{"entity": "f_Tickets", "column": "Categoría"},
         {"entity": "d_Calendario", "column": "Mes"}]

    accent: hex '#RRGGBB' del color de acento. Si se pasa, se escribe en el
        objeto de formato 'appearance' del visual para que la barra combine con
        la paleta del dashboard (pills activos, tabs, chips, botón aplicar).
        Si es None, el visual usa su morado por defecto (#7C3AED).

    Muestra los primeros 3 campos como pills visibles + panel 'Más Filtros'
    para el resto. Soporta búsqueda, chips y limpiar individual/global.

    El visual debe estar importado en el reporte (GUID: NAVARA_GUID).
    """
    projections = [
        {
            "field": {
                "Column": {
                    "Expression": {"SourceRef": {"Entity": f["entity"]}},
                    "Property": f["column"],
                }
            },
            "queryRef": f"{f['entity']}.{f['column']}",
            "nativeQueryRef": f["column"],
        }
        for f in fields
    ]
    visual = {
        "visualType": NAVARA_GUID,
        "query": {
            "queryState": {
                "category": {
                    "projections": projections
                }
            },
            "sortDefinition": {"isDefaultSort": True},
        },
        "drillFilterOtherVisuals": True,
        "visualContainerObjects": {
            "background": [{"properties": {"show": blit(False)}}],
            "border": [{"properties": {"show": blit(False)}}],
            "title": _hide_obj(),
            "visualHeader": [{"properties": {"show": blit(False)}}],
        },
    }
    if accent:
        visual["objects"] = {
            "appearance": [{"properties": {"accent": solid_color(accent)}}]
        }
    return _container(name, position(**pos, z=z), visual)


def pill_slicer(name, pos, entity, column, label=None, label_measure=None,
                label_entity="DAX Medidas", z=5000):
    """Dropdown slicer estilo pill — borde redondeado, búsqueda, multi-select.

    label_measure: medida DAX para el texto del header del pill
    (e.g. "_Pill Categoría" → "Categoría: Todos" / "Categoría: 2 selec.")
    El texto va en slicerHeader.text con expr Measure (conditional formatting nativo).
    """
    header_props = {
        "show": blit(True),
        "fontColor": solid_color("#374151"),
        "background": solid_color("#FFFFFF"),
        "fontSize": dlit(11),
        "bold": blit(False),
        "border": blit(False),
    }
    if label_measure:
        # Conditional formatting en el texto del slicer header
        header_props["text"] = {"expr": {"Measure": {
            "Expression": {"SourceRef": {"Entity": label_entity}},
            "Property": label_measure,
        }}}

    objects = {
        "data": [{"properties": {"mode": slit("Dropdown")}}],
        "selection": [{"properties": {
            "selectAllCheckboxEnabled": blit(True),
            "singleSelect": blit(False),
        }}],
        "search": [{"properties": {"show": blit(True)}}],
        "slicerHeader": [{"properties": header_props}],
        "items": [{"properties": {
            "fontColor": solid_color("#374151"),
            "background": solid_color("#FFFFFF"),
            "fontSize": dlit(11),
            "outline": slit("None"),
        }}],
    }

    vco = {
        "background": [{"properties": {
            "show": blit(True),
            "color": solid_color("#FFFFFF"),
            "transparency": dlit(0),
        }}],
        "border": [{"properties": {
            "show": blit(True),
            "color": solid_color("#D1D5DB"),
            "radius": dlit(20),
        }}],
        "title": _hide_obj(),
    }
    visual = {
        "visualType": "slicer",
        "query": {"queryState": {"Values": {"projections": [
            {**field(entity, column, "column"), "active": True}
        ]}}},
        "objects": objects,
        "visualContainerObjects": vco,
        "drillFilterOtherVisuals": True,
    }
    return _container(name, position(**pos, z=z), visual)


def table(name, pos, fields, title=None, z=3000):
    """Tabla. fields = lista de {entity, property, kind}."""
    projs = [field(f["entity"], f["property"], f.get("kind", "column")) for f in fields]
    visual = {
        "visualType": "tableEx",
        "query": {"queryState": {"Values": {"projections": projs}}},
        "drillFilterOtherVisuals": True,
    }
    if title:
        visual["visualContainerObjects"] = {"title": _title_obj(title)}
    return _container(name, position(**pos, z=z), visual)


def textbox(name, pos, text, font_size=14, color_hex="#000000", bold=False, z=3000):
    """Cuadro de texto simple."""
    run = {"value": text}
    text_style = {"fontSize": f"{font_size}px", "color": color_hex}
    if bold:
        text_style["fontWeight"] = "bold"
    run["textStyle"] = text_style
    visual = {
        "visualType": "textbox",
        "objects": {
            "general": [{
                "properties": {
                    "paragraphs": [{
                        "textRuns": [run]
                    }]
                }
            }]
        },
        "drillFilterOtherVisuals": True,
    }
    return _container(name, position(**pos, z=z), visual)


def _shade(hex_color: str, factor: float) -> str:
    """Oscurece (factor<0) o aclara (factor>0) un color '#RRGGBB'. factor en [-1, 1]."""
    h = hex_color.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    if factor < 0:
        r = max(0, int(r * (1 + factor)))
        g = max(0, int(g * (1 + factor)))
        b = max(0, int(b * (1 + factor)))
    else:
        r = min(255, int(r + (255 - r) * factor))
        g = min(255, int(g + (255 - g) * factor))
        b = min(255, int(b + (255 - b) * factor))
    return f'#{r:02x}{g:02x}{b:02x}'


def action_button(name, pos, text_label, bookmark_id,
                  bg_hex="#6A0DAD", text_hex="#FFFFFF", font_size=12,
                  radius=8, shadow=True, border_hex=None,
                  is_hidden=False, z=9000):
    """Botón de acción que dispara un bookmark.

    radius:     radio de esquinas redondeadas en px (0 = sin redondear, default 8)
    shadow:     sombra sutil bajo el botón (default True)
    border_hex: color de borde visible (None = sin borde)
    Los estados hover y pressed se derivan automáticamente de bg_hex.
    """
    hover_hex = _shade(bg_hex, -0.15)
    press_hex = _shade(bg_hex, -0.28)

    fill = [
        {"properties": {"show": blit(True), "fillColor": solid_color(bg_hex)}},
        {"properties": {"fillColor": solid_color(bg_hex)},   "selector": {"id": "default"}},
        {"properties": {"fillColor": solid_color(hover_hex)}, "selector": {"id": "hover"}},
        {"properties": {"fillColor": solid_color(press_hex)}, "selector": {"id": "pressed"}},
    ]

    text = [
        {"properties": {"show": blit(True)}},
        {"properties": {
            "text":      slit(text_label),
            "fontColor": solid_color(text_hex),
            "fontSize":  dlit(font_size),
            "bold":      blit(True),
            "alignment": slit("center"),
        }, "selector": {"id": "default"}},
        {"properties": {"fontColor": solid_color(text_hex)}, "selector": {"id": "hover"}},
        {"properties": {"fontColor": solid_color(text_hex)}, "selector": {"id": "pressed"}},
    ]

    outline_props = {"show": blit(bool(border_hex))}
    if border_hex:
        outline_props["color"]  = solid_color(border_hex)
        outline_props["weight"] = dlit(1.5)
    if radius:
        outline_props["radius"] = dlit(radius)

    vco = {
        "background": [{"properties": {
            "show":         blit(True),
            "color":        solid_color(bg_hex),
            "transparency": dlit(0),
        }}],
        "border": [{"properties": {
            "show":   blit(True),
            "radius": dlit(radius),
            "color":  solid_color(border_hex or bg_hex),
        }}],
        "title": _hide_obj(),
        "visualLink": [{"properties": {
            "show":     blit(True),
            "type":     slit("Bookmark"),
            "bookmark": slit(bookmark_id),
        }}],
    }

    if shadow:
        vco["dropShadow"] = [{"properties": {
            "show":         blit(True),
            "color":        solid_color(_shade(bg_hex, -0.3)),
            "position":     slit("Outer"),
            "preset":       slit("BottomRight"),
            "angle":        dlit(135),
            "transparency": dlit(75),
        }}]

    visual = {
        "visualType": "actionButton",
        "objects": {
            "icon":    [{"properties": {"show": blit(False)}}],
            "text":    text,
            "outline": [{"properties": outline_props}],
            "fill":    fill,
        },
        "visualContainerObjects": vco,
        "drillFilterOtherVisuals": False,
    }

    out = _container(name, position(**pos, z=z), visual)
    if is_hidden:
        out["isHidden"] = True
    return out


def background_rect(name, pos, color_hex="#FFFFFF", border_hex="#E0D6F5",
                    is_hidden=False, z=7500):
    """Rectángulo de fondo (textbox vacío con relleno sólido y borde)."""
    visual = {
        "visualType": "textbox",
        "objects": {
            "general": [{"properties": {"paragraphs": [{"textRuns": [{"value": ""}]}]}}]
        },
        "visualContainerObjects": {
            "background": [{"properties": {
                "show": blit(True),
                "color": solid_color(color_hex),
                "transparency": dlit(0),
            }}],
            "border": [{"properties": {
                "show": blit(True),
                "color": solid_color(border_hex),
                "radius": dlit(10),
            }}],
            "title": _hide_obj(),
            "dropShadow": [{"properties": {
                "show": blit(True),
                "color": solid_color("#6A0DAD"),
                "position": slit("Outer"),
                "preset": slit("BottomRight"),
                "angle": dlit(135),
                "transparency": dlit(80),
            }}],
        },
        "drillFilterOtherVisuals": False,
    }
    out = _container(name, position(**pos, z=z), visual)
    if is_hidden:
        out["isHidden"] = True
    return out


def deneb(name, pos, dataset, vega_spec, custom_type=None,
          deneb_version="6.4.1", z=7000):
    """Visual Deneb con una spec Vega-Lite.

    dataset   : lista de campos {entity, property, kind} que alimentan el dataset
    vega_spec : dict de la spec Vega-Lite (se serializa y empaqueta como literal)

    El nombre del dataset en Vega es 'dataset' y los campos se referencian por
    su nativeQueryRef (= property), tal como Power BI los expone a Deneb.
    """
    vtype = custom_type or DENEB_TYPE
    projs = [field(f["entity"], f["property"], f.get("kind",
             "measure" if f.get("kind") == "measure" else "column"))
             for f in dataset]

    spec_text = json.dumps(vega_spec, ensure_ascii=False, indent=2)
    spec_literal = "'" + spec_text.replace("'", "''") + "'"

    vw = round(pos["w"] - 20, 6)
    vh = round(pos["h"] - 20, 6)

    visual = {
        "visualType": vtype,
        "query": {
            "queryState": {"dataset": {"projections": projs}},
            "sortDefinition": {"isDefaultSort": True},
        },
        "objects": {
            "vega": [{
                "properties": {
                    "provider": slit("vegaLite"),
                    "jsonSpec": {"expr": {"Literal": {"Value": spec_literal}}},
                    "jsonConfig": slit("{}"),
                    "enableTooltips": blit(True),
                    "enableContextMenu": blit(True),
                    "enableHighlight": blit(False),
                    "enableSelection": blit(False),
                    "selectionMaxDataPoints": dlit(50),
                    "selectionMode": slit("simple"),
                    "version": slit(deneb_version),
                }
            }],
            "stateManagement": [{
                "properties": {
                    "viewportHeight": dlit(vh),
                    "viewportWidth": dlit(vw),
                }
            }],
            "developer": [{"properties": {"version": slit("1.9.1.0")}}],
        },
        "drillFilterOtherVisuals": True,
    }
    return _container(name, position(**pos, z=z), visual)
