#!/usr/bin/env python3
"""
pbir_layout.py — Motor de layout (grid) para reportes Power BI PBIR.

En vez de calcular coordenadas x/y a mano (propenso a errores), se define un
lienzo dividido en una cuadrícula de columnas x filas con márgenes y separación
(gutter) consistentes. Cada visual se coloca en celdas (col, row, colspan,
rowspan) y el motor calcula la posición/tamaño exactos en píxeles.

Esto resuelve el problema de "quedó lejos / cambió de tamaño": las posiciones
salen de una matemática determinista, no de adivinar.
"""

from dataclasses import dataclass


@dataclass
class Grid:
    """Cuadrícula sobre el lienzo del reporte.

    width/height : tamaño del lienzo (default 1280x720, estándar 16:9 de Power BI)
    cols/rows    : número de columnas y filas de la cuadrícula
    margin       : margen exterior (px) entre el borde del lienzo y el contenido
    gutter       : separación (px) entre celdas
    """
    width: float = 1280
    height: float = 720
    cols: int = 12
    rows: int = 8
    margin: float = 24
    gutter: float = 12

    @property
    def cell_w(self) -> float:
        usable = self.width - 2 * self.margin - (self.cols - 1) * self.gutter
        return usable / self.cols

    @property
    def cell_h(self) -> float:
        usable = self.height - 2 * self.margin - (self.rows - 1) * self.gutter
        return usable / self.rows

    def cell(self, col: int, row: int, colspan: int = 1, rowspan: int = 1) -> dict:
        """Devuelve {x, y, width, height} para un bloque de celdas.

        col/row son índices base-0 (esquina superior izquierda = 0,0).
        colspan/rowspan = cuántas celdas ocupa horizontal/verticalmente.
        """
        if col < 0 or row < 0:
            raise ValueError("col y row deben ser >= 0")
        if col + colspan > self.cols:
            raise ValueError(
                f"El visual se sale de la cuadrícula: col {col} + colspan {colspan} > cols {self.cols}"
            )
        if row + rowspan > self.rows:
            raise ValueError(
                f"El visual se sale de la cuadrícula: row {row} + rowspan {rowspan} > rows {self.rows}"
            )
        cw, ch = self.cell_w, self.cell_h
        x = self.margin + col * (cw + self.gutter)
        y = self.margin + row * (ch + self.gutter)
        w = colspan * cw + (colspan - 1) * self.gutter
        h = rowspan * ch + (rowspan - 1) * self.gutter
        return {
            "x": round(x, 4),
            "y": round(y, 4),
            "width": round(w, 4),
            "height": round(h, 4),
        }


# ──────────────────────────────────────────────
# Posicionamiento relativo (sin grid)
# ──────────────────────────────────────────────

def place_next_to(ref: dict, side: str = "right", gap: float = 12,
                  match_size: bool = True, width: float = None,
                  height: float = None) -> dict:
    """Calcula la posición de un visual junto a otro (ref = su position dict).

    side: 'right' | 'left' | 'top' | 'bottom'
    gap : separación en px
    match_size: si True, hereda el tamaño del visual de referencia
    width/height: tamaño explícito (sobrescribe match_size en ese eje)
    """
    rx, ry = ref["x"], ref["y"]
    rw, rh = ref["width"], ref["height"]

    w = width if width is not None else (rw if match_size else rw)
    h = height if height is not None else (rh if match_size else rh)

    if side == "right":
        x, y = rx + rw + gap, ry
    elif side == "left":
        x, y = rx - w - gap, ry
    elif side == "bottom":
        x, y = rx, ry + rh + gap
    elif side == "top":
        x, y = rx, ry - h - gap
    else:
        raise ValueError(f"side inválido: {side} (usa right|left|top|bottom)")

    return {"x": round(x, 4), "y": round(y, 4),
            "width": round(w, 4), "height": round(h, 4)}


def align(positions: list[dict], edge: str = "top") -> list[dict]:
    """Alinea una lista de position dicts a un borde común.

    edge: 'top' | 'bottom' | 'left' | 'right' | 'center-h' | 'center-v'
    Devuelve nuevas posiciones (no muta las originales).
    """
    if not positions:
        return []
    out = [dict(p) for p in positions]
    if edge == "top":
        v = min(p["y"] for p in out)
        for p in out: p["y"] = v
    elif edge == "bottom":
        v = max(p["y"] + p["height"] for p in out)
        for p in out: p["y"] = v - p["height"]
    elif edge == "left":
        v = min(p["x"] for p in out)
        for p in out: p["x"] = v
    elif edge == "right":
        v = max(p["x"] + p["width"] for p in out)
        for p in out: p["x"] = v - p["width"]
    elif edge == "center-v":  # mismo centro vertical
        c = sum(p["y"] + p["height"] / 2 for p in out) / len(out)
        for p in out: p["y"] = c - p["height"] / 2
    elif edge == "center-h":  # mismo centro horizontal
        c = sum(p["x"] + p["width"] / 2 for p in out) / len(out)
        for p in out: p["x"] = c - p["width"] / 2
    else:
        raise ValueError(f"edge inválido: {edge}")
    return out
