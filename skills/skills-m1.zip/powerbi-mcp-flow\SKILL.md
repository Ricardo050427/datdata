---
name: powerbi-mcp-flow
description: >
  Metodología M1 — flujo para dashboards Power BI usando solo MCP + chat, sin scripts Python.
  Activar cuando el usuario mencione "metodología MCP", "sin scripts", "quiero hacerlo
  más sencillo", o cuando no tenga el motor PBIR instalado. En este flujo el usuario
  coloca los visuales manualmente en el lienzo; Claude entrega DAX (via MCP), JSON Deneb
  (para copiar), HTML cards (via MCP), e instrucciones de filtro via skill powerbi-filter.
  También activar cuando el usuario pida solo medidas DAX + instrucciones de colocación.
---

# Power BI Dashboard — Flujo MCP + Chat (M1)

Metodología ligera: Claude crea las medidas y genera los specs; el usuario los coloca
en el lienzo. Sin `pbi.ps1`, sin `build-dashboard`, sin edición de archivos PBIR.

---

## Diferencia con M2

| | M1 (MCP + Chat) | M2 (motor PBIR) |
|--|--|--|
| **Colocación de visuales** | El usuario los coloca a mano | Claude la hace automáticamente |
| **Herramientas** | Solo MCP + chat | `pbi.ps1 build-dashboard` + MCP |
| **Prerrequisitos** | Solo PBI Desktop + MCP conectado | Motor instalado, `pbi-init` corrido |
| **Velocidad** | Más flexible (control manual) | Más rápido (automatizado) |
| **Filtro** | Instrucciones via skill powerbi-filter | Colocado automáticamente con spec |

---

## Flujo de trabajo

### 1. Conectar via MCP (PBI debe estar ABIERTO)

```
powerbi-modeling-mcp → connection_operations → ListLocalInstances
```

Conectarse a la instancia abierta. Leer el modelo para conocer tablas y columnas.

### 2. Crear medidas DAX

Con PBI **abierto**, crear las medidas via MCP:

```
measure_operations → Create
  table: "DAX Medidas"   (o la tabla de medidas del proyecto)
  name: "Total Tickets"
  expression: "COUNTROWS(f_Tickets)"
```

Crear en orden:
1. Medidas base (conteos, sumas, promedios)
2. Variaciones (vs período anterior, vs meta)
3. Medidas HTML para tarjetas KPI
4. Medidas complementarias

Mostrar lista de medidas creadas antes de continuar.

### 3. Tarjetas KPI — medidas HTML

Crear la medida HTML via MCP. El usuario después:
1. Inserta un **HTML Content visual** en el lienzo (debe tenerlo importado)
2. Arrastra la medida al campo "Values" del visual

**Patrón correcto (OBLIGATORIO):**

```dax
KPI Nombre HTML =
VAR _css =
"html, body { margin:0; padding:0; width:100%; height:100%; overflow:hidden; }
* { box-sizing:border-box; }
body { font-family:'Segoe UI',sans-serif; display:flex; flex-direction:column;
       gap:10px; padding:8px; background:transparent; }
.card { background:#fff; border:1.5px solid #e0d6f5;
        border-radius:12px; padding:11px 8px;
        flex:1; min-height:0; display:flex; flex-direction:column; justify-content:center;
        box-shadow:0 2px 10px rgba(102,51,153,.08);
        transition:all .25s ease; cursor:default; overflow:hidden; }
.card:hover { background:linear-gradient(135deg,#6A0DAD,#9B59B6);
              box-shadow:0 6px 22px rgba(106,13,173,.3); transform:translateX(3px); }
.card:hover .lbl,.card:hover .ico { color:rgba(255,255,255,.75); }
.card:hover .val { color:#fff; }
.ico { font-size:11px; color:#9B59B6; margin-bottom:5px; font-weight:700;
       text-transform:uppercase; letter-spacing:.5px; }
.val { font-size:clamp(21px, 9.5cqh, 48px); font-weight:800; color:#3D0080;
       line-height:1; margin-bottom:5px; white-space:nowrap; }
.lbl { font-size:11px; color:#7B5EA7; font-weight:500; line-height:1.2; white-space:normal; }"

RETURN
"<!DOCTYPE html><html><head><meta charset='UTF-8'><style>" & _css & "</style></head>
<body style='container-type: size;'>
<div class='card' title='Tooltip explicativo del KPI.'>
  <div class='ico'>ETIQUETA</div>
  <div class='val'>" & FORMAT([Medida], "#,0") & "</div>
  <div class='lbl'>Label descriptivo</div>
</div>
</body></html>"
```

**Reglas obligatorias (validadas en producción):**
- `container-type: size` en el `<body>` tag → fix para espacio en blanco en PBI Desktop
- `cqh` en `.val` font-size (no `vh`) → escala al contenedor
- Sin emojis en `.ico` — texto ASCII MAYÚSCULAS
- `title='...'` en `.card` → tooltip nativo
- `overflow:hidden` y `min-height:0` en `.card`

Usar la skill `html-kpi-cards` para variantes (delta badge, insight text, tabla HTML).

### 4. Gráficas Deneb

Claude genera la spec JSON completa. El usuario:
1. Inserta un visual **Deneb** en el lienzo
2. Arrastra los campos al data role "Values"
3. Abre **"Edit specification"** (ícono lápiz en la barra superior del visual)
4. Pega el JSON que entrega Claude

Usar la skill `deneb-chart-generator` para generar specs (ver esa skill para patrones
de hover, selección, cross-filter). Siempre entregar el JSON **completo y listo para pegar**.

**Interactividad obligatoria en todo Deneb:**
- `usermeta.deneb.interactivity.selection: true` + `selectionMode: "single"`
- Hover via param `"hover"` → afecta SOLO color (gradiente más claro)
- Selección via `datum['__selected__'] == 'off'` → opacidad 0.3 en bar Y text label

### 5. Filtro — barra de filtros interactiva

Usar la skill **`powerbi-filter`** para todo lo relacionado con filtros.
Esa skill cubre dos enfoques:
- **Slicers nativos** (general, cualquier proyecto sin custom visual): dropdown con búsqueda
- **Visual "Filtro"** (si el analista tiene el `.pbiviz`): barra de pills con panel "Más Filtros"

Ambos enfoques incluyen DAX de ordenamiento de meses enero→diciembre y años descendentes.
Referirse a `powerbi-filter/SKILL.md` para instrucciones paso a paso completas.

---

## Instrucciones de colocación (para cada visual)

Después de crear/generar cada visual, dar instrucciones precisas:

```
Para el visual HTML Card de KPI Tickets:
1. Insertar visual "HTML Content" en el lienzo (panel de visuales → buscar "HTML")
2. Arrastra la medida "KPI Tickets HTML" al campo "Values"
3. Tamaño recomendado: 200px × 120px (ajustar según tu layout)
4. Posición: columna izquierda, primera tarjeta
```

```
Para el visual Deneb de barras por categoría:
1. Insertar visual "Deneb" en el lienzo
2. Arrastrar al campo "Values": [f_Tickets].[Categoría] + [DAX Medidas].[Total Tickets]
3. Abrir "Edit specification" (ícono lápiz)
4. Seleccionar todo (Ctrl+A) y reemplazar con el JSON de abajo
5. Dar clic en "Apply" para renderizar
```

---

## Paleta de acento

Definir una sola paleta para el dashboard:
- Color de acento: un solo hex (ej. `#6A0DAD`)
- Usar en: `.ico` color, `.val` color, gradientes de hover, filtro Formato→Apariencia
- Segoe UI en todos los textos

---

## Qué NO hacer en M1

- **No usar `pbi.ps1` ni `build-dashboard`** — ese es el flujo M2 (motor PBIR)
- **No editar archivos PBIR directamente** — todo via MCP (medidas) o entrega de spec (Deneb)
- **No usar visuals nativos de PBI** para KPIs o gráficas — HTML Content y Deneb siempre
- **No poner emojis** en ningún texto del dashboard
- **No usar `vh` en `.val`** — usar `cqh` con `container-type: size` en body
- **No olvidar `container-type: size`** en el body tag del HTML — causa espacio en blanco
