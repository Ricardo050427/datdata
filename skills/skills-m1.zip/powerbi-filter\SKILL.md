---
name: powerbi-filter
description: >
  Genera instrucciones paso a paso y DAX para crear la barra de filtros de un dashboard
  Power BI. Activar cuando el usuario pida "filtros", "slicer", "barra de filtros",
  "panel de filtros", o cuando el dashboard requiera filtros interactivos.
  Cubre dos enfoques: slicers nativos (general, cualquier proyecto) y el visual
  personalizado "Filtro" (cuando el .pbiviz esté disponible). Siempre incluye DAX
  para ordenamiento correcto de meses en español y años descendentes.
---

# PowerBI Filter — Barra de Filtros

## ¿Qué enfoque usar?

| Situación | Enfoque |
|-----------|---------|
| Primera vez con el proyecto / sin custom visual instalado | **Slicers nativos** (§2) |
| Proyecto con el visual "Filtro" (.pbiviz) disponible | **Visual Filtro** (§3) |
| El usuario especifica preferencia | Seguir su indicación |

---

## 1. Qué columnas poner en el filtro

Conectar via MCP y explorar el modelo, o preguntarle al usuario qué dimensiones maneja.
Usar esta prioridad:

| Orden | Tipo | Ejemplos | Notas |
|-------|------|----------|-------|
| 1° | Año (tabla calendario) | Año, Ejercicio, #Año | Siempre primero; ordenar descendente |
| 2° | Mes (tabla calendario) | Mes, Periodo, NombreMes | Ordenar enero→diciembre con DAX (§DAX) |
| 3° | Dimensión principal | Categoría, Región, Departamento, Cliente | La que más se analiza en el dashboard |
| 4° | Segunda dimensión | Tipo, Estado, Agente, Proveedor | Solo si el analista la necesita en el filtro |

**Máximo 4 slicers visibles.** Campos adicionales → filtros de página nativos de PBI.

Si el modelo no tiene tabla calendario separada, identificar las columnas de fecha en la
tabla de hechos y sugerirle al analista crearla (ver §2, Paso 1).

---

## 2. Enfoque General — Slicers Nativos

Funciona en cualquier proyecto Power BI sin instalar nada extra.

### DAX obligatorio: ordenamiento de meses en español

**Antes de insertar el slicer de Mes**, el analista debe crear esta columna calculada
en la tabla calendario:

```dax
Mes Orden =
SWITCH(
    [Mes],
    "Enero",      1,   "Febrero",    2,   "Marzo",      3,   "Abril",     4,
    "Mayo",       5,   "Junio",      6,   "Julio",       7,   "Agosto",    8,
    "Septiembre", 9,   "Octubre",   10,   "Noviembre",  11,  "Diciembre", 12,
    99
)
```

Si la tabla usa nombres cortos ("Ene", "Feb", …), adaptar el SWITCH a esos valores.
Si la tabla ya tiene una columna numérica de mes (Month, NumMes, #Mes), usar esa
directamente como columna de orden — no hace falta crear Mes Orden.

### Instrucciones paso a paso para el analista

**Paso 1 — Verificar o crear tabla calendario**

Vista de datos → verificar que existe una tabla con columnas de fecha (Año, Mes, o similares).
Si no existe, crear una nueva tabla con este DAX (Inicio → Nueva tabla):

```dax
d_Calendario =
ADDCOLUMNS(
    CALENDAR(DATE(2020, 1, 1), DATE(2030, 12, 31)),
    "Año",       YEAR([Date]),
    "Mes Orden", MONTH([Date]),
    "Mes",       FORMAT([Date], "MMMM")
)
```

Ajustar el rango de fechas (2020–2030) al rango real de los datos del proyecto.
Luego crear la relación: `d_Calendario[Date]` → columna de fecha de la tabla de hechos.

**Paso 2 — Crear columna Mes Orden (solo si la tabla no tiene número de mes)**

Vista de datos → seleccionar tabla calendario → Nueva columna → escribir el DAX de
Mes Orden de arriba → Enter para confirmar.

**Paso 3 — Ordenar columna Mes por Mes Orden**

1. Vista de datos → clic en la columna **Mes** para seleccionarla
2. Herramientas de columna (barra superior) → **Ordenar por columna** → seleccionar **Mes Orden**
3. Verificar: en una tabla de Power BI, los meses ahora aparecen en orden enero→diciembre

**Paso 4 — Ordenar Año de forma descendente**

Por defecto el slicer de Año mostrará el año más antiguo primero. Para invertirlo:
- Opción A (en el slicer, después de insertarlo): seleccionar el slicer → los tres puntos
  (…) en la esquina superior derecha → **Ordenar por → Año → Orden descendente**
- Opción B (en el modelo): Vista de datos → columna Año → Herramientas de columna →
  Criterio de ordenación: Descendente

**Paso 5 — Insertar slicers en el lienzo**

Para cada campo del filtro (Año, Mes, Categoría, etc.):
1. Panel de Visualizaciones → icono de **Segmentación de datos** (embudo con barras)
2. Arrastrar el campo correspondiente al data role "Campo"
3. Repetir para cada campo; alinearlos horizontalmente en la parte superior del canvas

**Paso 6 — Configurar cada slicer: modo dropdown con búsqueda**

Con el slicer seleccionado → panel Formato (icono de brocha → "Visual"):
- **Configuración del segmentador** → Estilo → **Lista desplegable**
- **Configuración del segmentador** → Búsqueda → **Activar** (aparece la opción al cambiar a dropdown)
- **Configuración del segmentador** → Selección → Selección múltiple: **Activar**
- **Configuración del segmentador** → Mostrar "Seleccionar todo": **Activar** (opcional)

**Paso 7 — Estilo de la barra de filtros**

Posicionar todos los slicers en Y ≈ 0, altura total de la barra ≈ 55-65px.
Para cada slicer → panel Formato:
- **Visual → Borde** → desactivar
- **Visual → Fondo** → desactivar (transparente)
- **Encabezado del segmentador → Fondo** → desactivar
- **Encabezado del segmentador → Fuente** → Segoe UI, 11px, color = acento del dashboard
- **Valores del segmentador → Fuente** → Segoe UI, 11px

Opcionalmente agregar un rectángulo de fondo detrás de toda la barra (Insertar →
Formas → Rectángulo) con el color de fondo de la página o un gris muy claro.

---

## 3. Enfoque Mejorado — Filtro General Universal

El visual estándar para M1 es `FiltroGeneralUniversal.pbiviz`.
Descargarlo desde el repositorio del tutorial: `filtro/FiltroGeneralUniversal.pbiviz`
(o localizar en `EXPORTAR/navara/FiltroGeneralUniversal.pbiviz` si se tiene el paquete local)

### Instalación del visual

1. Descargar `FiltroGeneralUniversal.pbiviz` desde el repositorio o el paquete EXPORTAR
2. En Power BI Desktop con el reporte abierto → menú **Inicio** → **"Más objetos visuales"**
   → **"Importar desde archivo"**
3. Navegar al archivo `.pbiviz` descargado → Abrir
4. Aceptar la advertencia de certificación → confirmar "Importación correcta"
5. El visual aparece en el panel de Visualizaciones con su ícono

### Configuración del visual

1. Insertar el visual **Filtro** en el lienzo (parte superior, altura ≈ 55-65px,
   ancho = ancho total del canvas)
2. Arrastrar las columnas al data role **"Campos de filtro"** en el orden de prioridad de §1:
   primero Año, luego Mes, luego dimensiones
3. El visual muestra los primeros campos como pills visibles y el resto en "Más Filtros"
4. Panel Formato → **Apariencia → Color de acento**: ajustar al color del dashboard (ver §4)

### DAX requerido (igual que §2)

El visual Filtro también necesita que el Mes esté ordenado por Mes Orden y el Año
descendente. Seguir los pasos 1-4 de §2 antes de configurar el visual.

---

## 4. Colores de acento por paleta de dashboard

| Paleta | Acento del filtro | Texto encabezado |
|--------|-------------------|-----------------|
| Morada (default BI) | `#6A0DAD` | `#3D0080` |
| Azul (finanzas) | `#1565C0` | `#0D3B6E` |
| Verde (logística) | `#1B5E20` | `#2E7D32` |
| Naranja (ventas) | `#E65100` | `#BF360C` |
| Gris (técnico/IT) | `#37474F` | `#263238` |

Si el dashboard usa una paleta corporativa diferente, pedir el hex al analista y usarlo.
Nunca dejar el filtro con un color que no combine con el resto del dashboard.

---

## 5. Checklist antes de entregar

- [ ] Tabla calendario existe con columnas Año, Mes Orden, Mes (o equivalentes)
- [ ] Columna Mes ordenada por Mes Orden → meses en orden enero→diciembre
- [ ] Columna Año ordenada descendente → año más reciente primero en el slicer
- [ ] Slicers en modo **Lista desplegable** con **Búsqueda activada**
- [ ] Multi-selección habilitada en todos los slicers
- [ ] Fondos de slicers transparentes o que combinen con el diseño de página
- [ ] No más de 4 slicers visibles (resto en filtros de página)
- [ ] Color de acento del filtro coincide con la paleta del dashboard
- [ ] Se verificó manualmente que enero aparece primero y diciembre al final en el slicer de Mes
