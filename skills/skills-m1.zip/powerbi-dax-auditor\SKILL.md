---
name: powerbi-dax-auditor
description: >
  Audita modelos semánticos de Power BI en busca de problemas de calidad, medidas
  rotas, particiones sin datos y errores DAX comunes. Activar siempre que el usuario
  diga "carga el reporte", "refresca PowerBI", "revisa mis medidas", "algo está mal
  con los datos", "los números no cuadran", o cuando se detecten particiones con
  estado NoData al conectar via MCP. También activar proactivamente al inicio de
  cualquier sesión de trabajo con Power BI si hay una instancia abierta — es buena
  práctica auditar antes de construir. Genera un reporte de salud priorizado.
---

# Power BI DAX Auditor

Audita modelos semánticos de Power BI y reporta problemas con prioridad de corrección.

> **Alcance:** esta skill audita el **modelo** (medidas, particiones, relaciones) via MCP
> con PBI abierto. Para validar el **reporte** (props de visuales que PBI rechaza al abrir)
> existe el linter del motor PBIR: `.\pbi.ps1 validate-page --page "<nombre>"` /
> `fix-page`. Ver `SISTEMA.md §4 y §10` en `C:\Users\lanfa\.claude\code\primera sesion\`.

## Flujo de auditoría

### Paso 1 — Conectar

```
connection_operations → ListLocalInstances
```

Si hay múltiples instancias, preguntar al usuario cuál auditar.

### Paso 2 — Inventario completo

Ejecutar en paralelo:
```
measure_operations → List (todas las medidas)
partition_operations → List (todas las particiones)
table_operations → List (todas las tablas)
```

### Paso 3 — Análisis por categoría

---

## Categoría A: Particiones NoData (CRÍTICO)

Detectar particiones con `state: "NoData"` o `state: "Unprocessed"`.

Para cada una:
1. Obtener la query actual: `partition_operations → Get`
2. Identificar si la ruta del archivo está hardcodeada
3. Si sí → preguntar al usuario la ruta correcta
4. Actualizar la query con la nueva ruta: `partition_operations → Update`
5. Refrescar: `partition_operations → Refresh`

**Reporte**:
```
❌ CRÍTICO: Tabla "NombreTabla" — Partición "NombrePartición"
   Estado: NoData
   Query actual: [mostrar query]
   Acción: Actualizar ruta y refrescar
```

---

## Categoría B: Medidas con errores potenciales

Revisar expresión de cada medida buscando patrones problemáticos:

| Patrón problemático | Por qué es malo | Corrección |
|---------------------|-----------------|------------|
| `tabla[col] / tabla[col2]` | División por cero | Reemplazar con `DIVIDE(num, den, 0)` |
| `SUM(col)` sin CALCULATE | Puede ignorar contexto | Verificar si es intencional |
| `IF(ISBLANK(x), 0, x)` repetido | Verboso | Usar `x + 0` o `COALESCE(x, 0)` |
| Referencias a tablas inexistentes | Error de compilación | Alertar inmediatamente |
| Medidas sin `formatString` | Formato inconsistente | Sugerir formato adecuado al tipo |

**Reporte**:
```
⚠️ ADVERTENCIA: Medida "NombreMedida"
   Problema: División sin DIVIDE()
   Expresión actual: [mostrar]
   Sugerencia: [mostrar corrección]
```

---

## Categoría C: Medidas huérfanas

Medidas que no son referenciadas por ninguna otra medida y probablemente son
versiones antiguas o de prueba.

Buscar patrones en nombres: `_OLD`, `_TEST`, `_TEMP`, `_BACKUP`, `v2`, `copia`.
También listar medidas con `isHidden: true` que no son auxiliares documentadas.

**Reporte**:
```
ℹ️ INFO: Medidas posiblemente huérfanas (considerar eliminar):
   - "Medida_OLD" (oculta, sin referencias)
   - "Test_Tickets" (nombre sugiere prueba)
```

---

## Categoría D: Modelo semántico

Verificar:
- Tablas sin relaciones (islas) → posible error de modelado
- Relaciones bidireccionales → pueden causar ambigüedad, advertir
- Ausencia de tabla calendario cuando hay columnas fecha

---

## Formato del reporte de salud

Presentar siempre en este orden:

```
════════════════════════════════════
 REPORTE DE SALUD — [NombreModelo]
 [Fecha y hora]
════════════════════════════════════

RESUMEN EJECUTIVO
  ❌ Críticos:     X
  ⚠️ Advertencias: X  
  ℹ️ Info:         X
  ✅ Sin problemas: X medidas / X tablas

CRÍTICOS (resolver antes de publicar)
  [lista detallada]

ADVERTENCIAS (resolver antes de entregar)
  [lista detallada]

INFO (mejoras opcionales)
  [lista detallada]

ACCIONES AUTOMÁTICAS DISPONIBLES
  ¿Quieres que corrija automáticamente los problemas con solución clara?
  [S] Sí, corregir todo lo que pueda via MCP
  [N] No, solo mostrar el reporte
```

---

## Correcciones automáticas via MCP

Si el usuario dice sí a correcciones automáticas:

1. **Rutas de particiones**: Preguntar ruta correcta → `partition_operations → Update → Refresh`
2. **Formato de medidas faltante**: Inferir del tipo y actualizar → `measure_operations → Update`
3. **DIVIDE()**: Reemplazar divisiones manuales → `measure_operations → Update`

Para cada corrección: confirmar con el usuario el cambio antes de aplicarlo.
Nunca eliminar medidas automáticamente — solo sugerir.

---

## Trigger automático en preferences del usuario

Si en las preferencias del usuario aparece `"carga el reporte"` o `"refresca PowerBI"`,
ejecutar este skill completo automáticamente al detectar esas frases, incluyendo:
1. Conectar a la instancia activa
2. Revisar particiones NoData
3. Preguntar rutas si es necesario
4. Actualizar y refrescar
5. Mostrar reporte de salud resumido
